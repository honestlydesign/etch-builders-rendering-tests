<?php
/**
 * SelectField.php
 *
 * This file defines the SelectField class, which represents a custom field of type 'select'.
 *
 * @package Etch\CustomFields\Fields
 */

namespace Etch\CustomFields\Fields;

/**
 * Class SelectField
 *
 * Represents a custom field of type 'select'. Values are stored and accepted only
 * when they match one of the configured options. Whitespace is trimmed before validation.
 *
 * @phpstan-import-type CustomField from \Etch\CustomFields\CustomFieldTypes
 */
class SelectField extends BaseField {

	/**
	 * The field value.
	 *
	 * @var string
	 */
	public string $value = '';

	/**
	 * Valid options keyed by stored value with display label as value.
	 *
	 * Built by parsing the newline-separated options string from the field definition.
	 *
	 * @var array<string, string>
	 */
	public array $options = array();

	/**
	 * Constructor.
	 *
	 * @param CustomField $field The custom field.
	 * @param mixed       $value The field value.
	 */
	protected function __construct( $field, $value ) {
		parent::__construct( $field );

		$this->type    = 'select';
		$this->options = self::parse_options_string( $field['options'] ?? '' );
		$this->value   = $this->sanitize_value( $value );
	}

	/**
	 * Render the field.
	 *
	 * @return void
	 */
	public function render() {
		$this->render_label();
		echo '<select id="' . esc_attr( $this->key ) . '" name="' . esc_attr( $this->key ) . '" class="etch-cf-input" ' . ( $this->required ? 'required' : '' ) . '>';
		echo '<option value=""></option>';
		foreach ( $this->options as $option_value => $opt_label ) {
			echo '<option value="' . esc_attr( $option_value ) . '"' . ( $this->value === $option_value ? ' selected' : '' ) . '>' . esc_html( $opt_label ) . '</option>';
		}
		echo '</select>';
	}

	/**
	 * Sanitizes the value: trims whitespace then accepts only values present in the options list.
	 *
	 * @param mixed $value The value to sanitize.
	 * @return string The sanitized value, or '' if invalid or not in options.
	 */
	public function sanitize_value( $value ): string {
		if ( ! is_string( $value ) ) {
			return '';
		}

		$value = trim( $value );

		if ( '' === $value ) {
			return '';
		}

		return array_key_exists( $value, $this->options ) ? $value : '';
	}

	/**
	 * Parses a newline-separated options string into a value => label map.
	 *
	 * Each line may be "Label : value" (space-colon-space) or plain "value" (label equals value).
	 *
	 * @param mixed $options_string The raw options string from the field definition.
	 * @return array<string, string> Map of stored value to display label.
	 */
	private static function parse_options_string( $options_string ): array {
		if ( ! is_string( $options_string ) || '' === trim( $options_string ) ) {
			return array();
		}

		$result = array();
		foreach ( explode( "\n", $options_string ) as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}

			if ( str_contains( $line, ' : ' ) ) {
				[ $label, $value ] = explode( ' : ', $line, 2 );
				$result[ trim( $value ) ] = trim( $label );
			} else {
				$result[ $line ] = $line;
			}
		}

		return $result;
	}

	/**
	 * Validates the raw value against the required constraint and the options list.
	 *
	 * @param string $raw_value The raw value to validate.
	 * @return string[] Error messages, empty when valid.
	 */
	public function validate( string $raw_value ): array {
		$errors = parent::validate( $raw_value );

		if ( array() !== $errors ) {
			return $errors;
		}

		$trimmed = trim( $raw_value );

		if ( '' !== $trimmed && ! array_key_exists( $trimmed, $this->options ) ) {
			$errors[] = "{$this->label} must be one of the available options";
		}

		return $errors;
	}
}
