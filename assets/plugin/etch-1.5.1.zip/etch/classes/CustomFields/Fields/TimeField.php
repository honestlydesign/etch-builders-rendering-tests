<?php
/**
 * TimeField.php
 *
 * This file defines the TimeField class, which represents a custom field of type 'time'.
 *
 * @package Etch\CustomFields\Fields
 */

namespace Etch\CustomFields\Fields;

/**
 * Class TimeField
 *
 * Represents a custom field of type 'time'. Values are stored and accepted only
 * in clock-valid HH:MM:SS format. Whitespace is trimmed before validation.
 *
 * @phpstan-import-type CustomField from \Etch\CustomFields\CustomFieldTypes
 */
class TimeField extends BaseField {

	/**
	 * The field value.
	 *
	 * @var string
	 */
	public string $value = '';

	/**
	 * Constructor.
	 *
	 * @param CustomField $field The custom field.
	 * @param mixed       $val The field value.
	 */
	protected function __construct( $field, $val ) {
		parent::__construct( $field );

		$this->type  = 'time';
		$this->value = $this->sanitize_value( $val );
	}

	/**
	 * Render the field.
	 *
	 * @return void
	 */
	public function render() {
		$this->render_label();
		echo '<input type="time" id="' . esc_attr( $this->key ) . '" name="' . esc_attr( $this->key ) . '" value="' . esc_attr( $this->value ) . '" class="etch-cf-input" ' . ( $this->required ? 'required' : '' ) . ' step="1" />';
	}

	/**
	 * Sanitizes the value: trims whitespace then accepts only clock-valid HH:MM:SS times.
	 *
	 * @param mixed $value The value to sanitize.
	 * @return string The sanitized time string, or '' if invalid.
	 */
	public function sanitize_value( $value ): string {
		if ( ! is_string( $value ) ) {
			return '';
		}

		$value = self::normalize( trim( $value ) );

		return self::is_valid_time( $value ) ? $value : '';
	}

	/**
	 * Validates the raw value against the required constraint and time format.
	 *
	 * @param string $raw_value The raw value to validate.
	 * @return string[] Error messages, empty when valid.
	 */
	public function validate( string $raw_value ): array {
		$errors = parent::validate( $raw_value );

		if ( array() !== $errors ) {
			return $errors;
		}

		$trimmed = self::normalize( trim( $raw_value ) );

		if ( '' !== $trimmed && ! self::is_valid_time( $trimmed ) ) {
			$errors[] = "{$this->label} must be a valid time (HH:MM:SS)";
		}

		return $errors;
	}

	/**
	 * Normalizes HH:MM to HH:MM:SS by appending ':00' when seconds are absent.
	 *
	 * @param string $value The string to normalize.
	 */
	private static function normalize( string $value ): string {
		if ( 1 === preg_match( '/^\d{2}:\d{2}$/', $value ) ) {
			return $value . ':00';
		}

		return $value;
	}

	/**
	 * Returns true only for clock-valid times in HH:MM:SS format.
	 *
	 * @param string $value The string to check.
	 */
	private static function is_valid_time( string $value ): bool {
		if ( 1 !== preg_match( '/^(\d{2}):(\d{2}):(\d{2})$/', $value, $matches ) ) {
			return false;
		}

		$h = (int) $matches[1];
		$m = (int) $matches[2];
		$s = (int) $matches[3];

		return $h <= 23 && $m <= 59 && $s <= 59;
	}
}
