<?php
/**
 * BaseField.php
 *
 * This file defines the BaseField class, which serves as a base for custom fields in the Etch plugin.
 *
 * @package Etch\CustomFields\Fields
 */

namespace Etch\CustomFields\Fields;

/**
 * Class BaseField
 *
 * Represents a base class for custom fields.
 *
 * @phpstan-import-type CustomField from \Etch\CustomFields\CustomFieldTypes
 * @phpstan-import-type CustomFieldType from \Etch\CustomFields\CustomFieldTypes
 */
abstract class BaseField {

	/**
	 * The field's label.
	 *
	 * @var string
	 */
	public string $label;

	/**
	 * The field's key.
	 *
	 * @var string
	 */
	public string $key;

	/**
	 * The field's type.
	 *
	 * @var CustomFieldType
	 */
	public $type;

	/**
	 * The field's description.
	 *
	 * @var string
	 */
	public string $description;

	/**
	 * The field's visibility.
	 *
	 * @var bool
	 */
	public bool $required;


	/**
	 * Constructor.
	 *
	 * @param CustomField $field The custom field.
	 */
	protected function __construct( $field ) {
		$this->label       = $field['label'];
		$this->key         = $field['key'];
		$this->type        = $field['type'];
		$this->description = $field['description'] ?? '';
		$this->required    = $field['required'] ?? false;
	}

	/**
	 * Create the correct custom field base on the type of the given definition.
	 *
	 * @param CustomField $field The custom field.
	 * @param mixed       $val The field value.
	 *
	 * @return BaseField The custom field instance.
	 * @throws \InvalidArgumentException If the field type is not recognized.
	 */
	public static function create( $field, $val ): BaseField {
		$map = array(
			'boolean'  => BooleanField::class,
			'text'     => TextField::class,
			'number'   => NumberField::class,
			'textarea' => TextAreaField::class,
			'date'     => DateField::class,
			'time'     => TimeField::class,
			'select'   => SelectField::class,
		);

		$type = $field['type'];

		if ( ! isset( $map[ $type ] ) ) {
			throw new \InvalidArgumentException( 'Unknown field type: ' . esc_html( $type ) );
		}

		$class = $map[ $type ];
		return new $class( $field, $val );
	}

	/**
	 * Render the field.
	 *
	 * @return void
	 */
	abstract public function render();

	/**
	 * Sanitize value for the field.
	 *
	 * @param mixed $value The value to sanitize.
	 * @return mixed
	 */
	abstract public function sanitize_value( $value );

	/**
	 * Validate a raw (pre-sanitized) value against the field's constraints.
	 *
	 * Returns an empty array when valid, or an array of human-readable error
	 * messages when not. Subclasses should call parent::validate() first and
	 * then append type-specific errors.
	 *
	 * @param string $raw_value The raw value to validate.
	 * @return string[] Error messages, empty when valid.
	 */
	public function validate( string $raw_value ): array {
		if ( $this->required && trim( $raw_value ) === '' ) {
			return array( "{$this->label} is required" );
		}

		return array();
	}

	/**
	 * Render the field label.
	 *
	 * @return void
	 */
	public function render_label() {
		echo '<label for="' . esc_attr( $this->key ) . '" class="etch-cf-label">' . esc_html( $this->label ) . ( $this->required ? ' <span class="etch-cf-required">*</span>' : '' ) . '</label>';
	}
}
