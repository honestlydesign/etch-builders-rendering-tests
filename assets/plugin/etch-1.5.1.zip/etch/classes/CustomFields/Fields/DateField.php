<?php
/**
 * DateField.php
 *
 * This file defines the DateField class, which represents a custom field of type 'date'.
 *
 * @package Etch\CustomFields\Fields
 */

namespace Etch\CustomFields\Fields;

/**
 * Class DateField
 *
 * Represents a custom field of type 'date'. Values are stored and accepted only
 * in calendar-valid yyyy-mm-dd format. Whitespace is trimmed before validation.
 *
 * @phpstan-import-type CustomField from \Etch\CustomFields\CustomFieldTypes
 */
class DateField extends BaseField {

	/**
	 * The field value.
	 *
	 * @var string
	 */
	public string $value = '';

	/**
	 * Constructor.
	 *
	 * @param CustomField $field The custom field.
	 * @param mixed       $val The field value.
	 */
	protected function __construct( $field, $val ) {
		parent::__construct( $field );

		$this->type  = 'date';
		$this->value = $this->sanitize_value( $val );
	}

	/**
	 * Render the field.
	 *
	 * @return void
	 */
	public function render() {
		$this->render_label();
		echo '<input type="date" id="' . esc_attr( $this->key ) . '" name="' . esc_attr( $this->key ) . '" value="' . esc_attr( $this->value ) . '" class="etch-cf-input" ' . ( $this->required ? 'required' : '' ) . ' />';
	}

	/**
	 * Sanitizes the value: trims whitespace then accepts only calendar-valid yyyy-mm-dd dates.
	 *
	 * @param mixed $value The value to sanitize.
	 * @return string The sanitized date string, or '' if invalid.
	 */
	public function sanitize_value( $value ): string {
		if ( ! is_string( $value ) ) {
			return '';
		}

		$value = trim( $value );

		return self::is_valid_date( $value ) ? $value : '';
	}

	/**
	 * Validates the raw value against the required constraint and date format.
	 *
	 * @param string $raw_value The raw value to validate.
	 * @return string[] Error messages, empty when valid.
	 */
	public function validate( string $raw_value ): array {
		$errors = parent::validate( $raw_value );

		if ( array() !== $errors ) {
			return $errors;
		}

		$trimmed = trim( $raw_value );

		if ( '' !== $trimmed && ! self::is_valid_date( $trimmed ) ) {
			$errors[] = "{$this->label} must be a valid date (YYYY-MM-DD)";
		}

		return $errors;
	}

	/**
	 * Returns true only for calendar-valid dates in yyyy-mm-dd format.
	 *
	 * @param string $value The string to check.
	 */
	private static function is_valid_date( string $value ): bool {
		if ( 1 !== preg_match( '/^\d{4}-(\d{2})-(\d{2})$/', $value, $matches ) ) {
			return false;
		}

		$date = \DateTime::createFromFormat( 'Y-m-d', $value );

		return false !== $date && $date->format( 'Y-m-d' ) === $value;
	}
}
