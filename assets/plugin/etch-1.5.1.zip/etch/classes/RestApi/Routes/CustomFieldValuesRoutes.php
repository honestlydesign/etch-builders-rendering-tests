<?php
/**
 * CustomFieldValuesRoutes.php
 *
 * REST API routes for reading, writing and deleting custom field values on
 * a single post, resolved against the field groups assigned to that post.
 *
 * PHP version 7.4+
 *
 * @category  Plugin
 * @package   Etch\RestApi\Routes
 */

declare(strict_types=1);
namespace Etch\RestApi\Routes;

use Etch\CustomFields\CustomFieldService;
use Etch\CustomFields\Fields\BaseField;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

/**
 * CustomFieldValuesRoutes
 *
 * @phpstan-import-type CustomField from \Etch\CustomFields\CustomFieldTypes
 * @phpstan-import-type CustomFieldGroup from \Etch\CustomFields\CustomFieldTypes
 *
 * @package Etch\RestApi\Routes
 */
class CustomFieldValuesRoutes extends BaseRoute {

	/**
	 * Custom field service.
	 *
	 * @var CustomFieldService
	 */
	private CustomFieldService $cf_service;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->cf_service = CustomFieldService::get_instance();
	}

	/**
	 * Returns the route definitions for the per-post field-values endpoints.
	 *
	 * @return array<array{route: string, methods: string|array<string>, callback: callable, permission_callback?: callable, args?: array<string, mixed>}>
	 */
	protected function get_routes(): array {
		return array(
			array(
				'route' => '/cms/post/(?P<post_id>\d+)/field-values',
				'methods' => 'GET',
				'callback' => array( $this, 'get_field_values' ),
			),
			array(
				'route' => '/cms/post/(?P<post_id>\d+)/field-values/(?P<field_key>[a-zA-Z0-9_-]+)',
				'methods' => 'GET',
				'callback' => array( $this, 'get_field_value' ),
			),
			array(
				'route' => '/cms/post/(?P<post_id>\d+)/field-values/(?P<field_key>[a-zA-Z0-9_-]+)',
				'methods' => 'PUT',
				'callback' => array( $this, 'update_field_value' ),
			),
			array(
				'route' => '/cms/post/(?P<post_id>\d+)/field-values',
				'methods' => 'PUT',
				'callback' => array( $this, 'update_field_values' ),
			),
			array(
				'route' => '/cms/post/(?P<post_id>\d+)/field-values/(?P<field_key>[a-zA-Z0-9_-]+)',
				'methods' => 'DELETE',
				'callback' => array( $this, 'delete_field_value' ),
			),
		);
	}

	/**
	 * Bulk read: every field of every group assigned to the target post.
	 *
	 * @param WP_REST_Request<array{post_id: string}> $request The REST request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_field_values( $request ): WP_REST_Response|WP_Error {
		$post_id = absint( $request->get_param( 'post_id' ) );
		$gate    = $this->guard_post_access( $post_id );
		if ( $gate instanceof WP_Error ) {
			return $gate;
		}

		return new WP_REST_Response(
			array(
				'post_id' => $post_id,
				'groups'  => $this->groups_payload( $post_id ),
			),
			200
		);
	}

	/**
	 * Single read by field key, resolved against assigned groups.
	 *
	 * @param WP_REST_Request<array{post_id: string, field_key: string}> $request The REST request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function get_field_value( $request ): WP_REST_Response|WP_Error {
		$post_id   = absint( $request->get_param( 'post_id' ) );
		$field_key = (string) $request->get_param( 'field_key' );

		$gate = $this->guard_post_access( $post_id );
		if ( $gate instanceof WP_Error ) {
			return $gate;
		}

		$resolved = $this->resolve_field( $post_id, $field_key );
		if ( null === $resolved ) {
			return $this->unknown_field_error();
		}

		[ $group_id, $field ] = $resolved;

		return new WP_REST_Response(
			array(
				'post_id'  => $post_id,
				'group_id' => $group_id,
				'field'    => $this->field_payload( $post_id, $field ),
			),
			200
		);
	}

	/**
	 * Single write: persist a value for one field on the post.
	 *
	 * @param WP_REST_Request<array{post_id: string, field_key: string}> $request The REST request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function update_field_value( $request ): WP_REST_Response|WP_Error {
		$post_id   = absint( $request->get_param( 'post_id' ) );
		$field_key = (string) $request->get_param( 'field_key' );

		$gate = $this->guard_post_access( $post_id );
		if ( $gate instanceof WP_Error ) {
			return $gate;
		}

		$body = json_decode( (string) $request->get_body(), true );
		if ( ! is_array( $body ) || ! array_key_exists( 'value', $body ) ) {
			return new WP_Error( 'invalid_request', 'Invalid request', array( 'status' => 400 ) );
		}
		$value = $body['value'];

		$resolved = $this->resolve_field( $post_id, $field_key );
		if ( null === $resolved ) {
			return $this->unknown_field_error();
		}

		[ $group_id, $field ] = $resolved;

		$sanitized = $this->sanitize( $field, $value );
		if ( $this->is_invalid_value( $field, $value, $sanitized ) ) {
			return $this->invalid_value_error();
		}

		$this->cf_service->set_field_value(
			array(
				'post_id'  => $post_id,
				'group_id' => $group_id,
				'field'    => $field,
				'value'    => $value,
			)
		);

		return new WP_REST_Response(
			array(
				'post_id'  => $post_id,
				'group_id' => $group_id,
				'field'    => $this->field_payload( $post_id, $field ),
			),
			200
		);
	}

	/**
	 * Bulk write: persist a map of field-key → value on the post, atomically.
	 *
	 * @param WP_REST_Request<array{post_id: string}> $request The REST request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function update_field_values( $request ): WP_REST_Response|WP_Error {
		$post_id = absint( $request->get_param( 'post_id' ) );

		$gate = $this->guard_post_access( $post_id );
		if ( $gate instanceof WP_Error ) {
			return $gate;
		}

		$values = $this->extract_values_map( $request );
		if ( $values instanceof WP_Error ) {
			return $values;
		}

		$writes = $this->build_writes( $post_id, $values );
		if ( $writes instanceof WP_Error ) {
			return $writes;
		}

		$this->cf_service->set_field_values( $post_id, $writes );

		$written_keys = array_map( static fn( array $write ): string => $write['field']['key'], $writes );

		return new WP_REST_Response(
			array(
				'post_id' => $post_id,
				'groups'  => $this->groups_payload( $post_id, $written_keys ),
			),
			200
		);
	}

	/**
	 * Pull the `values` map out of a bulk PUT request body.
	 *
	 * @param WP_REST_Request<array{post_id: string}> $request The REST request object.
	 * @return array<string, mixed>|WP_Error
	 */
	private function extract_values_map( $request ): array|WP_Error {
		$body   = json_decode( (string) $request->get_body(), true );
		$values = is_array( $body ) ? ( $body['values'] ?? null ) : null;
		if ( ! is_array( $values ) ) {
			return new WP_Error( 'invalid_request', 'Invalid request', array( 'status' => 400 ) );
		}
		return $values;
	}

	/**
	 * Resolve and validate every entry in a bulk values map.
	 *
	 * Returns the list of writes to apply, or the first error encountered —
	 * without touching post meta — so the caller can write atomically.
	 *
	 * @param int                  $post_id Target post id.
	 * @param array<string, mixed> $values  Incoming field-key → value map.
	 * @return array<int, array{group_id: string, field: CustomField, value: mixed}>|WP_Error
	 */
	private function build_writes( int $post_id, array $values ): array|WP_Error {
		$index  = $this->field_index( $post_id );
		$writes = array();
		foreach ( $values as $key => $value ) {
			$key = (string) $key;
			if ( ! isset( $index[ $key ] ) ) {
				return $this->unknown_field_error();
			}

			[ $group_id, $field ] = $index[ $key ];
			$sanitized            = $this->sanitize( $field, $value );
			if ( $this->is_invalid_value( $field, $value, $sanitized ) ) {
				return $this->invalid_value_error();
			}

			$writes[] = array(
				'group_id' => $group_id,
				'field'    => $field,
				'value'    => $value,
			);
		}
		return $writes;
	}

	/**
	 * Delete the meta value for one field on the post.
	 *
	 * @param WP_REST_Request<array{post_id: string, field_key: string}> $request The REST request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function delete_field_value( $request ): WP_REST_Response|WP_Error {
		$post_id   = absint( $request->get_param( 'post_id' ) );
		$field_key = (string) $request->get_param( 'field_key' );

		$gate = $this->guard_post_access( $post_id );
		if ( $gate instanceof WP_Error ) {
			return $gate;
		}

		$resolved = $this->resolve_field( $post_id, $field_key );
		if ( null === $resolved ) {
			return $this->unknown_field_error();
		}

		$this->cf_service->delete_field_value(
			array(
				'post_id'   => $post_id,
				'field_key' => $field_key,
			)
		);

		return new WP_REST_Response( array( 'message' => 'Field value deleted' ), 200 );
	}

	/**
	 * Verify the post exists and the current user can edit it.
	 *
	 * @param int $post_id Target post id.
	 * @return WP_Error|null Error response when access is denied, null otherwise.
	 */
	private function guard_post_access( int $post_id ): ?WP_Error {
		if ( ! get_post( $post_id ) ) {
			return new WP_Error( 'post_not_found', 'Post not found', array( 'status' => 404 ) );
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return new WP_Error( 'forbidden', 'You do not have permission to edit this post', array( 'status' => 403 ) );
		}

		return null;
	}

	/**
	 * Get all field groups whose assignment matches the target post.
	 *
	 * @param int $post_id Target post id.
	 * @return array<string, CustomFieldGroup>
	 */
	private function assigned_groups_for_post( int $post_id ): array {
		$post = get_post( $post_id );
		if ( null === $post ) {
			return array();
		}

		$matched = array();
		foreach ( $this->cf_service->get_all_custom_field_groups() as $group_id => $group ) {
			if ( $this->assignment_applies( $group['assigned_to'], $post ) ) {
				$matched[ $group_id ] = $group;
			}
		}

		return $matched;
	}

	/**
	 * Whether an assignment rule applies to the given post.
	 *
	 * @param mixed    $assigned_to Assignment definition.
	 * @param \WP_Post $post        Target post object.
	 */
	private function assignment_applies( $assigned_to, \WP_Post $post ): bool {
		if ( ! is_array( $assigned_to ) ) {
			return false;
		}

		$op = $assigned_to['op'] ?? 'isIn';

		if ( isset( $assigned_to['post_types'] ) && is_array( $assigned_to['post_types'] ) ) {
			$in = in_array( $post->post_type, $assigned_to['post_types'], true );
			return 'isNotIn' === $op ? ! $in : $in;
		}

		if ( isset( $assigned_to['post_ids'] ) && is_array( $assigned_to['post_ids'] ) ) {
			$in = in_array( $post->ID, $assigned_to['post_ids'], true );
			return 'isNotIn' === $op ? ! $in : $in;
		}

		return false;
	}

	/**
	 * Find the first assigned group containing the given field key.
	 *
	 * @param int    $post_id   Target post id.
	 * @param string $field_key Field key being resolved.
	 * @return array{0: string, 1: CustomField}|null
	 */
	private function resolve_field( int $post_id, string $field_key ): ?array {
		return $this->field_index( $post_id )[ $field_key ] ?? null;
	}

	/**
	 * Map every field key on the post's assigned groups to its [group_id, field].
	 *
	 * Built once per resolution so bulk operations don't re-walk every group per
	 * key. When a key appears in more than one assigned group the first wins.
	 *
	 * @param int $post_id Target post id.
	 * @return array<string, array{0: string, 1: CustomField}>
	 */
	private function field_index( int $post_id ): array {
		$index = array();
		foreach ( $this->assigned_groups_for_post( $post_id ) as $group_id => $group ) {
			foreach ( $group['fields'] as $field ) {
				if ( ! isset( $index[ $field['key'] ] ) ) {
					$index[ $field['key'] ] = array( (string) $group_id, $field );
				}
			}
		}
		return $index;
	}

	/**
	 * Build the response payload for a single field, with its stored value.
	 *
	 * Shared by every read and write handler so a write response is identical
	 * to the GET that would follow it.
	 *
	 * @param int   $post_id Target post id.
	 * @param array $field   Field definition.
	 *
	 * @phpstan-param CustomField $field
	 * @return array{key: string, label: string, type: string, value: mixed}
	 */
	private function field_payload( int $post_id, array $field ): array {
		return array(
			'key'   => $field['key'],
			'label' => $field['label'],
			'type'  => $field['type'],
			'value' => $this->cf_service->read_field_value( $post_id, $field ),
		);
	}

	/**
	 * Build the grouped field payload for a post's assigned groups.
	 *
	 * @param int                            $post_id   Target post id.
	 * @param array<int|string, string>|null $only_keys Restrict to these field keys, or null for all.
	 * @return array<string, array{label: string, fields: array<string, array{key: string, label: string, type: string, value: mixed}>}>
	 */
	private function groups_payload( int $post_id, ?array $only_keys = null ): array {
		$groups = array();
		foreach ( $this->assigned_groups_for_post( $post_id ) as $group_id => $group ) {
			$fields = array();
			foreach ( $group['fields'] as $field ) {
				if ( null !== $only_keys && ! in_array( $field['key'], $only_keys, true ) ) {
					continue;
				}
				$fields[ $field['key'] ] = $this->field_payload( $post_id, $field );
			}
			if ( null !== $only_keys && empty( $fields ) ) {
				continue;
			}
			$groups[ (string) $group_id ] = array(
				'label'  => $group['label'],
				'fields' => $fields,
			);
		}
		return $groups;
	}

	/**
	 * Sanitize a value against the field type.
	 *
	 * @param array $field Field definition.
	 * @param mixed $value Raw incoming value.
	 *
	 * @phpstan-param CustomField $field
	 * @return mixed
	 */
	private function sanitize( array $field, $value ): mixed {
		return BaseField::create( $field, $value )->sanitize_value( $value );
	}

	/**
	 * Whether an incoming value was non-empty but failed to sanitize to a usable value.
	 *
	 * @param array $field     Field definition.
	 * @param mixed $raw       Raw incoming value.
	 * @param mixed $sanitized Sanitized value.
	 *
	 * @phpstan-param CustomField $field
	 */
	private function is_invalid_value( array $field, $raw, $sanitized ): bool {
		if ( $this->is_non_canonical_boolean_input( $field, $raw ) ) {
			return true;
		}

		if ( null === $raw || '' === $raw ) {
			return false;
		}
		return null === $sanitized;
	}

	/**
	 * Whether a boolean field received a non-canonical non-empty token.
	 *
	 * @param array $field Field definition.
	 * @param mixed $raw   Raw incoming value.
	 *
	 * @phpstan-param CustomField $field
	 */
	private function is_non_canonical_boolean_input( array $field, $raw ): bool {
		if ( 'boolean' !== $field['type'] ) {
			return false;
		}

		if ( null === $raw || '' === $raw ) {
			return false;
		}

		if ( is_string( $raw ) ) {
			$raw = strtolower( trim( $raw ) );
		}

		return ! in_array( $raw, array( true, false, 1, 0, '1', '0', 'true', 'false' ), true );
	}

	/**
	 * Standard "unknown field" error response.
	 */
	private function unknown_field_error(): WP_Error {
		return new WP_Error( 'custom_field_not_found', 'Field not found on this post', array( 'status' => 404 ) );
	}

	/**
	 * Standard "invalid value" error response.
	 */
	private function invalid_value_error(): WP_Error {
		return new WP_Error( 'custom_field_invalid_value', 'Value failed validation for this field type', array( 'status' => 400 ) );
	}
}
