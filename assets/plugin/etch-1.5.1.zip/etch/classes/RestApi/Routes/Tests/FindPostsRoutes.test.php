<?php
/**
 * FindPostsRoutesTest.php
 *
 * @package Etch
 */

declare(strict_types=1);

namespace Etch\RestApi\Routes\Tests;

use Etch\RestApi\Routes\FindPostsRoutes;
use WP_REST_Request;
use WP_UnitTestCase;

/**
 * Tests for FindPostsRoutes.
 */
class FindPostsRoutesTest extends WP_UnitTestCase {

	/**
	 * Set up route registration and an authorized editor.
	 */
	public function setUp(): void {
		parent::setUp();

		( new FindPostsRoutes() )->register_routes();
		do_action( 'rest_api_init' );

		$editor = $this->factory->user->create_and_get(
			array(
				'role' => 'editor',
			)
		);
		wp_set_current_user( $editor->ID );
	}

	/**
	 * Test valid requests return grouped results with the expected shape.
	 */
	public function test_grouped_results_are_returned_when_request_is_valid(): void {
		$post_id = $this->factory->post->create(
			array(
				'post_type'   => 'post',
				'post_status' => 'publish',
				'post_title'  => 'Hero post',
				'post_name'   => 'hero-post',
				'post_date'   => '2025-01-01 12:00:00',
			)
		);

		$request = new WP_REST_Request( 'GET', '/etch-api/cms/find-posts' );
		$request->set_param( 'post_type', 'post' );
		$request->set_param( 'limit', 1 );

		$response = rest_do_request( $request );

		$this->assertSame( 200, $response->get_status() );
		$this->assertSame(
			array(
				array(
					'post_type'  => 'post',
					'totalPosts' => 1,
					'posts'      => array(
						array(
							'id'    => $post_id,
							'title' => 'Hero post',
							'slug'  => 'hero-post',
						),
					),
				),
			),
			$response->get_data()
		);
	}

	/**
	 * Test omitted limit defaults to ten posts.
	 */
	public function test_default_limit_is_applied_when_limit_is_omitted(): void {
		for ( $i = 0; $i < 12; $i++ ) {
			$this->factory->post->create(
				array(
					'post_type'   => 'post',
					'post_status' => 'publish',
					'post_title'  => 'Post ' . $i,
					'post_name'   => 'post-' . $i,
					'post_date'   => sprintf( '2025-01-%02d 12:00:00', $i + 1 ),
				)
			);
		}

		$request  = new WP_REST_Request( 'GET', '/etch-api/cms/find-posts' );
		$request->set_param( 'post_type', 'post' );
		$response = rest_do_request( $request );
		$data     = $response->get_data();

		$this->assertSame( 200, $response->get_status() );
		$this->assertCount( 10, $data[0]['posts'] );
	}

	/**
	 * Test unauthorized users cannot access the endpoint.
	 */
	public function test_unauthorized_response_is_returned_when_user_lacks_read_access(): void {
		wp_set_current_user( 0 );

		$request  = new WP_REST_Request( 'GET', '/etch-api/cms/find-posts' );
		$response = rest_do_request( $request );

		$this->assertTrue( in_array( $response->get_status(), array( 401, 403 ), true ) );
	}

	/**
	 * Test invalid post type returns a 400 response.
	 */
	public function test_invalid_post_type_error_is_returned_when_requested_post_type_is_not_supported(): void {
		$request = new WP_REST_Request( 'GET', '/etch-api/cms/find-posts' );
		$request->set_param( 'post_type', 'attachment' );

		$response = rest_do_request( $request );

		$this->assertSame( 400, $response->get_status() );
		$this->assertSame( 'invalid_post_type', $response->get_data()['code'] );
	}
}
