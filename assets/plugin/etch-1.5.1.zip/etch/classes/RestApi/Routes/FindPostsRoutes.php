<?php
/**
 * FindPostsRoutes.php
 *
 * @package Etch
 */

declare(strict_types=1);

namespace Etch\RestApi\Routes;

use Etch\Services\FindPostsService;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;

/**
 * Routes for grouped post search.
 */
class FindPostsRoutes extends BaseRoute {

	/**
	 * Route definitions.
	 *
	 * @return array<array{route: string, methods: string|array<string>, callback: callable, permission_callback?: callable, args?: array<string, mixed>}>
	 */
	protected function get_routes(): array {
		return array(
			array(
				'route'    => '/cms/find-posts',
				'methods'  => 'GET',
				'callback' => array( $this, 'find_posts' ),
				'args'     => array(
					'title'     => array(
						'type'              => 'string',
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'slug'      => array(
						'type'              => 'string',
						'required'          => false,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'post_type' => array(
						'type'              => 'string',
						'required'          => false,
						'sanitize_callback' => 'sanitize_key',
					),
					'limit'     => array(
						'type'              => 'integer',
						'required'          => false,
						'sanitize_callback' => 'absint',
						'validate_callback' => static fn( $value ): bool => is_numeric( $value ) && (int) $value >= 1 && (int) $value <= 100,
					),
				),
			),
		);
	}

	/**
	 * Find posts for AI tooling.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @phpstan-param WP_REST_Request<array<string,mixed>> $request
	 * @return WP_REST_Response|WP_Error
	 */
	public function find_posts( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$title     = $request->get_param( 'title' );
		$slug      = $request->get_param( 'slug' );
		$limit     = $request->get_param( 'limit' );
		$post_type = $request->get_param( 'post_type' );

		$args = array(
			'title' => is_string( $title ) ? $title : '',
			'slug'  => is_string( $slug ) ? $slug : '',
			'limit' => is_numeric( $limit ) ? (int) $limit : 10,
		);

		if ( is_string( $post_type ) ) {
			$args['post_type'] = $post_type;
		}

		$result = ( new FindPostsService() )->find_posts( $args );

		if ( $result instanceof WP_Error ) {
			return $result;
		}

		return new WP_REST_Response( $result, 200 );
	}
}
