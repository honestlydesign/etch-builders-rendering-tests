<?php
/**
 * WoocommerceIntegration
 *
 * @package Etch\DynamicData\Integrations
 */

declare(strict_types=1);

namespace Etch\DynamicData\Integrations;

use Etch\DynamicData\Helpers\ImageFormatter;

/**
 * Extends the Etch dynamic data for WooCommerce products.
 *
 * Hooks into etch/dynamic_data/post and injects a gallery_images property
 * built from the _product_image_gallery meta IDs, each formatted via ImageFormatter.
 */
class WoocommerceIntegration {

	/**
	 * Registers the filter when WooCommerce is active.
	 */
	public function __construct() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return;
		}
		add_filter( 'etch/dynamic_data/post', array( $this, 'add_gallery_images' ), 10, 2 );
	}

	/**
	 * Injects gallery_images into the dynamic data for WooCommerce product posts.
	 *
	 * @param array<string, mixed> $data    The current dynamic data array.
	 * @param int                  $post_id The post ID.
	 * @return array<string, mixed>
	 */
	public function add_gallery_images( array $data, int $post_id ): array {
		if ( get_post_type( $post_id ) !== 'product' ) {
			return $data;
		}

		$data['gallery_images'] = $this->build_gallery_images( $post_id );

		return $data;
	}

	/**
	 * Parses _product_image_gallery meta and returns formatted image arrays.
	 *
	 * @param int $post_id The product post ID.
	 * @return array<int, array<string, mixed>>
	 */
	private function build_gallery_images( int $post_id ): array {
		$gallery_meta = get_post_meta( $post_id, '_product_image_gallery', true );

		if ( ! is_string( $gallery_meta ) || '' === $gallery_meta ) {
			return array();
		}

		$images = array();
		foreach ( explode( ',', $gallery_meta ) as $raw ) {
			$id = (int) trim( $raw );
			if ( $id <= 0 ) {
				continue;
			}
			$image_data = ImageFormatter::format( $id );
			if ( ! empty( $image_data ) ) {
				$images[] = $image_data;
			}
		}

		return $images;
	}
}
