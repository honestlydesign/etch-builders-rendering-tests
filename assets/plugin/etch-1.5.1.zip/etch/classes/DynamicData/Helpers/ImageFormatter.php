<?php
/**
 * ImageFormatter
 *
 * @package Etch\DynamicData\Helpers
 */

declare(strict_types=1);

namespace Etch\DynamicData\Helpers;

/**
 * Formats attachment data into the standard Etch image array.
 *
 * Mirrors the logic of DynamicDataBases::get_base_image_data() so it can be
 * used outside trait-based classes. When this helper is well-tested, the
 * trait method can delegate here.
 */
class ImageFormatter {

	/**
	 * Build the standard Etch image array from an attachment ID or URL.
	 *
	 * @param string|int|false $image_input Attachment ID, image URL, or falsy value.
	 * @return array<string, mixed>
	 */
	public static function format( $image_input ): array {
		if ( empty( $image_input ) ) {
			return array();
		}

		if ( is_string( $image_input ) && ! is_numeric( $image_input ) ) {
			return self::format_url_string( $image_input );
		}

		return self::format_attachment( (int) $image_input );
	}

	/**
	 * Resolves a URL string to an attachment and formats it.
	 *
	 * Returns a basic array with only the URL when no attachment is found.
	 *
	 * @param string $url The image URL.
	 * @return array<string, mixed>
	 */
	private static function format_url_string( string $url ): array {
		$attachment_id = attachment_url_to_postid( $url );

		if ( ! $attachment_id ) {
			return array(
				'url'         => $url,
				'alt'         => '',
				'title'       => '',
				'caption'     => '',
				'description' => '',
				'sizes'       => array(),
				'srcset'      => '',
			);
		}

		return self::format_attachment( $attachment_id );
	}

	/**
	 * Formats a known attachment ID into the full Etch image array.
	 *
	 * @param int $attachment_id The attachment post ID.
	 * @return array<string, mixed>
	 */
	private static function format_attachment( int $attachment_id ): array {
		if ( $attachment_id <= 0 || ! wp_attachment_is_image( $attachment_id ) ) {
			return array();
		}

		$attachment = get_post( $attachment_id );
		if ( ! $attachment ) {
			return array();
		}

		$metadata   = wp_get_attachment_metadata( $attachment_id );
		$alt_text   = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
		$full_image = wp_get_attachment_image_src( $attachment_id, 'full' );
		$main_url   = $full_image ? $full_image[0] : '';
		$srcset     = wp_get_attachment_image_srcset( $attachment_id );

		return array(
			'id'          => $attachment_id,
			'url'         => $main_url,
			'alt'         => $alt_text ? $alt_text : '',
			'title'       => $attachment->post_title ? $attachment->post_title : '',
			'caption'     => $attachment->post_excerpt ? $attachment->post_excerpt : '',
			'description' => $attachment->post_content ? $attachment->post_content : '',
			'filename'    => basename( $main_url ),
			'sizes'       => self::build_sizes( $attachment_id ),
			'srcset'      => $srcset ? $srcset : '',
			'width'       => $metadata['width'] ?? 0,
			'height'      => $metadata['height'] ?? 0,
			'filesize'    => $metadata['filesize'] ?? 0,
			'mime_type'   => get_post_mime_type( $attachment_id ) ? get_post_mime_type( $attachment_id ) : '',
		);
	}

	/**
	 * Builds the sizes array for all registered image sizes plus full.
	 *
	 * @param int $attachment_id The attachment post ID.
	 * @return array<string, array<string, mixed>>
	 */
	private static function build_sizes( int $attachment_id ): array {
		$sizes         = array();
		$image_sizes   = get_intermediate_image_sizes();
		$image_sizes[] = 'full';

		foreach ( $image_sizes as $size ) {
			$image_src = wp_get_attachment_image_src( $attachment_id, $size );
			if ( $image_src ) {
				$sizes[ $size ] = array(
					'url'    => $image_src[0],
					'width'  => $image_src[1],
					'height' => $image_src[2],
				);
			}
		}

		return $sizes;
	}
}
