<?php
/**
 * IntegrationsMetadataService.php
 *
 * Resolves integration metadata that can be forwarded to middleware.
 *
 * PHP version 8.2+
 *
 * @category  Plugin
 * @package   Etch\Services
 */

declare(strict_types=1);

namespace Etch\Services;

use Etch\Helpers\Flag;

/**
 * IntegrationsMetadataService
 *
 * @package Etch\Services
 */
class IntegrationsMetadataService {

	/**
	 * Whether ACSS metadata is enabled for middleware payloads.
	 *
	 * @var bool
	 */
	private bool $acss_metadata_enabled;

	/**
	 * Constructor.
	 *
	 * @param bool|null $acss_metadata_enabled Whether ACSS metadata is enabled.
	 */
	public function __construct( ?bool $acss_metadata_enabled = null ) {
		$this->acss_metadata_enabled = $acss_metadata_enabled ?? Flag::is_on( 'ENABLE_AI_ACSS_METADATA' );
	}

	/**
	 * Build integrations metadata for middleware payloads.
	 *
	 * @return array<string, mixed>|null
	 */
	public function for_middleware_payload(): ?array {
		if ( ! $this->acss_metadata_enabled ) {
			return null;
		}

		$metadata = array();

		$acss_metadata = $this->resolve_acss_metadata();
		if ( null !== $acss_metadata ) {
			$metadata['acss'] = $acss_metadata;
		}

		if ( array() === $metadata ) {
			return null;
		}

		return $metadata;
	}

	/**
	 * Resolve ACSS integration metadata when ACSS is active and version is semver.
	 *
	 * @return array{version: string}|null
	 */
	private function resolve_acss_metadata(): ?array {
		if ( ! function_exists( 'is_plugin_active' ) || ! function_exists( 'get_plugin_data' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugin_relative_path = $this->resolve_active_acss_plugin_relative_path();
		if ( null === $plugin_relative_path ) {
			return null;
		}

		$plugin_file = trailingslashit( WP_PLUGIN_DIR ) . $plugin_relative_path;
		if ( ! file_exists( $plugin_file ) ) {
			return null;
		}

		$plugin_data = get_plugin_data( $plugin_file, false, false );
		$version = trim( $plugin_data['Version'] );

		if ( '' === $version || ! $this->is_semver( $version ) ) {
			return null;
		}

		return array( 'version' => $version );
	}

	/**
	 * Resolve the active ACSS plugin basename from currently active plugins.
	 *
	 * @return string|null Plugin basename relative to WP_PLUGIN_DIR or null when ACSS is not active.
	 */
	private function resolve_active_acss_plugin_relative_path(): ?string {
		if ( ! $this->can_read_active_plugins() ) {
			return null;
		}

		foreach ( $this->get_all_active_plugin_relative_paths() as $plugin_relative_path ) {
			$plugin_name = $this->read_plugin_name( $plugin_relative_path );
			if ( null === $plugin_name ) {
				continue;
			}

			if ( $this->is_acss_plugin_name( $plugin_name ) ) {
				return $plugin_relative_path;
			}
		}

		return null;
	}

	/**
	 * Check whether required WP functions for reading active plugins are available.
	 *
	 * @return bool
	 */
	private function can_read_active_plugins(): bool {
		return function_exists( 'get_option' )
			&& function_exists( 'get_site_option' )
			&& function_exists( 'get_plugin_data' );
	}

	/**
	 * Return all active plugin basenames (site + network).
	 *
	 * @return array<int, string>
	 */
	private function get_all_active_plugin_relative_paths(): array {
		$active_plugins = get_option( 'active_plugins', array() );
		if ( ! is_array( $active_plugins ) ) {
			$active_plugins = array();
		}

		$network_active_plugins = get_site_option( 'active_sitewide_plugins', array() );
		if ( ! is_array( $network_active_plugins ) ) {
			$network_active_plugins = array();
		}

		$all_active_plugins = array_merge( $active_plugins, array_keys( $network_active_plugins ) );

		$sanitized = array();
		foreach ( $all_active_plugins as $plugin_relative_path ) {
			if ( is_string( $plugin_relative_path ) && '' !== $plugin_relative_path ) {
				$sanitized[] = $plugin_relative_path;
			}
		}

		return $sanitized;
	}

	/**
	 * Read a plugin Name header by plugin relative path.
	 *
	 * @param string $plugin_relative_path Plugin basename relative to WP_PLUGIN_DIR.
	 * @return string|null
	 */
	private function read_plugin_name( string $plugin_relative_path ): ?string {
		$plugin_file = trailingslashit( WP_PLUGIN_DIR ) . $plugin_relative_path;
		if ( ! file_exists( $plugin_file ) ) {
			return null;
		}

		$plugin_data = get_plugin_data( $plugin_file, false, false );
		return $plugin_data['Name'];
	}

	/**
	 * Check if a plugin Name header belongs to ACSS.
	 *
	 * @param string $plugin_name Plugin Name header.
	 * @return bool
	 */
	private function is_acss_plugin_name( string $plugin_name ): bool {
		return 'automatic.css' === strtolower( trim( $plugin_name ) );
	}

	/**
	 * Validate that a version string follows semver (with optional pre-release/build metadata).
	 *
	 * @param string $version Version string to validate.
	 * @return bool
	 */
	private function is_semver( string $version ): bool {
		return 1 === preg_match( '/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?(?:\+[0-9A-Za-z.-]+)?$/', $version );
	}
}
