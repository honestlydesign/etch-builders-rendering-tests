<?php
/**
 * FindPostsQuerySpec.php
 *
 * @package Etch
 */

declare(strict_types=1);

namespace Etch\Services;

use WP_Post_Type;

/**
 * Query spec for one grouped post-search bucket.
 */
final class FindPostsQuerySpec {

	/**
	 * Constructor.
	 *
	 * @param WP_Post_Type     $post_type Searchable post type object.
	 * @param FindPostsRequest $request Parsed grouped-search request.
	 */
	public function __construct(
		public readonly WP_Post_Type $post_type,
		public readonly FindPostsRequest $request
	) {}

	/**
	 * Get the result limit.
	 *
	 * @return int
	 */
	public function limit(): int {
		return $this->request->limit;
	}

	/**
	 * Get the title filter.
	 *
	 * @return string
	 */
	public function title(): string {
		return $this->request->title;
	}

	/**
	 * Get the slug filter.
	 *
	 * @return string
	 */
	public function slug(): string {
		return $this->request->slug;
	}

	/**
	 * Whether this query spec has active filters.
	 *
	 * @return bool
	 */
	public function should_filter(): bool {
		return $this->request->is_filtered();
	}

	/**
	 * Whether the query should include found rows.
	 *
	 * @return bool
	 */
	public function include_found_rows(): bool {
		return $this->request->is_filtered();
	}

	/**
	 * Get the post type slug.
	 *
	 * @return string
	 */
	public function post_type_name(): string {
		return $this->post_type->name;
	}
}
