<?php
/**
 * OpenAiStreamEventProcessor.php
 *
 * Routes decoded OpenAI streaming events to the appropriate callbacks.
 *
 * @package Etch\Services\Ai\AgentProviders
 */

declare(strict_types=1);

namespace Etch\Services\Ai\AgentProviders;

use Etch\Helpers\WideEventLogger;

/**
 * OpenAiStreamEventProcessor
 *
 * @package Etch\Services\Ai\AgentProviders
 */
class OpenAiStreamEventProcessor {

	/**
	 * Tracks text segments that already emitted deltas.
	 *
	 * @var array<string, true>
	 */
	private array $seen_text_segments = array();

	/**
	 * Tracks reasoning summary segments that already emitted deltas.
	 *
	 * @var array<string, true>
	 */
	private array $seen_reasoning_segments = array();

	/**
	 * Process a streaming event from OpenAI.
	 *
	 * @param array<string, mixed> $event     The decoded event.
	 * @param array                $callbacks Callbacks keyed on_delta (required), on_error, on_reasoning, on_response_completed, on_client_tool_calls.
	 *
	 * @phpstan-param array{on_delta: callable, on_error?: callable|null, on_reasoning?: callable|null, on_response_completed?: callable|null, on_client_tool_calls?: callable|null} $callbacks
	 *
	 * @return void
	 */
	public function process( array $event, array $callbacks ): void {
		$callbacks = $this->normalize_callbacks( $callbacks );
		$type      = is_string( $event['type'] ?? null ) ? $event['type'] : '';

		$this->maybe_log_response_meta( $type );

		$handler = $this->resolve_handler( $type );
		if ( null === $handler ) {
			return;
		}

		$callback_key = $handler['callback_key'];
		$method       = $handler['method'];
		$this->$method( $event, $callbacks[ $callback_key ] );
	}

	/**
	 * Normalize a callbacks array, returning null for absent or unset optional entries.
	 *
	 * @param array $callbacks Incoming callbacks array.
	 *
	 * @phpstan-param array{on_delta: callable, on_error?: callable|null, on_reasoning?: callable|null, on_response_completed?: callable|null, on_client_tool_calls?: callable|null} $callbacks
	 * @phpstan-return array{on_delta: callable, on_error: callable|null, on_reasoning: callable|null, on_response_completed: callable|null, on_client_tool_calls: callable|null}
	 *
	 * @return array
	 */
	private function normalize_callbacks( array $callbacks ): array {
		return array(
			'on_delta'              => $callbacks['on_delta'],
			'on_error'              => $callbacks['on_error'] ?? null,
			'on_reasoning'          => $callbacks['on_reasoning'] ?? null,
			'on_response_completed' => $callbacks['on_response_completed'] ?? null,
			'on_client_tool_calls'  => $callbacks['on_client_tool_calls'] ?? null,
		);
	}

	/**
	 * Log middleware metadata events until the transport is fully covered by tests.
	 *
	 * @param string $type Event type.
	 *
	 * @return void
	 */
	private function maybe_log_response_meta( string $type ): void {
		if ( 'response.meta' === $type ) {
			WideEventLogger::set( 'ai.response.source', 'middleware' );
		}
	}

	/**
	 * Resolve an event type to the handler method and callback key.
	 *
	 * @param string $type Event type.
	 *
	 * @phpstan-return array{method: string, callback_key: string}|null
	 *
	 * @return array<string, string>|null
	 */
	private function resolve_handler( string $type ): ?array {
		$handlers = array(
			'response.output_text.delta'        => array(
				'method'       => 'handle_delta',
				'callback_key' => 'on_delta',
			),
			'response.output_text.done'         => array(
				'method'       => 'handle_text_done',
				'callback_key' => 'on_delta',
			),
			'response.reasoning_summary_text.delta' => array(
				'method'       => 'handle_reasoning_delta',
				'callback_key' => 'on_reasoning',
			),
			'response.reasoning_summary_text.done' => array(
				'method'       => 'handle_reasoning_done_event',
				'callback_key' => 'on_reasoning',
			),
			'response.completed'               => array(
				'method'       => 'handle_completed',
				'callback_key' => 'on_response_completed',
			),
			'etch.client_tool_calls'           => array(
				'method'       => 'handle_client_tool_calls',
				'callback_key' => 'on_client_tool_calls',
			),
			'response.error'                   => array(
				'method'       => 'handle_error',
				'callback_key' => 'on_error',
			),
			'error'                            => array(
				'method'       => 'handle_error',
				'callback_key' => 'on_error',
			),
		);

		return $handlers[ $type ] ?? null;
	}

	/**
	 * Handle a text output delta event.
	 *
	 * @param array<string, mixed> $event    The decoded event.
	 * @param callable             $on_delta Callback for text deltas.
	 *
	 * @return void
	 */
	private function handle_delta( array $event, callable $on_delta ): void {
		$delta = $this->extract_delta( $event );
		if ( null !== $delta ) {
			$this->mark_text_segment_seen( $event );
			$on_delta( $delta );
		}
	}

	/**
	 * Handle a finalized text output event.
	 *
	 * @param array<string, mixed> $event    The decoded event.
	 * @param callable             $on_delta Callback for text deltas.
	 *
	 * @return void
	 */
	private function handle_text_done( array $event, callable $on_delta ): void {
		$text = $this->extract_text( $event );
		$segment_key = $this->build_segment_key( $event, 'content_index' );

		if ( ! $this->should_forward_done_text( $text, $segment_key, $this->seen_text_segments ) ) {
			return;
		}

		$this->mark_segment_seen( $this->seen_text_segments, $segment_key );
		$on_delta( $text );
	}

	/**
	 * Handle a reasoning summary delta event.
	 *
	 * @param array<string, mixed> $event        The decoded event.
	 * @param callable|null        $on_reasoning Callback for reasoning deltas.
	 *
	 * @return void
	 */
	private function handle_reasoning_delta( array $event, ?callable $on_reasoning ): void {
		if ( null === $on_reasoning ) {
			return;
		}

		$delta = $this->extract_delta( $event );
		if ( null !== $delta ) {
			$this->mark_reasoning_segment_seen( $event );
			$on_reasoning( $delta );
		}
	}

	/**
	 * Handle a reasoning summary done event.
	 *
	 * @param callable|null $on_reasoning Callback for reasoning completion.
	 *
	 * @return void
	 */
	private function handle_reasoning_done( ?callable $on_reasoning ): void {
		if ( null !== $on_reasoning ) {
			$on_reasoning( null );
		}
	}

	/**
	 * Handle a reasoning summary done event, salvaging finalized reasoning text when
	 * the provider skipped delta events for the same summary segment.
	 *
	 * @param array<string, mixed> $event        The decoded event.
	 * @param callable|null        $on_reasoning Callback for reasoning completion.
	 *
	 * @return void
	 */
	private function handle_reasoning_done_event( array $event, ?callable $on_reasoning ): void {
		if ( null === $on_reasoning ) {
			return;
		}

		$segment_key = $this->build_segment_key( $event, 'summary_index' );
		$text        = $this->extract_text( $event );

		if ( $this->should_forward_done_text( $text, $segment_key, $this->seen_reasoning_segments ) ) {
			$this->mark_segment_seen( $this->seen_reasoning_segments, $segment_key );
			$on_reasoning( $text );
		}

		$this->handle_reasoning_done( $on_reasoning );
	}

	/**
	 * Handle a response completed event.
	 *
	 * @param array<string, mixed> $event                 The decoded event.
	 * @param callable|null        $on_response_completed Callback for response completion.
	 *
	 * @return void
	 */
	private function handle_completed( array $event, ?callable $on_response_completed ): void {
		if ( null === $on_response_completed ) {
			return;
		}

		$response = $event['response'] ?? null;
		if ( is_array( $response ) ) {
			$on_response_completed( $response );
		}
	}

	/**
	 * Forward etch.client_tool_calls events to the consumer.
	 *
	 * @param array<string, mixed> $event                Decoded SSE data.
	 * @param callable|null        $on_client_tool_calls Optional callback.
	 *
	 * @return void
	 */
	private function handle_client_tool_calls( array $event, ?callable $on_client_tool_calls ): void {
		if ( null === $on_client_tool_calls ) {
			return;
		}

		$on_client_tool_calls( $event );
	}

	/**
	 * Handle an error event.
	 *
	 * @param array<string, mixed> $event    The decoded event.
	 * @param callable|null        $on_error Callback for errors.
	 *
	 * @return void
	 */
	private function handle_error( array $event, ?callable $on_error ): void {
		if ( null !== $on_error ) {
			$on_error( $event );
		}
	}

	/**
	 * Extract a non-empty string delta from an event, or return null.
	 *
	 * @param array<string, mixed> $event The decoded event.
	 *
	 * @return string|null The delta string, or null if absent or empty.
	 */
	private function extract_delta( array $event ): ?string {
		$delta = $event['delta'] ?? null;

		if ( is_string( $delta ) && '' !== $delta ) {
			return $delta;
		}

		return null;
	}

	/**
	 * Extract a non-empty finalized text value from an event, or return null.
	 *
	 * @param array<string, mixed> $event The decoded event.
	 *
	 * @return string|null
	 */
	private function extract_text( array $event ): ?string {
		$text = $event['text'] ?? null;

		if ( is_string( $text ) && '' !== $text ) {
			return $text;
		}

		return null;
	}

	/**
	 * Mark a streamed text segment as seen when delta events arrive.
	 *
	 * @param array<string, mixed> $event The decoded event.
	 *
	 * @return void
	 */
	private function mark_text_segment_seen( array $event ): void {
		$segment_key = $this->build_segment_key( $event, 'content_index' );
		$this->mark_segment_seen( $this->seen_text_segments, $segment_key );
	}

	/**
	 * Mark a streamed reasoning segment as seen when delta events arrive.
	 *
	 * @param array<string, mixed> $event The decoded event.
	 *
	 * @return void
	 */
	private function mark_reasoning_segment_seen( array $event ): void {
		$segment_key = $this->build_segment_key( $event, 'summary_index' );
		$this->mark_segment_seen( $this->seen_reasoning_segments, $segment_key );
	}

	/**
	 * Decide whether finalized text should be forwarded for a segment.
	 *
	 * @param string|null         $text        Finalized text from the event.
	 * @param string|null         $segment_key Stable segment key when available.
	 * @param array<string, true> $seen_map    Already-streamed segments.
	 *
	 * @return bool
	 */
	private function should_forward_done_text( ?string $text, ?string $segment_key, array $seen_map ): bool {
		if ( null === $text ) {
			return false;
		}

		return ! $this->segment_has_been_seen( $seen_map, $segment_key );
	}

	/**
	 * Check whether a segment already emitted streaming content.
	 *
	 * @param array<string, true> $seen_map    Already-streamed segments.
	 * @param string|null         $segment_key Stable segment key when available.
	 *
	 * @return bool
	 */
	private function segment_has_been_seen( array $seen_map, ?string $segment_key ): bool {
		return null !== $segment_key && isset( $seen_map[ $segment_key ] );
	}

	/**
	 * Mark a segment as having emitted streaming content.
	 *
	 * @param array<string, true> $seen_map    Already-streamed segments.
	 * @param string|null         $segment_key Stable segment key when available.
	 *
	 * @return void
	 */
	private function mark_segment_seen( array &$seen_map, ?string $segment_key ): void {
		if ( null !== $segment_key ) {
			$seen_map[ $segment_key ] = true;
		}
	}

	/**
	 * Build a stable segment key from item and segment indexes.
	 *
	 * @param array<string, mixed> $event      The decoded event.
	 * @param string               $index_name The segment index field name.
	 *
	 * @return string|null
	 */
	private function build_segment_key( array $event, string $index_name ): ?string {
		$item_id = $event['item_id'] ?? null;
		$index   = $event[ $index_name ] ?? null;

		if ( ! is_string( $item_id ) || ! is_int( $index ) ) {
			return null;
		}

		return $item_id . ':' . $index_name . ':' . (string) $index;
	}
}
