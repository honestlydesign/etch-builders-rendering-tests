<?php
/**
 * OpenAiStreamEventProcessorTest.php
 *
 * @package Etch
 */

declare(strict_types=1);

namespace Etch\Services\Ai\Tests;

use Etch\Services\Ai\AgentProviders\OpenAiStreamEventProcessor;
use WP_UnitTestCase;

/**
 * Class OpenAiStreamEventProcessorTest
 *
 * Tests the OpenAiStreamEventProcessor class.
 */
class OpenAiStreamEventProcessorTest extends WP_UnitTestCase {

	/**
	 * Test that text output is collected as expected for each stream shape.
	 *
	 * @param array<int, array<string, mixed>> $events   Events to process in order.
	 * @param array<int, string>               $expected Expected text output.
	 *
	 * @dataProvider text_output_cases
	 */
	public function test_text_output_is_collected_as_expected( array $events, array $expected ): void {
		$received = $this->collect_output( 'on_delta', ...$events );

		$this->assertSame( $expected, $received );
	}

	/**
	 * Data provider for text output collection scenarios.
	 *
	 * @return array<string, array{events: array<int, array<string, mixed>>, expected: array<int, string>}>
	 */
	public static function text_output_cases(): array {
		return array(
			'delta when text delta event received' => array(
				'events'   => array(
					array(
						'type'  => 'response.output_text.delta',
						'delta' => 'Hello world',
					),
				),
				'expected' => array( 'Hello world' ),
			),
			'empty when text delta has empty string' => array(
				'events'   => array(
					array(
						'type'  => 'response.output_text.delta',
						'delta' => '',
					),
				),
				'expected' => array(),
			),
			'finalized text when no text deltas were streamed' => array(
				'events'   => array(
					array(
						'type'          => 'response.output_text.done',
						'item_id'       => 'msg_1',
						'content_index' => 0,
						'text'          => 'Hello world',
					),
				),
				'expected' => array( 'Hello world' ),
			),
			'no duplicate when same text segment already streamed via delta' => array(
				'events'   => array(
					array(
						'type'          => 'response.output_text.delta',
						'item_id'       => 'msg_1',
						'content_index' => 0,
						'delta'         => 'Hello',
					),
					array(
						'type'          => 'response.output_text.done',
						'item_id'       => 'msg_1',
						'content_index' => 0,
						'text'          => 'Hello',
					),
				),
				'expected' => array( 'Hello' ),
			),
			'finalized text when prior delta for same segment is empty' => array(
				'events'   => array(
					array(
						'type'          => 'response.output_text.delta',
						'item_id'       => 'msg_1',
						'content_index' => 0,
						'delta'         => '',
					),
					array(
						'type'          => 'response.output_text.done',
						'item_id'       => 'msg_1',
						'content_index' => 0,
						'text'          => 'Hello',
					),
				),
				'expected' => array( 'Hello' ),
			),
		);
	}

	/**
	 * Test that reasoning output is collected as expected for each stream shape.
	 *
	 * @param array<int, array<string, mixed>> $events   Events to process in order.
	 * @param array<int, string|null>          $expected Expected reasoning output.
	 *
	 * @dataProvider reasoning_output_cases
	 */
	public function test_reasoning_output_is_collected_as_expected( array $events, array $expected ): void {
		$received = $this->collect_output( 'on_reasoning', ...$events );

		$this->assertSame( $expected, $received );
	}

	/**
	 * Data provider for reasoning output collection scenarios.
	 *
	 * @return array<string, array{events: array<int, array<string, mixed>>, expected: array<int, string|null>}>
	 */
	public static function reasoning_output_cases(): array {
		return array(
			'reasoning delta when reasoning delta event received' => array(
				'events'   => array(
					array(
						'type'  => 'response.reasoning_summary_text.delta',
						'delta' => 'Thinking',
					),
				),
				'expected' => array( 'Thinking' ),
			),
			'null when reasoning done event received without text' => array(
				'events'   => array(
					array( 'type' => 'response.reasoning_summary_text.done' ),
				),
				'expected' => array( null ),
			),
			'finalized reasoning text before completion marker' => array(
				'events'   => array(
					array(
						'type'          => 'response.reasoning_summary_text.done',
						'item_id'       => 'rs_1',
						'summary_index' => 0,
						'text'          => 'Thinking',
					),
				),
				'expected' => array( 'Thinking', null ),
			),
			'no duplicate when reasoning delta already streamed for same segment' => array(
				'events'   => array(
					array(
						'type'          => 'response.reasoning_summary_text.delta',
						'item_id'       => 'rs_1',
						'summary_index' => 0,
						'delta'         => 'Thinking',
					),
					array(
						'type'          => 'response.reasoning_summary_text.done',
						'item_id'       => 'rs_1',
						'summary_index' => 0,
						'text'          => 'Thinking',
					),
				),
				'expected' => array( 'Thinking', null ),
			),
		);
	}

	/**
	 * Test that response is captured when response completed event received.
	 */
	public function test_response_is_captured_when_response_completed_event_received(): void {
		$processor = new OpenAiStreamEventProcessor();
		$received = array();

		$response_data = array(
			'id'     => 'resp_123',
			'output' => array(
				array(
					'type'      => 'function_call',
					'call_id'   => 'call_1',
					'name'      => 'rag_search',
					'arguments' => '{"query":"test"}',
				),
			),
		);

		$processor->process(
			array(
				'type'     => 'response.completed',
				'response' => $response_data,
			),
			array(
				'on_delta'              => function () {},
				'on_response_completed' => function ( array $response ) use ( &$received ) {
					$received[] = $response;
				},
			)
		);

		$this->assertSame( array( $response_data ), $received );
	}

	/**
	 * Test that on_error is called when error event received.
	 */
	public function test_on_error_is_called_when_error_event_received(): void {
		$processor = new OpenAiStreamEventProcessor();
		$received = array();

		$event = array(
			'type'  => 'response.error',
			'error' => array( 'message' => 'API error' ),
		);

		$processor->process(
			$event,
			array(
				'on_delta'  => function () {},
				'on_error'  => function ( $error ) use ( &$received ) {
					$received[] = $error;
				},
			)
		);

		$this->assertSame( array( $event ), $received );
	}

	/**
	 * Collect callback output emitted while processing a sequence of events.
	 *
	 * @param string               $callback_key Callback key to collect.
	 * @param array<string, mixed> ...$events     Events to process in order.
	 *
	 * @return array<int, string|null>
	 */
	private function collect_output( string $callback_key, array ...$events ): array {
		$received = array();
		$callbacks = array(
			'on_delta' => function () {},
		);

		if ( 'on_delta' === $callback_key ) {
			$callbacks['on_delta'] = function ( string $delta ) use ( &$received ) {
				$received[] = $delta;
			};
		} else {
			$callbacks['on_reasoning'] = function ( ?string $reasoning ) use ( &$received ) {
				$received[] = $reasoning;
			};
		}

		$this->process_events( $events, $callbacks );

		return $received;
	}

	/**
	 * Process a sequence of events through a fresh processor instance.
	 *
	 * @param array<int, array<string, mixed>> $events    Events to process in order.
	 * @param array<string, callable>          $callbacks Callbacks for processor output.
	 *
	 * @return void
	 */
	private function process_events( array $events, array $callbacks ): void {
		$processor = new OpenAiStreamEventProcessor();

		foreach ( $events as $event ) {
			$processor->process( $event, $callbacks );
		}
	}
}
