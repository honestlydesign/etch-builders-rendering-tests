<?php
/**
 * FindPostsRequest.php
 *
 * @package Etch
 */

declare(strict_types=1);

namespace Etch\Services;

/**
 * Parsed request for grouped post search.
 */
final class FindPostsRequest {

	/**
	 * Constructor.
	 *
	 * @param string      $title Title needle.
	 * @param string      $slug Slug needle.
	 * @param string|null $requested_post_type Requested post type.
	 * @param int         $limit Result limit.
	 */
	public function __construct(
		public readonly string $title,
		public readonly string $slug,
		public readonly ?string $requested_post_type,
		public readonly int $limit
	) {}

	/**
	 * Create a parsed request from raw route arguments.
	 *
	 * @param array{title?: string, slug?: string, post_type?: string, limit?: int} $args Search arguments.
	 * @return self
	 */
	public static function from_array( array $args ): self {
		return new self(
			isset( $args['title'] ) ? trim( (string) $args['title'] ) : '',
			isset( $args['slug'] ) ? trim( (string) $args['slug'] ) : '',
			isset( $args['post_type'] ) ? (string) $args['post_type'] : null,
			isset( $args['limit'] ) ? max( 1, (int) $args['limit'] ) : 10
		);
	}

	/**
	 * Whether any search filters are active.
	 *
	 * @return bool
	 */
	public function is_filtered(): bool {
		return '' !== $this->title || '' !== $this->slug;
	}
}
