<?php
/**
 * FindPostsService.php
 *
 * @package Etch
 */

declare(strict_types=1);

namespace Etch\Services;

use WP_Error;
use WP_Post;
use WP_Post_Type;
use WP_Query;

/**
 * Grouped post search for AI tooling.
 */
class FindPostsService {

	/**
	 * Find posts grouped by post type.
	 *
	 * @param array{title?: string, slug?: string, post_type?: string, limit?: int} $args Search arguments.
	 * @return array<int, array{post_type: string, totalPosts: int, matches?: int, posts: array<int, array{id: int, title: string, slug: string}>}>|WP_Error
	 */
	public function find_posts( array $args ): array|WP_Error {
		$request = FindPostsRequest::from_array( $args );

		$searchable_post_types = $this->get_searchable_post_types( $request->requested_post_type );
		if ( $searchable_post_types instanceof WP_Error ) {
			return $searchable_post_types;
		}

		$results = array();

		foreach ( $searchable_post_types as $searchable_post_type ) {
			$total_posts = $this->count_searchable_posts( $searchable_post_type );
			$query_spec  = new FindPostsQuerySpec( $searchable_post_type, $request );

			if ( ! $request->is_filtered() ) {
				$query = $this->run_posts_query_for_type( $query_spec );
				$results[] = $this->build_bucket(
					$query_spec,
					$total_posts,
					null,
					$this->extract_posts( $query )
				);

				continue;
			}

			$query = $this->run_posts_query_for_type( $query_spec );
			$results[] = $this->build_bucket(
				$query_spec,
				$total_posts,
				(int) $query->found_posts,
				$this->extract_posts( $query )
			);
		}

		return $results;
	}

	/**
	 * Resolve searchable post types.
	 *
	 * @param string|null $requested_post_type Optional explicit post type.
	 * @return array<int, WP_Post_Type>|WP_Error
	 */
	private function get_searchable_post_types( ?string $requested_post_type ): array|WP_Error {
		$post_types = get_post_types( array( 'public' => true ), 'objects' );

		$searchable_post_types = array_filter(
			$post_types,
			static function ( $post_type ): bool {
				return $post_type instanceof WP_Post_Type
					&& 'attachment' !== $post_type->name
					&& true === $post_type->show_in_rest
					&& true !== $post_type->exclude_from_search;
			}
		);

		uasort(
			$searchable_post_types,
			static fn( WP_Post_Type $a, WP_Post_Type $b ): int => strcmp( $a->name, $b->name )
		);

		if ( null === $requested_post_type || '' === $requested_post_type ) {
			return array_values( $searchable_post_types );
		}

		foreach ( $searchable_post_types as $post_type ) {
			if ( $post_type->name === $requested_post_type ) {
				return array( $post_type );
			}
		}

		return new WP_Error(
			'invalid_post_type',
			'Invalid or unsupported post type specified.',
			array( 'status' => 400 )
		);
	}

	/**
	 * Count searchable posts for a post type.
	 *
	 * @param WP_Post_Type $post_type Searchable post type object.
	 * @return int
	 */
	private function count_searchable_posts( WP_Post_Type $post_type ): int {
		$counts = wp_count_posts( $post_type->name );
		// totalPosts is intentionally the tool-visible draft+publish population.
		return (int) ( $counts->draft ?? 0 ) + (int) ( $counts->publish ?? 0 );
	}

	/**
	 * Build a result bucket.
	 *
	 * @param FindPostsQuerySpec  $query_spec Query spec for this bucket.
	 * @param int                 $total_posts Total posts in this type.
	 * @param int|null            $matches Optional exact match count.
	 * @param array<int, WP_Post> $posts Posts to return.
	 * @return array{post_type: string, totalPosts: int, matches?: int, posts: array<int, array{id: int, title: string, slug: string}>}
	 */
	private function build_bucket( FindPostsQuerySpec $query_spec, int $total_posts, ?int $matches, array $posts ): array {
		$bucket = array(
			'post_type'  => $query_spec->post_type_name(),
			'totalPosts' => $total_posts,
		);

		if ( null !== $matches ) {
			$bucket['matches'] = $matches;
		}

		$bucket['posts'] = array();

		foreach ( $posts as $post ) {
			$bucket['posts'][] = array(
				'id'    => $post->ID,
				'title' => $post->post_title,
				'slug'  => $post->post_name,
			);
		}

		return $bucket;
	}

	/**
	 * Extract typed posts from a WP_Query result.
	 *
	 * @param WP_Query $query Query result.
	 * @return array<int, WP_Post>
	 */
	private function extract_posts( WP_Query $query ): array {
		return array_values(
			array_filter(
				$query->posts,
				static fn( $post ): bool => $post instanceof WP_Post
			)
		);
	}

	/**
	 * Run a posts query for one searchable post type.
	 *
	 * @param FindPostsQuerySpec $query_spec Query spec.
	 * @return WP_Query
	 */
	private function run_posts_query_for_type( FindPostsQuerySpec $query_spec ): WP_Query {
		$filter = function ( string $where, WP_Query $query ) use ( $query_spec ): string {
			if ( ! $query->get( 'etch_find_posts_enabled' ) ) {
				return $where;
			}

			global $wpdb;

			if ( '' !== $query_spec->title() ) {
				$where .= $wpdb->prepare(
					" AND {$wpdb->posts}.post_title LIKE %s",
					'%' . $wpdb->esc_like( $query_spec->title() ) . '%'
				);
			}

			if ( '' !== $query_spec->slug() ) {
				$where .= $wpdb->prepare(
					" AND {$wpdb->posts}.post_name LIKE %s",
					'%' . $wpdb->esc_like( $query_spec->slug() ) . '%'
				);
			}

			return $where;
		};

		if ( $query_spec->should_filter() ) {
			// Scoped by query flag and always removed in finally.
			add_filter( 'posts_where', $filter, 10, 2 );
		}

		try {
			return new WP_Query(
				array(
					'post_type'               => $query_spec->post_type_name(),
					'post_status'             => array( 'draft', 'publish' ),
					'posts_per_page'          => $query_spec->limit(),
					'orderby'                 => 'date',
					'order'                   => 'DESC',
					'ignore_sticky_posts'     => true,
					'update_post_meta_cache'  => false,
					'update_post_term_cache'  => false,
					'no_found_rows'           => ! $query_spec->include_found_rows(),
					'etch_find_posts_enabled' => $query_spec->should_filter(),
				)
			);
		} finally {
			if ( $query_spec->should_filter() ) {
				remove_filter( 'posts_where', $filter, 10 );
			}
		}
	}
}
