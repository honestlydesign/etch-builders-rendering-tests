<?php
/**
 * IntegrationsMetadataService.test.php
 *
 * @package Etch
 */

declare(strict_types=1);

namespace Etch\Services\Tests;

use Etch\Services\IntegrationsMetadataService;
use WP_UnitTestCase;

/**
 * Class IntegrationsMetadataServiceTest
 */
class IntegrationsMetadataServiceTest extends WP_UnitTestCase {

	/**
	 * Original active plugins option, saved before each test.
	 *
	 * @var mixed
	 */
	private $original_active_plugins;

	/**
	 * Temporary plugin file path when created in tests.
	 *
	 * @var string|null
	 */
	private ?string $temporary_plugin_file = null;

	/**
	 * Save options snapshot before each test.
	 */
	public function setUp(): void {
		parent::setUp();
		$this->original_active_plugins = get_option( 'active_plugins', array() );
	}

	/**
	 * Restore options snapshot after each test.
	 */
	protected function tearDown(): void {
		if ( null !== $this->temporary_plugin_file && file_exists( $this->temporary_plugin_file ) ) {
			unlink( $this->temporary_plugin_file );
			$plugin_dir = dirname( $this->temporary_plugin_file );
			if ( is_dir( $plugin_dir ) ) {
				rmdir( $plugin_dir );
			}
		}

		update_option( 'active_plugins', $this->original_active_plugins );
		parent::tearDown();
	}

	/**
	 * Test that null is returned when no supported integration is active.
	 */
	public function test_null_is_returned_when_no_supported_integration_is_active(): void {
		$service = new IntegrationsMetadataService();

		$result = $service->for_middleware_payload();

		$this->assertNull( $result );
	}

	/**
	 * Test that ACSS metadata is returned when ACSS plugin is active and semver is valid.
	 */
	public function test_acss_metadata_is_returned_when_acss_plugin_is_active_with_valid_semver(): void {
		$this->activate_fake_plugin( 'Automatic.css', '4.0.0-rc-3', 'automatic-css/automaticcss-plugin.php' );
		$service = new IntegrationsMetadataService( true );

		$result = $service->for_middleware_payload();

		$this->assertSame(
			array( 'acss' => array( 'version' => '4.0.0-rc-3' ) ),
			$result
		);
	}

	/**
	 * Test that ACSS metadata is returned when ACSS plugin is active with alternate basename.
	 */
	public function test_acss_metadata_is_returned_when_acss_plugin_uses_alternate_basename(): void {
		$this->activate_fake_plugin( 'Automatic.css', '4.0.1', 'acss/acss.php' );
		$service = new IntegrationsMetadataService( true );

		$result = $service->for_middleware_payload();

		$this->assertSame(
			array( 'acss' => array( 'version' => '4.0.1' ) ),
			$result
		);
	}

	/**
	 * Test that null is returned when ACSS metadata flag is off.
	 */
	public function test_null_is_returned_when_acss_metadata_flag_is_off(): void {
		$this->activate_fake_plugin( 'Automatic.css', '4.0.0', 'automatic-css/automaticcss-plugin.php' );
		$service = new IntegrationsMetadataService( false );

		$result = $service->for_middleware_payload();

		$this->assertNull( $result );
	}

	/**
	 * Test that null is returned when ACSS version is not semver.
	 */
	public function test_null_is_returned_when_acss_version_is_not_semver(): void {
		$this->activate_fake_plugin( 'Automatic.css', 'version-four', 'automatic-css/automaticcss-plugin.php' );
		$service = new IntegrationsMetadataService( true );

		$result = $service->for_middleware_payload();

		$this->assertNull( $result );
	}

	/**
	 * Activate a temporary plugin by header name/version and mark it active.
	 *
	 * @param string $plugin_name          Plugin Name header value.
	 * @param string $plugin_version       Plugin Version header value.
	 * @param string $plugin_relative_path Plugin basename (relative to WP_PLUGIN_DIR).
	 * @return void
	 */
	private function activate_fake_plugin( string $plugin_name, string $plugin_version, string $plugin_relative_path ): void {
		$plugin_file      = WP_PLUGIN_DIR . DIRECTORY_SEPARATOR . $plugin_relative_path;
		$plugin_directory = dirname( $plugin_file );

		if ( ! is_dir( $plugin_directory ) ) {
			wp_mkdir_p( $plugin_directory );
		}

		$plugin_contents = "<?php\n/*\nPlugin Name: {$plugin_name}\nVersion: {$plugin_version}\n*/\n";
		file_put_contents( $plugin_file, $plugin_contents );
		$this->temporary_plugin_file = $plugin_file;

		$active_plugins = get_option( 'active_plugins', array() );
		if ( ! is_array( $active_plugins ) ) {
			$active_plugins = array();
		}

		if ( ! in_array( $plugin_relative_path, $active_plugins, true ) ) {
			$active_plugins[] = $plugin_relative_path;
		}

		update_option( 'active_plugins', $active_plugins );
	}
}
