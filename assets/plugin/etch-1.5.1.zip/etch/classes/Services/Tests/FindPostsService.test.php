<?php
/**
 * FindPostsServiceTest.php
 *
 * @package Etch
 */

declare(strict_types=1);

namespace Etch\Services\Tests;

use Etch\Services\FindPostsService;
use WP_UnitTestCase;

/**
 * Tests for FindPostsService.
 */
class FindPostsServiceTest extends WP_UnitTestCase {

	/**
	 * Set up searchable and non-searchable post types.
	 */
	public function setUp(): void {
		parent::setUp();

		register_post_type(
			'book',
			array(
				'label'        => 'Books',
				'public'       => true,
				'show_in_rest' => true,
			)
		);

		register_post_type(
			'private_note',
			array(
				'label'        => 'Private Notes',
				'public'       => true,
				'show_in_rest' => false,
			)
		);
	}

	/**
	 * Tear down registered post types.
	 */
	public function tearDown(): void {
		unregister_post_type( 'book' );
		unregister_post_type( 'private_note' );
		parent::tearDown();
	}

	/**
	 * Test latest posts grouped by searchable post type.
	 */
	public function test_latest_posts_are_grouped_by_searchable_post_type_when_no_filters_are_provided(): void {
		$this->factory()->post->create(
			array(
				'post_type'   => 'book',
				'post_status' => 'publish',
				'post_title'  => 'Book launch',
				'post_name'   => 'book-launch',
				'post_date'   => '2025-01-01 12:00:00',
			)
		);

		$this->factory()->post->create(
			array(
				'post_type'   => 'post',
				'post_status' => 'draft',
				'post_title'  => 'Hero post',
				'post_name'   => 'hero-post',
				'post_date'   => '2025-01-02 12:00:00',
			)
		);

		$this->factory()->post->create(
			array(
				'post_type'   => 'private_note',
				'post_status' => 'publish',
				'post_title'  => 'Hidden note',
				'post_name'   => 'hidden-note',
				'post_date'   => '2025-01-03 12:00:00',
			)
		);

		$service = new FindPostsService();

		$results = $service->find_posts(
			array(
				'limit' => 1,
			)
		);

		$this->assertIsArray( $results );
		$results_by_type = array_column( $results, null, 'post_type' );

		$this->assertArrayHasKey( 'book', $results_by_type );
		$this->assertArrayHasKey( 'post', $results_by_type );
		$this->assertArrayNotHasKey( 'private_note', $results_by_type );
		$this->assertSame( 'book-launch', $results_by_type['book']['posts'][0]['slug'] );
		$this->assertSame( 'hero-post', $results_by_type['post']['posts'][0]['slug'] );
	}

	/**
	 * Test title and slug filtering with AND semantics.
	 */
	public function test_matches_are_filtered_with_and_semantics_when_title_and_slug_are_provided(): void {
		$this->factory()->post->create(
			array(
				'post_type'   => 'book',
				'post_status' => 'publish',
				'post_title'  => 'Hero intro',
				'post_name'   => 'hero-intro',
				'post_date'   => '2025-01-01 12:00:00',
			)
		);

		$this->factory()->post->create(
			array(
				'post_type'   => 'book',
				'post_status' => 'draft',
				'post_title'  => 'Landing overview',
				'post_name'   => 'overview',
				'post_date'   => '2025-01-02 12:00:00',
			)
		);

		$matching_post_id = $this->factory()->post->create(
			array(
				'post_type'   => 'book',
				'post_status' => 'publish',
				'post_title'  => 'Hero landing',
				'post_name'   => 'hero-landing',
				'post_date'   => '2025-01-03 12:00:00',
			)
		);

		$service = new FindPostsService();

		$results = $service->find_posts(
			array(
				'post_type' => 'book',
				'title'     => 'hero',
				'slug'      => 'landing',
				'limit'     => 1,
			)
		);

		$this->assertSame(
			array(
				array(
					'post_type'  => 'book',
					'totalPosts' => 3,
					'matches'    => 1,
					'posts'      => array(
						array(
							'id'    => $matching_post_id,
							'title' => 'Hero landing',
							'slug'  => 'hero-landing',
						),
					),
				),
			),
			$results
		);
	}

	/**
	 * Test filtered results keep zero-match buckets for other searchable types.
	 */
	public function test_zero_match_buckets_are_preserved_when_filtering_across_searchable_post_types(): void {
		$matching_post_id = $this->factory()->post->create(
			array(
				'post_type'   => 'book',
				'post_status' => 'publish',
				'post_title'  => 'Hero landing',
				'post_name'   => 'hero-landing',
				'post_date'   => '2025-01-03 12:00:00',
			)
		);

		$this->factory()->post->create(
			array(
				'post_type'   => 'post',
				'post_status' => 'publish',
				'post_title'  => 'Regular post',
				'post_name'   => 'regular-post',
				'post_date'   => '2025-01-04 12:00:00',
			)
		);

		$service = new FindPostsService();

		$results = $service->find_posts(
			array(
				'title' => 'hero',
				'slug'  => 'landing',
				'limit' => 1,
			)
		);

		$this->assertIsArray( $results );
		$results_by_type = array_column( $results, null, 'post_type' );

		$this->assertSame(
			array(
				'post_type'  => 'book',
				'totalPosts' => 1,
				'matches'    => 1,
				'posts'      => array(
					array(
						'id'    => $matching_post_id,
						'title' => 'Hero landing',
						'slug'  => 'hero-landing',
					),
				),
			),
			$results_by_type['book']
		);
		$this->assertSame(
			array(
				'post_type'  => 'post',
				'totalPosts' => 1,
				'matches'    => 0,
				'posts'      => array(),
			),
			$results_by_type['post']
		);
	}

	/**
	 * Test exact matches count is preserved when result posts are limited.
	 */
	public function test_exact_matches_count_is_returned_when_filtered_results_exceed_limit(): void {
		$first_match_id = $this->factory()->post->create(
			array(
				'post_type'   => 'book',
				'post_status' => 'publish',
				'post_title'  => 'Hero landing one',
				'post_name'   => 'hero-landing-one',
				'post_date'   => '2025-01-01 12:00:00',
			)
		);

		$second_match_id = $this->factory()->post->create(
			array(
				'post_type'   => 'book',
				'post_status' => 'draft',
				'post_title'  => 'Hero landing two',
				'post_name'   => 'hero-landing-two',
				'post_date'   => '2025-01-02 12:00:00',
			)
		);

		$service = new FindPostsService();

		$results = $service->find_posts(
			array(
				'post_type' => 'book',
				'title'     => 'hero',
				'slug'      => 'landing',
				'limit'     => 1,
			)
		);

		$this->assertSame( 2, $results[0]['matches'] );
		$this->assertCount( 1, $results[0]['posts'] );
		$this->assertSame( $second_match_id, $results[0]['posts'][0]['id'] );
		$this->assertNotSame( $first_match_id, $results[0]['posts'][0]['id'] );
	}

	/**
	 * Test total posts still reflect all draft and publish posts when latest posts are limited.
	 */
	public function test_total_posts_reflect_all_draft_and_publish_posts_when_latest_posts_are_limited(): void {
		$this->factory()->post->create(
			array(
				'post_type'   => 'book',
				'post_status' => 'publish',
				'post_title'  => 'Oldest book',
				'post_name'   => 'oldest-book',
				'post_date'   => '2025-01-01 12:00:00',
			)
		);

		$this->factory()->post->create(
			array(
				'post_type'   => 'book',
				'post_status' => 'draft',
				'post_title'  => 'Newest book',
				'post_name'   => 'newest-book',
				'post_date'   => '2025-01-02 12:00:00',
			)
		);

		$service = new FindPostsService();

		$results = $service->find_posts(
			array(
				'post_type' => 'book',
				'limit'     => 1,
			)
		);

		$this->assertSame( 2, $results[0]['totalPosts'] );
		$this->assertCount( 1, $results[0]['posts'] );
		$this->assertSame( 'newest-book', $results[0]['posts'][0]['slug'] );
	}

	/**
	 * Test invalid post type returns an error.
	 */
	public function test_invalid_post_type_error_is_returned_when_requested_post_type_is_not_supported(): void {
		$service = new FindPostsService();

		$result = $service->find_posts(
			array(
				'post_type' => 'attachment',
			)
		);

		$this->assertWPError( $result );
		$this->assertSame( 'invalid_post_type', $result->get_error_code() );
		$this->assertSame( 400, $result->get_error_data()['status'] );
	}
}
