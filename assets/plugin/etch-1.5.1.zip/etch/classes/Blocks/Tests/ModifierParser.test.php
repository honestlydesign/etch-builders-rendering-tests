<?php
/**
 * Modifier parser test class.
 *
 * @package Etch
 */

declare(strict_types=1);

namespace Etch\Blocks\Tests;

use Etch\Blocks\Global\Utilities\ModifierParser;
use Etch\Blocks\Global\Utilities\Modifiers;
use WP_UnitTestCase;

/**
 * Class ModifierParserTest
 */
class ModifierParserTest extends WP_UnitTestCase {
	/**
	 * Test is_modifier returns true when modifier syntax is valid.
	 *
	 * @dataProvider provide_valid_modifier_syntax_cases
	 *
	 * @param string $modifier Modifier syntax under test.
	 */
	public function test_is_modifier_returns_true_when_modifier_syntax_is_valid( string $modifier ) {
		$this->assertTrue( ModifierParser::is_modifier( $modifier ) );
	}

	/**
	 * Test is_modifier returns false when modifier syntax is invalid.
	 *
	 * @dataProvider provide_invalid_modifier_syntax_cases
	 *
	 * @param string $modifier Invalid modifier syntax under test.
	 */
	public function test_is_modifier_returns_false_when_modifier_syntax_is_invalid( string $modifier ) {
		$this->assertFalse( ModifierParser::is_modifier( $modifier ) );
	}

	/**
	 * Test parse returns expected parts for the supplied modifier string.
	 *
	 * @dataProvider provide_parse_cases
	 *
	 * @param string               $modifier Modifier syntax under test.
	 * @param array<string,string> $expected Expected parsed parts.
	 */
	public function test_parse_returns_expected_parts_for_the_supplied_modifier_string( string $modifier, array $expected ) {
		$this->assertEquals( $expected, ModifierParser::parse( $modifier ) );
	}

	/**
	 * Test parse_modifier_arguments returns expected tokens for supported syntax.
	 *
	 * @dataProvider provide_parse_modifier_argument_cases
	 *
	 * @param string        $arguments Argument string under test.
	 * @param array<string> $expected Expected parsed arguments.
	 */
	public function test_parse_modifier_arguments_returns_expected_tokens_for_supported_syntax( string $arguments, array $expected ) {
		$this->assertEquals( $expected, Modifiers::parse_modifier_arguments( $arguments ) );
	}

	/**
	 * Provide valid modifier syntax cases.
	 *
	 * @return array<string, array{0:string}>
	 */
	public function provide_valid_modifier_syntax_cases(): array {
		return array(
			'recognizes format syntax' => array( 'format("Y-m-d")' ),
			'recognizes empty argument lists' => array( 'toUpperCase()' ),
		);
	}

	/**
	 * Provide invalid modifier syntax cases.
	 *
	 * @return array<string, array{0:string}>
	 */
	public function provide_invalid_modifier_syntax_cases(): array {
		return array(
			'rejects bare identifiers' => array( 'notAFunction' ),
			'rejects unclosed argument lists' => array( 'brokenFunc(123' ),
			'rejects hyphenated method names' => array( 'hyphen-method()' ),
		);
	}

	/**
	 * Provide parse cases.
	 *
	 * @return array<string, array{0:string,1:array<string,string>}>
	 */
	public function provide_parse_cases(): array {
		return array(
			'returns empty args when the modifier has no arguments' => array(
				'method()',
				array(
					'method' => 'method',
					'args'   => '',
				),
			),
			'trims outer whitespace before parsing' => array(
				'  format("Y-m-d")  ',
				array(
					'method' => 'format',
					'args'   => '"Y-m-d"',
				),
			),
			'returns empty parts when modifier syntax is invalid' => array(
				'not a modifier',
				array(
					'method' => '',
					'args'   => '',
				),
			),
		);
	}

	/**
	 * Provide parse_modifier_arguments cases.
	 *
	 * @return array<string, array{0:string,1:array<string>}>
	 */
	public function provide_parse_modifier_argument_cases(): array {
		return array(
			'parses double quoted arguments' => array(
				'2, ".", ","',
				array( '2', '"."', '","' ),
			),
			'parses single quoted arguments' => array(
				"2, '.', ','",
				array( '2', "'.'", "','" ),
			),
			'preserves spaces inside quoted arguments' => array(
				'2 , ". ", ", "',
				array( '2', '". "', '", "' ),
			),
			'preserves nested structures' => array(
				'$filter: {type: \'user\', tags: [\'admin\', \'active\']}, $limit: 10',
				array(
					'$filter: {type: \'user\', tags: [\'admin\', \'active\']}',
					'$limit: 10',
				),
			),
			'preserves commas inside strings' => array(
				'"arg1,with,commas", "arg2"',
				array(
					'"arg1,with,commas"',
					'"arg2"',
				),
			),
		);
	}
}
