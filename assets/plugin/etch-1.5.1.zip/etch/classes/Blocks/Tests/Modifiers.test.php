<?php
/**
 * Modifiers facade test class.
 *
 * @package Etch
 */

declare(strict_types=1);

namespace Etch\Blocks\Tests;

use Etch\Blocks\Global\Utilities\Modifiers;
use WP_UnitTestCase;

/**
 * Class ModifiersTest
 */
class ModifiersTest extends WP_UnitTestCase {
	/**
	 * Test get_modifier returns a callable when the modifier is registered.
	 *
	 * @dataProvider provide_registered_modifiers
	 *
	 * @param string $modifier Registered modifier name.
	 */
	public function test_get_modifier_returns_a_callable_when_modifier_is_registered( string $modifier ) {
		$this->assertIsCallable( Modifiers::get_modifier( $modifier ) );
	}

	/**
	 * Test has_modifier returns false when the modifier is unknown.
	 */
	public function test_has_modifier_returns_false_when_modifier_is_unknown() {
		$this->assertFalse( Modifiers::has_modifier( 'not-a-modifier' ) );
	}

	/**
	 * Test apply_modifier returns null when the modifier is unknown.
	 */
	public function test_apply_modifier_returns_null_when_modifier_is_unknown() {
		$this->assertNull( Modifiers::apply_modifier( 'hello', 'notAModifier()', array() ) );
	}

	/**
	 * Test apply_modifier routes representative facade cases through the facade seam.
	 *
	 * @dataProvider provide_apply_modifier_facade_cases
	 *
	 * @param mixed               $value Modifier input value.
	 * @param string              $modifier Modifier expression.
	 * @param array<string,mixed> $options Facade options.
	 * @param mixed               $expected Expected modifier output.
	 */
	public function test_apply_modifier_routes_representative_facade_cases_through_the_facade_seam( $value, string $modifier, array $options, $expected ) {
		$this->assertSame( $expected, Modifiers::apply_modifier( $value, $modifier, $options ) );
	}

	/**
	 * Provide registered modifiers covered by the facade seam test.
	 *
	 * @return array<string, array{0:string}>
	 */
	public function provide_registered_modifiers(): array {
		return array(
			'returns arithmetic modifier callable' => array( 'add' ),
			'returns numeric modifier callable' => array( 'numberFormat' ),
			'returns date modifier callable' => array( 'dateFormat' ),
			'returns string modifier callable' => array( 'toUpperCase' ),
			'returns collection modifier callable' => array( 'pluck' ),
			'returns comparison modifier callable' => array( 'equal' ),
			'returns dynamic-content-aware modifier callable' => array( 'applyData' ),
		);
	}

	/**
	 * Provide representative facade seam cases.
	 *
	 * @return array<string, array{0:mixed,1:string,2:array<string,mixed>,3:mixed}>
	 */
	public function provide_apply_modifier_facade_cases(): array {
		return array(
			'parses literal arithmetic arguments' => array( 5, 'add(3)', array(), 8 ),
			'resolves source arithmetic arguments' => array(
				5,
				'add(site.offset)',
				array( 'sources' => $this->provide_site_sources() ),
				8,
			),
			'resolves nested comparison arguments before routing' => array(
				'http://localhost:9000/',
				'equal(site.home_url.concat("/"))',
				array( 'sources' => $this->provide_site_sources() ),
				true,
			),
			'passes quoted string arguments to replace' => array(
				'hello world',
				'replace("hello", "hey")',
				array(),
				'hey world',
			),
			'passes quoted string arguments to replaceAll' => array(
				'hello hello',
				'replaceAll("hello", "hey")',
				array(),
				'hey hey',
			),
			'passes sources through dynamic-content-aware modifiers' => array(
				'Hello my name is {person.name}',
				'applyData()',
				array( 'sources' => $this->provide_person_sources() ),
				'Hello my name is Bob',
			),
		);
	}

	/**
	 * Provide site sources used by facade seam cases.
	 *
	 * @return array<int, array<string,mixed>>
	 */
	private function provide_site_sources(): array {
		return array(
			array(
				'key'    => 'site',
				'source' => array(
					'offset' => 3,
					'home_url' => 'http://localhost:9000',
				),
			),
		);
	}

	/**
	 * Provide person sources used by facade seam cases.
	 *
	 * @return array<int, array<string,mixed>>
	 */
	private function provide_person_sources(): array {
		return array(
			array(
				'key'    => 'person',
				'source' => array(
					'name' => 'Bob',
				),
			),
		);
	}
}
