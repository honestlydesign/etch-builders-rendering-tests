<?php
/**
 * Collection modifiers test class.
 *
 * @package Etch
 */

declare(strict_types=1);

namespace Etch\Blocks\Tests;

use Etch\Blocks\Global\Utilities\Modifiers\CollectionModifiers;
use WP_UnitTestCase;

/**
 * Class CollectionModifiersTest
 */
class CollectionModifiersTest extends WP_UnitTestCase {
	/**
	 * Test concat returns callable in collection seam.
	 */
	public function test_concat_returns_callable_in_collection_seam() {
		$this->assertIsCallable( CollectionModifiers::get_modifier( 'concat' ) );
	}

	/**
	 * Test concat concatenates arrays in collection seam.
	 */
	public function test_concat_concatenates_arrays_in_collection_seam() {
		$modifier = CollectionModifiers::get_modifier( 'concat' );

		$this->assertEquals( array( 1, 2, 3, 4 ), $modifier( array( 1, 2 ), array( 3, 4 ) ) );
	}

	/**
	 * Test the deprecated unserializePhp alias returns a callable in collection seam.
	 */
	public function test_unserialize_php_alias_returns_callable_in_collection_seam() {
		$this->assertIsCallable( CollectionModifiers::get_modifier( 'unserializePhp' ) );
	}

	/**
	 * Test the deprecated unserializePhp alias unserializes arrays in collection seam.
	 */
	public function test_unserialize_php_alias_unserializes_arrays_in_collection_seam() {
		$modifier = CollectionModifiers::get_modifier( 'unserializePhp' );

		$this->assertEquals( array( 'key' => 'value' ), $modifier( 'a:1:{s:3:"key";s:5:"value";}' ) );
	}

	/**
	 * Test collection seam returns null outside collection scope.
	 */
	public function test_collection_seam_returns_null_when_modifier_is_outside_collection_scope() {
		$this->assertNull( CollectionModifiers::get_modifier( 'toUpperCase' ) );
	}

	/**
	 * Test length returns expected value.
	 *
	 * @dataProvider provide_length_cases
	 *
	 * @param mixed $value Input value.
	 * @param mixed $expected Expected value.
	 */
	public function test_length_returns_expected_value( $value, $expected ) {
		$modifier = CollectionModifiers::get_modifier( 'length' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Test reverse returns expected value.
	 *
	 * @dataProvider provide_reverse_cases
	 *
	 * @param mixed $value Input value.
	 * @param mixed $expected Expected value.
	 */
	public function test_reverse_returns_expected_value( $value, $expected ) {
		$modifier = CollectionModifiers::get_modifier( 'reverse' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Test at returns expected value.
	 *
	 * @dataProvider provide_at_cases
	 *
	 * @param mixed $value Input value.
	 * @param array $args Modifier args.
	 * @param mixed $expected Expected value.
	 */
	public function test_at_returns_expected_value( $value, array $args, $expected ) {
		$modifier = CollectionModifiers::get_modifier( 'at' );

		$this->assertEquals( $expected, $modifier( $value, ...$args ) );
	}

	/**
	 * Test slice returns expected value.
	 *
	 * @dataProvider provide_slice_cases
	 *
	 * @param mixed $value Input value.
	 * @param array $args Modifier args.
	 * @param mixed $expected Expected value.
	 */
	public function test_slice_returns_expected_value( $value, array $args, $expected ) {
		$modifier = CollectionModifiers::get_modifier( 'slice' );

		$this->assertEquals( $expected, $modifier( $value, ...$args ) );
	}

	/**
	 * Test indexOf returns expected value.
	 *
	 * @dataProvider provide_index_of_cases
	 *
	 * @param mixed $value Input value.
	 * @param array $args Modifier args.
	 * @param int   $expected Expected index.
	 */
	public function test_index_of_returns_expected_value( $value, array $args, int $expected ) {
		$modifier = CollectionModifiers::get_modifier( 'indexOf' );

		$this->assertEquals( $expected, $modifier( $value, ...$args ) );
	}

	/**
	 * Test concat returns expected value.
	 *
	 * @dataProvider provide_concat_cases
	 *
	 * @param mixed $value Input value.
	 * @param array $args Modifier args.
	 * @param mixed $expected Expected value.
	 */
	public function test_concat_returns_expected_value( $value, array $args, $expected ) {
		$modifier = CollectionModifiers::get_modifier( 'concat' );

		$this->assertEquals( $expected, $modifier( $value, ...$args ) );
	}

	/**
	 * Test join returns expected value.
	 *
	 * @dataProvider provide_join_cases
	 *
	 * @param mixed $value Input value.
	 * @param array $args Modifier args.
	 * @param mixed $expected Expected value.
	 */
	public function test_join_returns_expected_value( $value, array $args, $expected ) {
		$modifier = CollectionModifiers::get_modifier( 'join' );

		$this->assertEquals( $expected, $modifier( $value, ...$args ) );
	}

	/**
	 * Test includes returns expected value.
	 *
	 * @dataProvider provide_includes_cases
	 *
	 * @param mixed $value Input value.
	 * @param array $args Modifier args.
	 * @param mixed $expected Expected value.
	 */
	public function test_includes_returns_expected_value( $value, array $args, $expected ) {
		$modifier = CollectionModifiers::get_modifier( 'includes' );

		$this->assertEquals( $expected, $modifier( $value, ...$args ) );
	}

	/**
	 * Test pluck returns expected value.
	 *
	 * @dataProvider provide_pluck_cases
	 *
	 * @param mixed $value Input value.
	 * @param array $args Modifier args.
	 * @param array $expected Expected value.
	 */
	public function test_pluck_returns_expected_value( $value, array $args, array $expected ) {
		$modifier = CollectionModifiers::get_modifier( 'pluck' );

		$this->assertEquals( $expected, $modifier( $value, ...$args ) );
	}

	/**
	 * Test unserializePHP returns expected value.
	 *
	 * @dataProvider provide_unserialize_php_cases
	 *
	 * @param mixed $value Input value.
	 * @param mixed $expected Expected value.
	 */
	public function test_unserialize_php_returns_expected_value( $value, $expected ) {
		$modifier = CollectionModifiers::get_modifier( 'unserializePHP' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Test intersects returns expected value.
	 *
	 * @dataProvider provide_intersects_cases
	 *
	 * @param mixed $value Input value.
	 * @param array $args Modifier args.
	 * @param mixed $expected Expected value.
	 */
	public function test_intersects_returns_expected_value( $value, array $args, $expected ) {
		$modifier = CollectionModifiers::get_modifier( 'intersects' );

		$this->assertEquals( $expected, $modifier( $value, ...$args ) );
	}

	/**
	 * Test values returns expected value.
	 *
	 * @dataProvider provide_values_cases
	 *
	 * @param mixed $value Input value.
	 * @param mixed $expected Expected value.
	 */
	public function test_values_returns_expected_value( $value, $expected ) {
		$modifier = CollectionModifiers::get_modifier( 'values' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Test keys returns expected value.
	 *
	 * @dataProvider provide_keys_cases
	 *
	 * @param mixed $value Input value.
	 * @param mixed $expected Expected value.
	 */
	public function test_keys_returns_expected_value( $value, $expected ) {
		$modifier = CollectionModifiers::get_modifier( 'keys' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Data provider for length test cases.
	 *
	 * @return array<string, mixed>
	 */
	public function provide_length_cases(): array {
		return $this->build_string_or_list_collection_cases(
			array(
				'returns string length' => array( 'Hello', 5 ),
				'returns empty string length' => array( '', 0 ),
				'returns list array length' => array( array( 1, 2, 3 ), 3 ),
				'returns empty array length' => array( array(), 0 ),
			),
			'length'
		);
	}

	/**
	 * Data provider for reverse test cases.
	 *
	 * @return array<string, mixed>
	 */
	public function provide_reverse_cases(): array {
		return $this->build_string_or_list_collection_cases(
			array(
				'reverses string' => array( 'Hello', 'olleH' ),
				'reverses empty string' => array( '', '' ),
				'reverses array' => array( array( 1, 2, 3 ), array( 3, 2, 1 ) ),
				'reverses empty array' => array( array(), array() ),
			),
			'reverse'
		);
	}

	/**
	 * Data provider for at test cases.
	 *
	 * @return array<string, mixed>
	 */
	public function provide_at_cases(): array {
		return array_merge(
			array(
				'returns value at positive index' => array( array( 10, 20, 30 ), array( 1 ), 20 ),
				'returns value at zero index' => array( array( 10, 20, 30 ), array( 0 ), 10 ),
				'returns value at negative index' => array( array( 10, 20, 30 ), array( -1 ), 30 ),
				'returns null when positive index is out of bounds' => array( array( 10, 20, 30 ), array( 5 ), null ),
				'returns null when negative index is out of bounds' => array( array( 10, 20, 30 ), array( -5 ), null ),
			),
			$this->provide_non_list_array_passthrough_cases( 'at', array( 0 ) ),
		);
	}

	/**
	 * Data provider for slice test cases.
	 *
	 * @return array<string, mixed>
	 */
	public function provide_slice_cases(): array {
		return array_merge(
			array(
				'returns middle slice' => array( array( 10, 20, 30, 40, 50 ), array( 1, 3 ), array( 20, 30 ) ),
				'returns leading slice' => array( array( 10, 20, 30, 40, 50 ), array( 0, 2 ), array( 10, 20 ) ),
				'returns trailing slice when end omitted' => array( array( 10, 20, 30, 40, 50 ), array( 2 ), array( 30, 40, 50 ) ),
				'returns negative start slice' => array( array( 10, 20, 30, 40, 50 ), array( -2 ), array( 40, 50 ) ),
			),
			$this->provide_non_list_array_passthrough_cases( 'slice', array( 0, 1 ) ),
		);
	}

	/**
	 * Data provider for indexOf test cases.
	 *
	 * @return array<string, mixed>
	 */
	public function provide_index_of_cases(): array {
		return array(
			'returns substring index in string' => array( 'Hello World', array( 'World' ), 6 ),
			'returns first index in string' => array( 'Hello World', array( 'H' ), 0 ),
			'returns first repeated index in string' => array( 'Hello World', array( 'o' ), 4 ),
			'returns minus one for missing string value' => array( 'Hello World', array( 'Universe' ), -1 ),
			'returns minus one for case mismatch in string' => array( 'Hello World', array( 'h' ), -1 ),
			'returns index in array' => array( array( 'apple', 'banana', 'cherry' ), array( 'banana' ), 1 ),
			'returns first index in array' => array( array( 'apple', 'banana', 'cherry' ), array( 'apple' ), 0 ),
			'returns minus one for missing array value' => array( array( 'apple', 'banana', 'cherry' ), array( 'date' ), -1 ),
			'returns minus one for number input' => array( 42, array( '4' ), -1 ),
			'returns minus one for boolean input' => array( true, array( 't' ), -1 ),
			'returns minus one for null input' => array( null, array( 'n' ), -1 ),
		);
	}

	/**
	 * Data provider for concat test cases.
	 *
	 * @return array<string, mixed>
	 */
	public function provide_concat_cases(): array {
		return array(
			'concatenates strings with multiple args' => array( 'Hello', array( ' ', 'World' ), 'Hello World' ),
			'concatenates strings with one arg' => array( 'foo', array( 'bar' ), 'foobar' ),
			'returns original integer when input is neither string nor array' => array( 42, array(), 42 ),
			'returns original boolean when input is neither string nor array' => array( true, array(), true ),
			'returns original null when input is neither string nor array' => array( null, array(), null ),
			'concatenates arrays' => array( array( 1, 2, 3 ), array( array( 4, 5 ) ), array( 1, 2, 3, 4, 5 ) ),
			'concatenates multiple arrays' => array( array( 1 ), array( array( 2, 3 ), array( 4 ) ), array( 1, 2, 3, 4 ) ),
			'appends non-array args to array' => array( array( 1, 2 ), array( 3, 4 ), array( 1, 2, 3, 4 ) ),
			'handles mixed array and non-array args' => array( array( 1, 2 ), array( array( 3, 4 ), 5 ), array( 1, 2, 3, 4, 5 ) ),
			'preserves element types when concatenating arrays' => array( array( 'a', 'b' ), array( array( 'c' ), 'd' ), array( 'a', 'b', 'c', 'd' ) ),
		);
	}

	/**
	 * Data provider for join test cases.
	 *
	 * @return array<string, mixed>
	 */
	public function provide_join_cases(): array {
		return array(
			'joins arrays with default separator' => array( array( 'apple', 'banana' ), array(), 'apple,banana' ),
			'joins arrays with custom separator' => array( array( 'apple', 'banana' ), array( ' | ' ), 'apple | banana' ),
			'returns original string when input is not array' => array( 'apple', array( ' | ' ), 'apple' ),
		);
	}

	/**
	 * Data provider for includes test cases.
	 *
	 * @return array<string, mixed>
	 */
	public function provide_includes_cases(): array {
		return array(
			'returns true when array includes search value' => array( array( 'apple', 'banana' ), array( 'banana' ), true ),
			'returns false when array does not include search value' => array( array( 'apple', 'banana' ), array( 'pear' ), false ),
			'returns true when string includes search value' => array( 'apple pie', array( 'pie' ), true ),
			'returns false when string does not include search value' => array( 'apple pie', array( 'pear' ), false ),
			'returns custom truthy value when array includes search value' => array( array( 'apple', 'banana' ), array( 'banana', 'found', 'missing' ), 'found' ),
			'returns custom falsey value when string does not include search value' => array( 'apple pie', array( 'pear', 'found', 'missing' ), 'missing' ),
			'returns false for unsupported input' => array( 42, array( '4' ), false ),
		);
	}

	/**
	 * Data provider for pluck test cases.
	 *
	 * @return array<string, mixed>
	 */
	public function provide_pluck_cases(): array {
		$users = $this->provide_pluck_users();
		$posts = $this->provide_pluck_posts();
		$deep_data = $this->provide_pluck_deep_data();
		$users_with_missing_age = $this->provide_pluck_users_with_missing_age();
		$posts_with_missing_author = $this->provide_pluck_posts_with_missing_author();
		$mixed = $this->provide_pluck_mixed_values();
		$falsy_data = $this->provide_pluck_falsy_data();
		$object_posts = $this->provide_pluck_object_posts();

		return array_merge(
			array(
				'plucks names from objects' => array( $users, array( 'name' ), array( 'Alice', 'Bob', 'Charlie' ) ),
				'plucks ids from objects' => array( $users, array( 'id' ), array( 1, 2, 3 ) ),
				'plucks emails from objects' => array( $users, array( 'email' ), array( 'alice@example.com', 'bob@example.com', 'charlie@example.com' ) ),
			),
			array(
				'plucks nested author names' => array( $posts, array( 'author.name' ), array( 'Alice', 'Bob', 'Charlie' ) ),
				'plucks nested author ages' => array( $posts, array( 'author.age' ), array( 30, 25, 35 ) ),
				'plucks deeply nested cities' => array( $deep_data, array( 'user.profile.address.city' ), array( 'New York', 'London', 'Tokyo' ) ),
				'plucks nested values from objects' => array( $object_posts, array( 'author.name' ), array( 'Alice', 'Bob' ) ),
			),
			array(
				'returns null for missing properties' => array( $users_with_missing_age, array( 'age' ), array( null, 25, null ) ),
				'returns null for missing nested properties' => array( $posts_with_missing_author, array( 'author.name' ), array( 'Alice', null, 'Charlie' ) ),
				'returns null for non-object items' => array( $mixed, array( 'name' ), array( 'Alice', null, 'Charlie', null, null ) ),
				'returns empty array for string input' => array( 'not an array', array( 'name' ), array() ),
				'returns empty array for number input' => array( 42, array( 'name' ), array() ),
				'returns empty array for null input' => array( null, array( 'name' ), array() ),
				'returns empty array for associative array input' => array(
					array(
						'id' => 1,
						'name' => 'Alice',
					),
					array( 'name' ),
					array(),
				),
				'returns empty array when property is omitted' => array( $users, array(), array() ),
				'returns empty array for empty array input' => array( array(), array( 'name' ), array() ),
				'preserves falsy values' => array( $falsy_data, array( 'value' ), array( 0, false, '', null ) ),
			),
		);
	}

	/**
	 * Provide fixture users for pluck cases.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function provide_pluck_users(): array {
		$users = array(
			array(
				'id' => 1,
				'name' => 'Alice',
				'email' => 'alice@example.com',
			),
			array(
				'id' => 2,
				'name' => 'Bob',
				'email' => 'bob@example.com',
			),
			array(
				'id' => 3,
				'name' => 'Charlie',
				'email' => 'charlie@example.com',
			),
		);

		return $users;
	}

	/**
	 * Provide fixture posts for pluck cases.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function provide_pluck_posts(): array {
		$posts = array(
			array(
				'id' => 1,
				'title' => 'Post 1',
				'author' => array(
					'name' => 'Alice',
					'age' => 30,
				),
			),
			array(
				'id' => 2,
				'title' => 'Post 2',
				'author' => array(
					'name' => 'Bob',
					'age' => 25,
				),
			),
			array(
				'id' => 3,
				'title' => 'Post 3',
				'author' => array(
					'name' => 'Charlie',
					'age' => 35,
				),
			),
		);

		return $posts;
	}

	/**
	 * Provide deep nested fixture data for pluck cases.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function provide_pluck_deep_data(): array {
		$deep_data = array(
			array(
				'id' => 1,
				'user' => array( 'profile' => array( 'address' => array( 'city' => 'New York' ) ) ),
			),
			array(
				'id' => 2,
				'user' => array( 'profile' => array( 'address' => array( 'city' => 'London' ) ) ),
			),
			array(
				'id' => 3,
				'user' => array( 'profile' => array( 'address' => array( 'city' => 'Tokyo' ) ) ),
			),
		);

		return $deep_data;
	}

	/**
	 * Provide users missing age for pluck cases.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function provide_pluck_users_with_missing_age(): array {
		$users_with_missing_age = array(
			array(
				'id' => 1,
				'name' => 'Alice',
			),
			array(
				'id' => 2,
				'name' => 'Bob',
				'age' => 25,
			),
			array(
				'id' => 3,
				'name' => 'Charlie',
			),
		);

		return $users_with_missing_age;
	}

	/**
	 * Provide posts missing author data for pluck cases.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function provide_pluck_posts_with_missing_author(): array {
		$posts_with_missing_author = array(
			array(
				'id' => 1,
				'title' => 'Post 1',
				'author' => array( 'name' => 'Alice' ),
			),
			array(
				'id' => 2,
				'title' => 'Post 2',
			),
			array(
				'id' => 3,
				'title' => 'Post 3',
				'author' => array( 'name' => 'Charlie' ),
			),
		);

		return $posts_with_missing_author;
	}

	/**
	 * Provide mixed values for pluck cases.
	 *
	 * @return array<int, mixed>
	 */
	private function provide_pluck_mixed_values(): array {
		$mixed = array(
			array(
				'id' => 1,
				'name' => 'Alice',
			),
			null,
			array(
				'id' => 3,
				'name' => 'Charlie',
			),
			'string',
			42,
		);

		return $mixed;
	}

	/**
	 * Provide falsy-value fixtures for pluck cases.
	 *
	 * @return array<int, array<string, mixed>>
	 */
	private function provide_pluck_falsy_data(): array {
		$falsy_data = array(
			array(
				'id' => 1,
				'value' => 0,
			),
			array(
				'id' => 2,
				'value' => false,
			),
			array(
				'id' => 3,
				'value' => '',
			),
			array(
				'id' => 4,
				'value' => null,
			),
		);

		return $falsy_data;
	}

	/**
	 * Provide object-post fixtures for pluck cases.
	 *
	 * @return array<int, object>
	 */
	private function provide_pluck_object_posts(): array {
		$object_posts = array(
			(object) array(
				'id' => 1,
				'author' => (object) array( 'name' => 'Alice' ),
			),
			(object) array(
				'id' => 2,
				'author' => (object) array( 'name' => 'Bob' ),
			),
		);

		return $object_posts;
	}

	/**
	 * Data provider for unserializePHP test cases.
	 *
	 * @return array<string, mixed>
	 */
	public function provide_unserialize_php_cases(): array {
		return array(
			'unserializes simple php string array' => array( 'a:3:{i:0;s:5:"apple";i:1;s:6:"banana";i:2;s:6:"cherry";}', array( 'apple', 'banana', 'cherry' ) ),
			'returns original invalid serialized string' => array( 'not a serialized string', 'not a serialized string' ),
			'returns original integer when input is not string' => array( 42, 42 ),
		);
	}

	/**
	 * Data provider for intersects test cases.
	 *
	 * @return array<string, mixed>
	 */
	public function provide_intersects_cases(): array {
		return array(
			'returns true when arrays intersect' => array( array( 1, 2, 3 ), array( array( 2, 3, 4 ) ), true ),
			'returns false when arrays do not intersect' => array( array( 1, 2, 3 ), array( array( 4, 5, 6 ) ), false ),
			'returns false for null input' => array( null, array( array( 2, 3, 4 ) ), false ),
			'returns false when compare value is not array' => array( array( 1, 2, 3 ), array( null ), false ),
			'returns false for empty array input' => array( array(), array( array( 1, 2, 3 ) ), false ),
			'returns false for object input' => array( (object) array(), array( array( 2, 3, 4 ) ), false ),
			'returns custom true value when arrays intersect' => array( array( 1, 2, 3 ), array( array( 2, 3, 4 ), 'yes', 'no' ), 'yes' ),
			'returns custom false value when arrays do not intersect' => array( array( 1, 2, 3 ), array( array( 4, 5, 6 ), 'yes', 'no' ), 'no' ),
		);
	}

	/**
	 * Data provider for values test cases.
	 *
	 * @return array<string, mixed>
	 */
	public function provide_values_cases(): array {
		return $this->build_array_projection_cases(
			array(
				'returns values of associative array' => array(
					$this->provide_fruit_map(),
					array( 'apple', 'banana', 'cherry' ),
				),
				'returns empty array for empty array' => array( array(), array() ),
				'returns original list array' => array( $this->provide_fruit_list(), array( 'apple', 'banana', 'cherry' ) ),
			),
			'values'
		);
	}

	/**
	 * Data provider for keys test cases.
	 *
	 * @return array<string, mixed>
	 */
	public function provide_keys_cases(): array {
		return $this->build_array_projection_cases(
			array(
				'returns keys of associative array' => array(
					$this->provide_fruit_map(),
					array( 'a', 'b', 'c' ),
				),
				'returns empty array for empty array' => array( array(), array() ),
				'returns original list array' => array( $this->provide_fruit_list(), array( 'apple', 'banana', 'cherry' ) ),
			),
			'keys'
		);
	}

	/**
	 * Build cases shared by string/list collection modifiers.
	 *
	 * @param array<string, array{0:mixed,1:mixed}> $valid_cases Valid collection cases.
	 * @param string                                $modifier Modifier name used in the dataset label.
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	private function build_string_or_list_collection_cases( array $valid_cases, string $modifier ): array {
		return array_merge( $valid_cases, $this->provide_non_string_or_non_list_passthrough_cases( $modifier ) );
	}

	/**
	 * Provide passthrough cases shared by length and reverse.
	 *
	 * @param string $modifier Modifier name used in the dataset label.
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	private function provide_non_string_or_non_list_passthrough_cases( string $modifier ): array {
		return array(
			sprintf( '%s returns original integer for non string non list array', $modifier ) => array( 42, 42 ),
			sprintf( '%s returns original boolean for non string non list array', $modifier ) => array( true, true ),
			sprintf( '%s returns original null for non string non list array', $modifier ) => array( null, null ),
			sprintf( '%s returns original associative array', $modifier ) => array( array( 'key' => 'value' ), array( 'key' => 'value' ) ),
		);
	}

	/**
	 * Provide passthrough cases shared by array-indexing modifiers.
	 *
	 * @param string $modifier Modifier name used in the dataset label.
	 * @param array  $args Modifier arguments to preserve.
	 * @return array<string, array{0:mixed,1:array,2:mixed}>
	 */
	private function provide_non_list_array_passthrough_cases( string $modifier, array $args ): array {
		return array(
			sprintf( '%s returns original integer when input is not array', $modifier ) => array( 42, $args, 42 ),
			sprintf( '%s returns original string when input is not array', $modifier ) => array( 'test', $args, 'test' ),
			sprintf( '%s returns original boolean when input is not array', $modifier ) => array( true, $args, true ),
			sprintf( '%s returns original null when input is not array', $modifier ) => array( null, $args, null ),
			sprintf( '%s returns original associative array when input is not list array', $modifier ) => array( array( 'key' => 'value' ), $args, array( 'key' => 'value' ) ),
		);
	}

	/**
	 * Provide passthrough cases shared by values and keys.
	 *
	 * @param string $modifier Modifier name used in the dataset label.
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	private function provide_non_array_passthrough_cases( string $modifier ): array {
		return array(
			sprintf( '%s returns original integer when input is not array', $modifier ) => array( 42, 42 ),
			sprintf( '%s returns original string when input is not array', $modifier ) => array( 'string', 'string' ),
			sprintf( '%s returns original boolean when input is not array', $modifier ) => array( true, true ),
			sprintf( '%s returns original null when input is not array', $modifier ) => array( null, null ),
		);
	}

	/**
	 * Build cases shared by values and keys.
	 *
	 * @param array<string, array{0:mixed,1:mixed}> $valid_cases Valid projection cases.
	 * @param string                                $modifier Modifier name used in the dataset label.
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	private function build_array_projection_cases( array $valid_cases, string $modifier ): array {
		return array_merge( $valid_cases, $this->provide_non_array_passthrough_cases( $modifier ) );
	}

	/**
	 * Provide a shared associative fruit map.
	 *
	 * @return array<string, string>
	 */
	private function provide_fruit_map(): array {
		return array(
			'a' => 'apple',
			'b' => 'banana',
			'c' => 'cherry',
		);
	}

	/**
	 * Provide a shared fruit list.
	 *
	 * @return array<int, string>
	 */
	private function provide_fruit_list(): array {
		return array( 'apple', 'banana', 'cherry' );
	}
}
