<?php
/**
 * Date modifiers test class.
 *
 * @package Etch
 */

declare(strict_types=1);

namespace Etch\Blocks\Tests;

use Etch\Blocks\Global\Utilities\Modifiers\DateModifiers;
use WP_UnitTestCase;

/**
 * Class DateModifiersTest
 */
class DateModifiersTest extends WP_UnitTestCase {
	/**
	 * Test dateFormat returns callable in the date seam.
	 */
	public function test_date_format_returns_callable_in_the_date_seam() {
		$this->assertIsCallable( DateModifiers::get_modifier( 'dateFormat' ) );
	}

	/**
	 * Test deprecated format alias returns callable in the date seam.
	 */
	public function test_format_alias_returns_callable_in_the_date_seam() {
		$this->assertIsCallable( DateModifiers::get_modifier( 'format' ) );
	}

	/**
	 * Test deprecated format alias keeps canonical behavior in the date seam.
	 */
	public function test_format_alias_keeps_canonical_behavior_in_the_date_seam() {
		$modifier = DateModifiers::get_modifier( 'format' );

		$this->assertEquals( '2024-02-29', $modifier( '1709211909', 'Y-m-d' ) );
	}

	/**
	 * Test date seam returns null when modifier is outside scope.
	 */
	public function test_date_seam_returns_null_when_modifier_is_outside_scope() {
		$this->assertNull( DateModifiers::get_modifier( 'add' ) );
	}

	/**
	 * Test dateFormat returns expected output when input is date-like.
	 *
	 * @dataProvider provide_date_format_cases
	 *
	 * @param mixed  $value Date-like input value.
	 * @param string $format Format string.
	 * @param string $expected Expected formatted value.
	 */
	public function test_date_format_returns_expected_output_when_input_is_date_like( $value, string $format, string $expected ) {
		$modifier = DateModifiers::get_modifier( 'dateFormat' );

		$this->assertEquals( $expected, $modifier( $value, $format ) );
	}

	/**
	 * Test dateFormat returns original value when input is invalid.
	 *
	 * @dataProvider provide_invalid_date_inputs
	 *
	 * @param mixed $value Invalid date input value.
	 */
	public function test_date_format_returns_original_value_when_input_is_invalid( $value ) {
		$modifier = DateModifiers::get_modifier( 'dateFormat' );

		$this->assertEquals( $value, $modifier( $value, 'Y-m-d' ) );
	}

	/**
	 * Provide date-like inputs.
	 *
	 * @return array<string, array{0:mixed,1:string,2:string}>
	 */
	public function provide_date_format_cases(): array {
		return array(
			'formats ISO date strings' => array( '2025-05-07T10:00:00.000Z', 'Y-m-d', '2025-05-07' ),
			'formats Unix timestamps' => array( 1709211909, 'Y-m-d H:i:s', '2024-02-29 13:05:09' ),
			'formats Unix timestamps given as strings' => array( '1709211909', 'Y-m-d', '2024-02-29' ),
			'formats short Unix timestamps' => array( 20589635, 'Y-m-d', '1970-08-27' ),
			'formats non ISO date strings' => array( '2025-07-31 10:00:00', 'Y-m-d H:i:s', '2025-07-31 10:00:00' ),
			'formats other non ISO date strings' => array( '12/03/2025', 'Y-m-d', '2025-12-03' ),
		);
	}

	/**
	 * Provide invalid date inputs.
	 *
	 * @return array<string, array{0:mixed}>
	 */
	public function provide_invalid_date_inputs(): array {
		return array(
			'returns original boolean for invalid date input' => array( true ),
			'returns original null for invalid date input' => array( null ),
			'returns original string for invalid date input' => array( 'not-a-date' ),
		);
	}
}
