<?php
/**
 * Comparison modifiers test class.
 *
 * @package Etch
 */

declare(strict_types=1);

namespace Etch\Blocks\Tests;

use Etch\Blocks\Global\Utilities\Modifiers\ComparisonModifiers;
use WP_UnitTestCase;

/**
 * Class ComparisonModifiersTest
 */
class ComparisonModifiersTest extends WP_UnitTestCase {
	/**
	 * Test comparison seam returns a callable when the modifier is registered.
	 *
	 * @dataProvider provide_registered_comparison_modifiers
	 *
	 * @param string $modifier Registered modifier name.
	 */
	public function test_comparison_seam_returns_a_callable_when_the_modifier_is_registered( string $modifier ) {
		$this->assertIsCallable( ComparisonModifiers::get_modifier( $modifier ) );
	}

	/**
	 * Test comparison seam returns expected output for direct modifier execution.
	 *
	 * @dataProvider provide_direct_comparison_modifier_cases
	 *
	 * @param string $modifier Registered modifier name.
	 * @param mixed  $value Modifier input value.
	 * @param array  $args Modifier arguments.
	 * @param mixed  $expected Expected modifier output.
	 */
	public function test_comparison_seam_returns_expected_output_for_direct_modifier_execution( string $modifier, $value, array $args, $expected ) {
		$comparison_modifier = ComparisonModifiers::get_modifier( $modifier );

		$this->assertSame( $expected, $comparison_modifier( $value, ...$args ) );
	}

	/**
	 * Test comparison seam returns null outside comparison scope.
	 */
	public function test_comparison_seam_returns_null_when_modifier_is_outside_comparison_scope() {
		$this->assertNull( ComparisonModifiers::get_modifier( 'concat' ) );
	}

	/**
	 * Provide registered comparison modifiers.
	 *
	 * @return array<string, array{0:string}>
	 */
	public function provide_registered_comparison_modifiers(): array {
		return array(
			'less is registered' => array( 'less' ),
			'greaterOrEqual is registered' => array( 'greaterOrEqual' ),
			'equal is registered' => array( 'equal' ),
		);
	}

	/**
	 * Provide direct comparison modifier cases.
	 *
	 * @return array<string, array{0:string,1:mixed,2:array,3:mixed}>
	 */
	public function provide_direct_comparison_modifier_cases(): array {
		return array_merge(
			$this->provide_less_direct_cases(),
			$this->provide_less_or_equal_direct_cases(),
			$this->provide_greater_direct_cases(),
			$this->provide_greater_or_equal_direct_cases(),
			$this->provide_equal_direct_cases(),
		);
	}

	/**
	 * Provide less direct cases.
	 *
	 * @return array<string, array{0:string,1:mixed,2:array,3:mixed}>
	 */
	private function provide_less_direct_cases(): array {
		return array(
			'less returns true when the left number is smaller' => array( 'less', 5, array( 10 ), true ),
			'less returns true when a negative number is smaller' => array( 'less', -1, array( 0 ), true ),
			'less returns false when the left number is larger' => array( 'less', 10, array( 5 ), false ),
			'less returns false when zero is larger than a negative number' => array( 'less', 0, array( -1 ), false ),
			'less returns false when numbers match' => array( 'less', 5, array( 5 ), false ),
			'less returns true for numeric strings when the left value is smaller' => array( 'less', '5', array( '10' ), true ),
			'less returns false for numeric strings when the left value is larger' => array( 'less', '10', array( '5' ), false ),
			'less returns true for lexicographically smaller strings' => array( 'less', 'apple', array( 'banana' ), true ),
			'less returns false for lexicographically larger strings' => array( 'less', 'banana', array( 'apple' ), false ),
			'less returns false for matching strings' => array( 'less', 'apple', array( 'apple' ), false ),
			'less returns false when the left value is null' => array( 'less', null, array( 5 ), false ),
			'less returns false when the right value is null' => array( 'less', 5, array( null ), false ),
			'less returns false when the left value is an array' => array( 'less', array(), array( 5 ), false ),
			'less returns false when the right value is an array' => array( 'less', 5, array( array() ), false ),
			'less returns the custom truthy branch when the comparison succeeds' => array( 'less', 5, array( 10, 'yes', 'no' ), 'yes' ),
			'less returns the custom falsey branch when the comparison fails' => array( 'less', 10, array( 5, 'yes', 'no' ), 'no' ),
		);
	}

	/**
	 * Provide lessOrEqual direct cases.
	 *
	 * @return array<string, array{0:string,1:mixed,2:array,3:mixed}>
	 */
	private function provide_less_or_equal_direct_cases(): array {
		return array(
			'lessOrEqual returns true when the left number is smaller' => array( 'lessOrEqual', 5, array( 10 ), true ),
			'lessOrEqual returns true when a negative number is smaller' => array( 'lessOrEqual', -1, array( 0 ), true ),
			'lessOrEqual returns true when numbers match' => array( 'lessOrEqual', 5, array( 5 ), true ),
			'lessOrEqual returns false when the left number is larger' => array( 'lessOrEqual', 10, array( 5 ), false ),
			'lessOrEqual returns false when the left float is larger' => array( 'lessOrEqual', 5.1, array( 5 ), false ),
			'lessOrEqual returns true for numeric strings when the left value is smaller' => array( 'lessOrEqual', '5', array( '10' ), true ),
			'lessOrEqual returns false for numeric strings when the left value is larger' => array( 'lessOrEqual', '10', array( '5' ), false ),
			'lessOrEqual returns true for lexicographically smaller strings' => array( 'lessOrEqual', 'apple', array( 'banana' ), true ),
			'lessOrEqual returns false for lexicographically larger strings' => array( 'lessOrEqual', 'banana', array( 'apple' ), false ),
			'lessOrEqual returns true for matching strings' => array( 'lessOrEqual', 'apple', array( 'apple' ), true ),
			'lessOrEqual returns false when the left value is null' => array( 'lessOrEqual', null, array( 5 ), false ),
			'lessOrEqual returns false when the right value is null' => array( 'lessOrEqual', 5, array( null ), false ),
			'lessOrEqual returns the custom truthy branch when the comparison succeeds' => array( 'lessOrEqual', 5, array( 10, 'yes', 'no' ), 'yes' ),
			'lessOrEqual returns the custom falsey branch when the comparison fails' => array( 'lessOrEqual', 10, array( 5, 'yes', 'no' ), 'no' ),
		);
	}

	/**
	 * Provide greater direct cases.
	 *
	 * @return array<string, array{0:string,1:mixed,2:array,3:mixed}>
	 */
	private function provide_greater_direct_cases(): array {
		return array(
			'greater returns true when the left number is larger' => array( 'greater', 10, array( 5 ), true ),
			'greater returns true when zero is larger than a negative number' => array( 'greater', 0, array( -1 ), true ),
			'greater returns false when the left number is smaller' => array( 'greater', 5, array( 10 ), false ),
			'greater returns false when numbers match' => array( 'greater', 5, array( 5 ), false ),
			'greater returns false for numeric strings when the left value is smaller' => array( 'greater', '5', array( '10' ), false ),
			'greater returns true for numeric strings when the left value is larger' => array( 'greater', '10', array( '5' ), true ),
			'greater returns false for lexicographically smaller strings' => array( 'greater', 'apple', array( 'banana' ), false ),
			'greater returns true for lexicographically larger strings' => array( 'greater', 'banana', array( 'apple' ), true ),
			'greater returns false for matching strings' => array( 'greater', 'apple', array( 'apple' ), false ),
			'greater returns false when the left value is null' => array( 'greater', null, array( 5 ), false ),
			'greater returns the custom falsey branch when the comparison fails' => array( 'greater', 5, array( 10, 'yes', 'no' ), 'no' ),
			'greater returns the custom truthy branch when the comparison succeeds' => array( 'greater', 10, array( 5, 'yes', 'no' ), 'yes' ),
		);
	}

	/**
	 * Provide greaterOrEqual direct cases.
	 *
	 * @return array<string, array{0:string,1:mixed,2:array,3:mixed}>
	 */
	private function provide_greater_or_equal_direct_cases(): array {
		return array(
			'greaterOrEqual returns true when the left number is larger' => array( 'greaterOrEqual', 10, array( 5 ), true ),
			'greaterOrEqual returns true when zero is larger than a negative number' => array( 'greaterOrEqual', 0, array( -1 ), true ),
			'greaterOrEqual returns true when numbers match' => array( 'greaterOrEqual', 5, array( 5 ), true ),
			'greaterOrEqual returns false when the left number is smaller' => array( 'greaterOrEqual', 1, array( 5 ), false ),
			'greaterOrEqual returns true for matching strings' => array( 'greaterOrEqual', 'apple', array( 'apple' ), true ),
			'greaterOrEqual returns false for lexicographically smaller strings' => array( 'greaterOrEqual', 'apple', array( 'banana' ), false ),
			'greaterOrEqual returns the custom falsey branch when the comparison fails' => array( 'greaterOrEqual', 5, array( 10, 'yes', 'no' ), 'no' ),
			'greaterOrEqual returns the custom truthy branch when the comparison succeeds' => array( 'greaterOrEqual', 10, array( 5, 'yes', 'no' ), 'yes' ),
		);
	}

	/**
	 * Provide equal direct cases.
	 *
	 * @return array<string, array{0:string,1:mixed,2:array,3:mixed}>
	 */
	private function provide_equal_direct_cases(): array {
		return array(
			'equal returns true for matching integers' => array( 'equal', 5, array( 5 ), true ),
			'equal returns true for matching strings' => array( 'equal', 'test', array( 'test' ), true ),
			'equal returns true for matching booleans' => array( 'equal', true, array( true ), true ),
			'equal returns false for different integers' => array( 'equal', 5, array( 10 ), false ),
			'equal returns false for different strings' => array( 'equal', 'test', array( 'TEST' ), false ),
			'equal returns false for different booleans' => array( 'equal', true, array( false ), false ),
			'equal keeps strict equality for mixed scalar types' => array( 'equal', 5, array( '5' ), false ),
			'equal returns the custom truthy branch when values match' => array( 'equal', 5, array( 5, 'yes', 'no' ), 'yes' ),
			'equal returns the custom falsey branch when values differ' => array( 'equal', 5, array( 10, 'yes', 'no' ), 'no' ),
		);
	}
}
