<?php
/**
 * Arithmetic modifiers test class.
 *
 * @package Etch
 */

declare(strict_types=1);

namespace Etch\Blocks\Tests;

use Etch\Blocks\Global\Utilities\Modifiers\ArithmeticModifiers;
use WP_UnitTestCase;

/**
 * Class ArithmeticModifiersTest
 */
class ArithmeticModifiersTest extends WP_UnitTestCase {
	/**
	 * Test add returns a callable in the arithmetic seam.
	 */
	public function test_add_returns_a_callable_in_the_arithmetic_seam() {
		$this->assertIsCallable( ArithmeticModifiers::get_modifier( 'add' ) );
	}

	/**
	 * Test arithmetic seam returns null when modifier is outside scope.
	 */
	public function test_arithmetic_seam_returns_null_when_modifier_is_outside_scope() {
		$this->assertNull( ArithmeticModifiers::get_modifier( 'dateFormat' ) );
	}

	/**
	 * Test add returns sum when both operands are numbers.
	 */
	public function test_add_returns_sum_when_both_operands_are_numbers() {
		$modifier = ArithmeticModifiers::get_modifier( 'add' );

		$this->assertEquals( 8, $modifier( 5, 3 ) );
	}

	/**
	 * Test add accepts numeric strings when operands are string numbers.
	 */
	public function test_add_accepts_numeric_strings_when_operands_are_string_numbers() {
		$modifier = ArithmeticModifiers::get_modifier( 'add' );

		$this->assertEquals( 8, $modifier( '5', '3' ) );
	}

	/**
	 * Test add trims operands when numeric strings contain spaces.
	 */
	public function test_add_trims_operands_when_numeric_strings_contain_spaces() {
		$modifier = ArithmeticModifiers::get_modifier( 'add' );

		$this->assertEquals( 8, $modifier( ' 5 ', ' 3 ' ) );
	}

	/**
	 * Test add preserves decimal results when operands are floats.
	 */
	public function test_add_preserves_decimal_results_when_operands_are_floats() {
		$modifier = ArithmeticModifiers::get_modifier( 'add' );

		$this->assertEquals( 8.75, $modifier( 5.5, 3.25 ) );
	}

	/**
	 * Test add returns original value when left operand is not numeric.
	 */
	public function test_add_returns_original_value_when_left_operand_is_not_numeric() {
		$modifier = ArithmeticModifiers::get_modifier( 'add' );

		$this->assertSame( 'hello', $modifier( 'hello', 3 ) );
	}

	/**
	 * Test add returns original value when right operand is missing.
	 */
	public function test_add_returns_original_value_when_right_operand_is_missing() {
		$modifier = ArithmeticModifiers::get_modifier( 'add' );

		$this->assertSame( 5, $modifier( 5 ) );
	}

	/**
	 * Test add returns original value when right operand is not numeric.
	 */
	public function test_add_returns_original_value_when_right_operand_is_not_numeric() {
		$modifier = ArithmeticModifiers::get_modifier( 'add' );

		$this->assertSame( 5, $modifier( 5, 'abc' ) );
	}

	/**
	 * Test add returns original value when right operand is NaN.
	 */
	public function test_add_returns_original_value_when_right_operand_is_nan() {
		$modifier = ArithmeticModifiers::get_modifier( 'add' );

		$this->assertSame( 5, $modifier( 5, NAN ) );
	}

	/**
	 * Test subtract returns difference when both operands are numbers.
	 */
	public function test_subtract_returns_difference_when_both_operands_are_numbers() {
		$modifier = ArithmeticModifiers::get_modifier( 'subtract' );

		$this->assertEquals( 2, $modifier( 5, 3 ) );
	}

	/**
	 * Test subtract preserves decimal results when operands are floats.
	 */
	public function test_subtract_preserves_decimal_results_when_operands_are_floats() {
		$modifier = ArithmeticModifiers::get_modifier( 'subtract' );

		$this->assertEquals( 2.25, $modifier( 5.5, 3.25 ) );
	}

	/**
	 * Test subtract returns original value when right operand is not numeric.
	 */
	public function test_subtract_returns_original_value_when_right_operand_is_not_numeric() {
		$modifier = ArithmeticModifiers::get_modifier( 'subtract' );

		$this->assertSame( 5, $modifier( 5, 'abc' ) );
	}

	/**
	 * Test multiply returns product when both operands are numbers.
	 */
	public function test_multiply_returns_product_when_both_operands_are_numbers() {
		$modifier = ArithmeticModifiers::get_modifier( 'multiply' );

		$this->assertEquals( 15, $modifier( 5, 3 ) );
	}

	/**
	 * Test multiply preserves decimal results when operands are floats.
	 */
	public function test_multiply_preserves_decimal_results_when_operands_are_floats() {
		$modifier = ArithmeticModifiers::get_modifier( 'multiply' );

		$this->assertEquals( 8.25, $modifier( 3.3, 2.5 ) );
	}

	/**
	 * Test multiply returns original value when right operand is not numeric.
	 */
	public function test_multiply_returns_original_value_when_right_operand_is_not_numeric() {
		$modifier = ArithmeticModifiers::get_modifier( 'multiply' );

		$this->assertSame( 5, $modifier( 5, 'abc' ) );
	}

	/**
	 * Test divide returns quotient when both operands are numbers.
	 */
	public function test_divide_returns_quotient_when_both_operands_are_numbers() {
		$modifier = ArithmeticModifiers::get_modifier( 'divide' );

		$this->assertEquals( 4, $modifier( 12, 3 ) );
	}

	/**
	 * Test divide preserves decimal results when operands are floats.
	 */
	public function test_divide_preserves_decimal_results_when_operands_are_floats() {
		$modifier = ArithmeticModifiers::get_modifier( 'divide' );

		$this->assertEquals( 2.2, $modifier( 5.5, 2.5 ) );
	}

	/**
	 * Test divide returns original value when right operand is not numeric.
	 */
	public function test_divide_returns_original_value_when_right_operand_is_not_numeric() {
		$modifier = ArithmeticModifiers::get_modifier( 'divide' );

		$this->assertSame( 5, $modifier( 5, 'abc' ) );
	}

	/**
	 * Test divide returns original value when divisor is zero.
	 */
	public function test_divide_returns_original_value_when_divisor_is_zero() {
		$modifier = ArithmeticModifiers::get_modifier( 'divide' );

		$this->assertSame( 5, $modifier( 5, 0 ) );
	}

	/**
	 * Test divide returns original value when divisor is zero string.
	 */
	public function test_divide_returns_original_value_when_divisor_is_zero_string() {
		$modifier = ArithmeticModifiers::get_modifier( 'divide' );

		$this->assertSame( 5, $modifier( 5, '0' ) );
	}

	/**
	 * Test divide returns original value when divisor is trimmed zero string.
	 */
	public function test_divide_returns_original_value_when_divisor_is_trimmed_zero_string() {
		$modifier = ArithmeticModifiers::get_modifier( 'divide' );

		$this->assertSame( 5, $modifier( 5, ' 0 ' ) );
	}

	/**
	 * Test mod returns remainder when both operands are numbers.
	 */
	public function test_mod_returns_remainder_when_both_operands_are_numbers() {
		$modifier = ArithmeticModifiers::get_modifier( 'mod' );

		$this->assertEquals( 2, $modifier( 5, 3 ) );
	}

	/**
	 * Test mod supports decimal results when operands are floats.
	 */
	public function test_mod_supports_decimal_results_when_operands_are_floats() {
		$modifier = ArithmeticModifiers::get_modifier( 'mod' );

		$this->assertEquals( 1.5, $modifier( 5.5, 2 ) );
	}

	/**
	 * Test mod returns original value when right operand is not numeric.
	 */
	public function test_mod_returns_original_value_when_right_operand_is_not_numeric() {
		$modifier = ArithmeticModifiers::get_modifier( 'mod' );

		$this->assertSame( 5, $modifier( 5, 'abc' ) );
	}

	/**
	 * Test mod returns original value when divisor is zero.
	 */
	public function test_mod_returns_original_value_when_divisor_is_zero() {
		$modifier = ArithmeticModifiers::get_modifier( 'mod' );

		$this->assertSame( 5, $modifier( 5, 0 ) );
	}

	/**
	 * Test mod returns original value when divisor is zero string.
	 */
	public function test_mod_returns_original_value_when_divisor_is_zero_string() {
		$modifier = ArithmeticModifiers::get_modifier( 'mod' );

		$this->assertSame( 5, $modifier( 5, '0' ) );
	}
}
