<?php
/**
 * Numeric modifiers test class.
 *
 * @package Etch
 */

declare(strict_types=1);

namespace Etch\Blocks\Tests;

use Etch\Blocks\Global\Utilities\Modifiers\NumericModifiers;
use WP_UnitTestCase;

/**
 * Class NumericModifiersTest
 */
class NumericModifiersTest extends WP_UnitTestCase {
	/**
	 * Test numberFormat returns a callable when the numeric seam handles the modifier.
	 */
	public function test_number_format_returns_callable_when_numeric_seam_handles_modifier() {
		$this->assertIsCallable( NumericModifiers::get_modifier( 'numberFormat' ) );
	}

	/**
	 * Test numberFormat formats numeric strings when the numeric seam handles the modifier.
	 */
	public function test_number_format_formats_numeric_strings_when_numeric_seam_handles_modifier() {
		$modifier = NumericModifiers::get_modifier( 'numberFormat' );

		$this->assertEquals( '1.234.567,0', $modifier( '1234567', 1, ',', '.' ) );
	}

	/**
	 * Test round returns a callable when the numeric seam handles the modifier.
	 */
	public function test_round_returns_callable_when_numeric_seam_handles_modifier() {
		$this->assertIsCallable( NumericModifiers::get_modifier( 'round' ) );
	}

	/**
	 * Test round handles numeric strings when precision is provided.
	 */
	public function test_round_handles_numeric_strings_when_precision_is_provided() {
		$modifier = NumericModifiers::get_modifier( 'round' );

		$this->assertEquals( 3.14, $modifier( '3.14159', 2 ) );
	}

	/**
	 * Test numeric seam returns null when the modifier is outside numeric scope.
	 */
	public function test_numeric_seam_returns_null_when_modifier_is_outside_numeric_scope() {
		$this->assertNull( NumericModifiers::get_modifier( 'toUpperCase' ) );
	}

	/**
	 * Test numberFormat returns expected output when input is numeric.
	 *
	 * @dataProvider provide_number_format_cases
	 *
	 * @param mixed  $value Modifier input value.
	 * @param array  $args Modifier arguments.
	 * @param string $expected Expected formatted value.
	 */
	public function test_number_format_returns_expected_output_when_input_is_numeric( $value, array $args, string $expected ) {
		$modifier = NumericModifiers::get_modifier( 'numberFormat' );

		$this->assertEquals( $expected, $modifier( $value, ...$args ) );
	}

	/**
	 * Test numberFormat returns original value when input is invalid.
	 *
	 * @dataProvider provide_number_format_invalid_cases
	 *
	 * @param mixed $value Modifier input value.
	 */
	public function test_number_format_returns_original_value_when_input_is_invalid( $value ) {
		$modifier = NumericModifiers::get_modifier( 'numberFormat' );

		$this->assertEquals( $value, $modifier( $value, 0, '', ',' ) );
	}

	/**
	 * Test toInt returns expected integer when input is numeric.
	 *
	 * @dataProvider provide_to_int_cases
	 *
	 * @param mixed $value Modifier input value.
	 * @param int   $expected Expected integer value.
	 */
	public function test_to_int_returns_expected_integer_when_input_is_numeric( $value, int $expected ) {
		$modifier = NumericModifiers::get_modifier( 'toInt' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Test toInt returns original value when input is invalid.
	 *
	 * @dataProvider provide_to_int_invalid_cases
	 *
	 * @param mixed $value Modifier input value.
	 */
	public function test_to_int_returns_original_value_when_input_is_invalid( $value ) {
		$modifier = NumericModifiers::get_modifier( 'toInt' );

		$this->assertEquals( $value, $modifier( $value ) );
	}

	/**
	 * Test ceil returns expected integer when input is numeric.
	 *
	 * @dataProvider provide_ceil_cases
	 *
	 * @param mixed $value Modifier input value.
	 * @param int   $expected Expected integer value.
	 */
	public function test_ceil_returns_expected_integer_when_input_is_numeric( $value, int $expected ) {
		$modifier = NumericModifiers::get_modifier( 'ceil' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Test ceil returns original value when input is invalid.
	 *
	 * @dataProvider provide_ceil_invalid_cases
	 *
	 * @param mixed $value Modifier input value.
	 */
	public function test_ceil_returns_original_value_when_input_is_invalid( $value ) {
		$modifier = NumericModifiers::get_modifier( 'ceil' );

		$this->assertEquals( $value, $modifier( $value ) );
	}

	/**
	 * Test round returns expected value when input is numeric.
	 *
	 * @dataProvider provide_round_cases
	 *
	 * @param mixed      $value Modifier input value.
	 * @param array<int> $args Modifier arguments.
	 * @param float|int  $expected Expected rounded value.
	 */
	public function test_round_returns_expected_value_when_input_is_numeric( $value, array $args, $expected ) {
		$modifier = NumericModifiers::get_modifier( 'round' );

		$this->assertEquals( $expected, $modifier( $value, ...$args ) );
	}

	/**
	 * Test round returns original value when input is invalid.
	 *
	 * @dataProvider provide_round_invalid_cases
	 *
	 * @param mixed $value Modifier input value.
	 */
	public function test_round_returns_original_value_when_input_is_invalid( $value ) {
		$modifier = NumericModifiers::get_modifier( 'round' );

		$this->assertEquals( $value, $modifier( $value ) );
	}

	/**
	 * Test floor returns expected integer when input is numeric.
	 *
	 * @dataProvider provide_floor_cases
	 *
	 * @param mixed $value Modifier input value.
	 * @param int   $expected Expected floored value.
	 */
	public function test_floor_returns_expected_integer_when_input_is_numeric( $value, int $expected ) {
		$modifier = NumericModifiers::get_modifier( 'floor' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Test floor returns original value when input is invalid.
	 *
	 * @dataProvider provide_floor_invalid_cases
	 *
	 * @param mixed $value Modifier input value.
	 */
	public function test_floor_returns_original_value_when_input_is_invalid( $value ) {
		$modifier = NumericModifiers::get_modifier( 'floor' );

		$this->assertEquals( $value, $modifier( $value ) );
	}

	/**
	 * Provide numberFormat cases.
	 *
	 * @return array<string, array{0:mixed,1:array,2:string}>
	 */
	public function provide_number_format_cases(): array {
		return array(
			'formats integer with dot decimal and comma thousands' => array( 123456, array( 2, '.', ',' ), '123,456.00' ),
			'formats integer with comma decimal and dot thousands' => array( 123456, array( 2, ',', '.' ), '123.456,00' ),
			'rounds up when decimals are removed' => array( 1234.56, array( 0, '.', ',' ), '1,235' ),
			'formats integer with zero decimals and dot thousands' => array( 123456, array( 0, ',', '.' ), '123.456' ),
			'rounds down when decimals are removed' => array( 1234.33, array( 0, '', ',' ), '1,234' ),
			'formats numeric string without decimal suffix when decimals are zero' => array( '1234567', array( 0, ',', '.' ), '1.234.567' ),
			'formats numeric string with padded decimal suffix when decimals are one' => array( '1234567', array( 1, ',', '.' ), '1.234.567,0' ),
			'formats short numeric string with custom thousands separator' => array( '1234', array( 0, '', '.' ), '1.234' ),
		);
	}

	/**
	 * Provide invalid numberFormat cases.
	 *
	 * @return array<string, array{0:mixed}>
	 */
	public function provide_number_format_invalid_cases(): array {
		return array(
			'returns original string for non numeric input' => array( 'some string' ),
			'returns original array for non numeric input' => array( array( 1, 2, 3 ) ),
		);
	}

	/**
	 * Provide toInt cases.
	 *
	 * @return array<string, array{0:mixed,1:int}>
	 */
	public function provide_to_int_cases(): array {
		return array(
			'converts numeric string input' => array( '123', 123 ),
			'returns integer input unchanged' => array( 123, 123 ),
			'truncates decimal numeric string input' => array( '123.456', 123 ),
			'truncates decimal number input' => array( 123.456, 123 ),
		);
	}

	/**
	 * Provide invalid toInt cases.
	 *
	 * @return array<string, array{0:mixed}>
	 */
	public function provide_to_int_invalid_cases(): array {
		return array(
			'returns original string for non numeric input' => array( 'string' ),
			'returns original boolean for non numeric input' => array( true ),
			'returns original null for non numeric input' => array( null ),
			'returns original array for non numeric input' => array( array( 'array' ) ),
		);
	}

	/**
	 * Provide ceil cases.
	 *
	 * @return array<string, array{0:mixed,1:int}>
	 */
	public function provide_ceil_cases(): array {
		return array(
			'rounds decimal number upward' => array( 0.5, 1 ),
			'rounds one point five upward' => array( 1.5, 2 ),
			'trims numeric string before rounding upward' => array( ' 123.45 ', 124 ),
		);
	}

	/**
	 * Provide invalid ceil cases.
	 *
	 * @return array<string, array{0:mixed}>
	 */
	public function provide_ceil_invalid_cases(): array {
		return array(
			'returns original string for non numeric input' => array( 'string' ),
			'returns original boolean for non numeric input' => array( true ),
			'returns original null for non numeric input' => array( null ),
			'returns original array for non numeric input' => array( array( 'array' ) ),
		);
	}

	/**
	 * Provide round cases.
	 *
	 * @return array<string, array{0:mixed,1:array<int>,2:float|int}>
	 */
	public function provide_round_cases(): array {
		return array(
			'rounds half-up decimal number to nearest integer' => array( 0.5, array(), 1 ),
			'rounds one point five to nearest integer' => array( 1.5, array(), 2 ),
			'trims numeric string before rounding to nearest integer' => array( ' 123.45 ', array(), 123 ),
			'rounds numeric string to two decimal places' => array( '3.14159', array( 2 ), 3.14 ),
			'rounds numeric string up at the third decimal place' => array( '3.14159', array( 3 ), 3.142 ),
			'rounds numeric string down at the third decimal place' => array( '3.14149', array( 3 ), 3.141 ),
		);
	}

	/**
	 * Provide invalid round cases.
	 *
	 * @return array<string, array{0:mixed}>
	 */
	public function provide_round_invalid_cases(): array {
		return array(
			'returns original string for non numeric input' => array( 'string' ),
			'returns original boolean for non numeric input' => array( true ),
			'returns original null for non numeric input' => array( null ),
			'returns original array for non numeric input' => array( array( 'array' ) ),
		);
	}

	/**
	 * Provide floor cases.
	 *
	 * @return array<string, array{0:mixed,1:int}>
	 */
	public function provide_floor_cases(): array {
		return array(
			'rounds decimal number downward' => array( 0.5, 0 ),
			'rounds decimal number downward without trimming' => array( 123.45, 123 ),
			'trims numeric string before rounding downward' => array( ' 123.75 ', 123 ),
		);
	}

	/**
	 * Provide invalid floor cases.
	 *
	 * @return array<string, array{0:mixed}>
	 */
	public function provide_floor_invalid_cases(): array {
		return array(
			'returns original string for non numeric input' => array( 'string' ),
			'returns original boolean for non numeric input' => array( true ),
			'returns original null for non numeric input' => array( null ),
			'returns original array for non numeric input' => array( array( 'array' ) ),
		);
	}
}
