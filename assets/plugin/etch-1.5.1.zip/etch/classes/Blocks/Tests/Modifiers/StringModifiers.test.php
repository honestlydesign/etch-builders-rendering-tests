<?php
/**
 * String modifiers test class.
 *
 * @package Etch
 */

declare(strict_types=1);

namespace Etch\Blocks\Tests;

use Etch\Blocks\Global\Utilities\Modifiers\StringModifiers;
use WP_UnitTestCase;

/**
 * Class StringModifiersTest
 */
class StringModifiersTest extends WP_UnitTestCase {
	/**
	 * Test the deprecated uppercase alias returns a callable.
	 */
	public function test_to_uppercase_alias_returns_callable_in_string_seam() {
		$this->assertIsCallable( StringModifiers::get_modifier( 'toUppercase' ) );
	}

	/**
	 * Test the deprecated uppercase alias uppercases hello.
	 */
	public function test_to_uppercase_alias_uppercases_hello_in_string_seam() {
		$modifier = StringModifiers::get_modifier( 'toUppercase' );

		$this->assertEquals( 'HELLO', $modifier( 'hello' ) );
	}

	/**
	 * Test the canonical lowercase modifier returns a callable.
	 */
	public function test_to_lower_case_returns_callable_in_string_seam() {
		$this->assertIsCallable( StringModifiers::get_modifier( 'toLowerCase' ) );
	}

	/**
	 * Test the canonical lowercase modifier lowercases hello.
	 */
	public function test_to_lower_case_lowercases_hello_in_string_seam() {
		$modifier = StringModifiers::get_modifier( 'toLowerCase' );

		$this->assertEquals( 'hello', $modifier( 'HELLO' ) );
	}

	/**
	 * Test split returns a callable in the string seam.
	 */
	public function test_split_returns_callable_in_string_seam() {
		$this->assertIsCallable( StringModifiers::get_modifier( 'split' ) );
	}

	/**
	 * Test split splits comma-delimited strings in the string seam.
	 */
	public function test_split_splits_comma_delimited_strings_in_string_seam() {
		$modifier = StringModifiers::get_modifier( 'split' );

		$this->assertEquals( array( 'a', 'b', 'c' ), $modifier( 'a,b,c', ',' ) );
	}

	/**
	 * Test the string seam returns null outside string scope.
	 */
	public function test_string_seam_returns_null_when_modifier_is_outside_string_scope() {
		$this->assertNull( StringModifiers::get_modifier( 'join' ) );
	}

	/**
	 * Test toUpperCase returns expected value.
	 *
	 * @dataProvider provide_to_upper_case_cases
	 *
	 * @param mixed $value Input value.
	 * @param mixed $expected Expected value.
	 */
	public function test_to_upper_case_returns_expected_value( $value, $expected ) {
		$modifier = StringModifiers::get_modifier( 'toUpperCase' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Test toLowerCase returns expected value.
	 *
	 * @dataProvider provide_to_lower_case_cases
	 *
	 * @param mixed $value Input value.
	 * @param mixed $expected Expected value.
	 */
	public function test_to_lower_case_returns_expected_value( $value, $expected ) {
		$modifier = StringModifiers::get_modifier( 'toLowerCase' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Test toBool returns expected value.
	 *
	 * @dataProvider provide_to_bool_cases
	 *
	 * @param mixed $value Input value.
	 * @param bool  $expected Expected bool value.
	 */
	public function test_to_bool_returns_expected_value( $value, bool $expected ) {
		$modifier = StringModifiers::get_modifier( 'toBool' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Test trim returns expected value.
	 *
	 * @dataProvider provide_trim_cases
	 *
	 * @param mixed $value Input value.
	 * @param mixed $expected Expected value.
	 */
	public function test_trim_returns_expected_value( $value, $expected ) {
		$modifier = StringModifiers::get_modifier( 'trim' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Test ltrim returns expected value.
	 *
	 * @dataProvider provide_ltrim_cases
	 *
	 * @param mixed $value Input value.
	 * @param mixed $expected Expected value.
	 */
	public function test_ltrim_returns_expected_value( $value, $expected ) {
		$modifier = StringModifiers::get_modifier( 'ltrim' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Test rtrim returns expected value.
	 *
	 * @dataProvider provide_rtrim_cases
	 *
	 * @param mixed $value Input value.
	 * @param mixed $expected Expected value.
	 */
	public function test_rtrim_returns_expected_value( $value, $expected ) {
		$modifier = StringModifiers::get_modifier( 'rtrim' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Test split returns expected value.
	 *
	 * @dataProvider provide_split_cases
	 *
	 * @param mixed $value Input value.
	 * @param array $args Modifier args.
	 * @param mixed $expected Expected value.
	 */
	public function test_split_returns_expected_value( $value, array $args, $expected ) {
		$modifier = StringModifiers::get_modifier( 'split' );

		$this->assertEquals( $expected, $modifier( $value, ...$args ) );
	}

	/**
	 * Test truncateChars returns expected value.
	 *
	 * @dataProvider provide_truncate_chars_cases
	 *
	 * @param mixed $value Input value.
	 * @param array $args Modifier args.
	 * @param mixed $expected Expected value.
	 */
	public function test_truncate_chars_returns_expected_value( $value, array $args, $expected ) {
		$modifier = StringModifiers::get_modifier( 'truncateChars' );

		$this->assertEquals( $expected, $modifier( $value, ...$args ) );
	}

	/**
	 * Test truncateWords returns expected value.
	 *
	 * @dataProvider provide_truncate_words_cases
	 *
	 * @param mixed $value Input value.
	 * @param array $args Modifier args.
	 * @param mixed $expected Expected value.
	 */
	public function test_truncate_words_returns_expected_value( $value, array $args, $expected ) {
		$modifier = StringModifiers::get_modifier( 'truncateWords' );

		$this->assertEquals( $expected, $modifier( $value, ...$args ) );
	}

	/**
	 * Test urlEncode returns expected value.
	 *
	 * @dataProvider provide_url_encode_cases
	 *
	 * @param mixed $value Input value.
	 * @param mixed $expected Expected value.
	 */
	public function test_url_encode_returns_expected_value( $value, $expected ) {
		$modifier = StringModifiers::get_modifier( 'urlEncode' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Test urlDecode returns expected value.
	 *
	 * @dataProvider provide_url_decode_cases
	 *
	 * @param mixed $value Input value.
	 * @param mixed $expected Expected value.
	 */
	public function test_url_decode_returns_expected_value( $value, $expected ) {
		$modifier = StringModifiers::get_modifier( 'urlDecode' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Test stripTags returns expected value.
	 *
	 * @dataProvider provide_strip_tags_cases
	 *
	 * @param mixed $value Input value.
	 * @param mixed $expected Expected value.
	 */
	public function test_strip_tags_returns_expected_value( $value, $expected ) {
		$modifier = StringModifiers::get_modifier( 'stripTags' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Test replace returns expected value.
	 *
	 * @dataProvider provide_replace_cases
	 *
	 * @param mixed $value Input value.
	 * @param array $args Modifier args.
	 * @param mixed $expected Expected value.
	 */
	public function test_replace_returns_expected_value( $value, array $args, $expected ) {
		$modifier = StringModifiers::get_modifier( 'replace' );

		$this->assertEquals( $expected, $modifier( $value, ...$args ) );
	}

	/**
	 * Test replaceAll returns expected value.
	 *
	 * @dataProvider provide_replace_all_cases
	 *
	 * @param mixed $value Input value.
	 * @param array $args Modifier args.
	 * @param mixed $expected Expected value.
	 */
	public function test_replace_all_returns_expected_value( $value, array $args, $expected ) {
		$modifier = StringModifiers::get_modifier( 'replaceAll' );

		$this->assertEquals( $expected, $modifier( $value, ...$args ) );
	}

	/**
	 * Test startsWith returns expected value.
	 *
	 * @dataProvider provide_starts_with_cases
	 *
	 * @param mixed $value Input value.
	 * @param array $args Modifier args.
	 * @param mixed $expected Expected value.
	 */
	public function test_starts_with_returns_expected_value( $value, array $args, $expected ) {
		$modifier = StringModifiers::get_modifier( 'startsWith' );

		$this->assertEquals( $expected, $modifier( $value, ...$args ) );
	}

	/**
	 * Test endsWith returns expected value.
	 *
	 * @dataProvider provide_ends_with_cases
	 *
	 * @param mixed $value Input value.
	 * @param array $args Modifier args.
	 * @param mixed $expected Expected value.
	 */
	public function test_ends_with_returns_expected_value( $value, array $args, $expected ) {
		$modifier = StringModifiers::get_modifier( 'endsWith' );

		$this->assertEquals( $expected, $modifier( $value, ...$args ) );
	}

	/**
	 * Test toString returns expected value.
	 *
	 * @dataProvider provide_to_string_cases
	 *
	 * @param mixed  $value Input value.
	 * @param string $expected Expected string value.
	 */
	public function test_to_string_returns_expected_value( $value, string $expected ) {
		$modifier = StringModifiers::get_modifier( 'toString' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Test toSlug returns expected value.
	 *
	 * @dataProvider provide_to_slug_cases
	 *
	 * @param mixed $value Input value.
	 * @param mixed $expected Expected value.
	 */
	public function test_to_slug_returns_expected_value( $value, $expected ) {
		$modifier = StringModifiers::get_modifier( 'toSlug' );

		$this->assertEquals( $expected, $modifier( $value ) );
	}

	/**
	 * Provide toUpperCase cases.
	 *
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	public function provide_to_upper_case_cases(): array {
		return array(
			'uppercases lowercase input' => array( 'hello', 'HELLO' ),
			'uppercases mixed case input' => array( 'hElLo', 'HELLO' ),
			'preserves numeric string input' => array( '42', '42' ),
			'returns original integer when input is not a string' => array( 42, 42 ),
			'returns original boolean when input is not a string' => array( true, true ),
		);
	}

	/**
	 * Provide toLowerCase cases.
	 *
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	public function provide_to_lower_case_cases(): array {
		return array(
			'lowercases uppercase input' => array( 'HELLO', 'hello' ),
			'lowercases mixed case input' => array( 'HeLLo', 'hello' ),
			'preserves numeric string input' => array( '42', '42' ),
			'returns original integer when input is not a string' => array( 42, 42 ),
			'returns original boolean when input is not a string' => array( true, true ),
		);
	}

	/**
	 * Provide toBool cases.
	 *
	 * @return array<string, array{0:mixed,1:bool}>
	 */
	public function provide_to_bool_cases(): array {
		return array(
			'string true' => array( 'true', true ),
			'boolean true' => array( true, true ),
			'string one' => array( '1', true ),
			'numeric string greater than zero' => array( '222', true ),
			'number greater than zero' => array( 222, true ),
			'yes alias' => array( 'yes', true ),
			'y alias' => array( 'y', true ),
			'on alias' => array( 'on', true ),
			'string false' => array( 'false', false ),
			'boolean false' => array( false, false ),
			'string zero' => array( '0', false ),
			'number zero' => array( 0, false ),
			'no alias' => array( 'no', false ),
			'n alias' => array( 'n', false ),
			'off alias' => array( 'off', false ),
			'empty string' => array( '', false ),
			'null input' => array( null, false ),
		);
	}

	/**
	 * Provide trim cases.
	 *
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	public function provide_trim_cases(): array {
		return array_merge(
			array(
				'trims spaces on both sides' => array( '  hello  ', 'hello' ),
				'trims tabs and newlines on both sides' => array( "\t\nhello\t\n", 'hello' ),
				'trims leading spaces only' => array( '   spaces at beginning', 'spaces at beginning' ),
				'trims trailing spaces only' => array( 'spaces at end   ', 'spaces at end' ),
			),
			$this->provide_non_string_passthrough_cases( 'trim' ),
		);
	}

	/**
	 * Provide ltrim cases.
	 *
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	public function provide_ltrim_cases(): array {
		return $this->build_whitespace_modifier_cases( $this->provide_ltrim_valid_cases(), 'ltrim' );
	}

	/**
	 * Provide rtrim cases.
	 *
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	public function provide_rtrim_cases(): array {
		return $this->build_whitespace_modifier_cases( $this->provide_rtrim_valid_cases(), 'rtrim' );
	}

	/**
	 * Provide passthrough cases shared by string whitespace modifiers.
	 *
	 * @param string $modifier Modifier name used in the dataset label.
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	private function provide_non_string_passthrough_cases( string $modifier ): array {
		return array(
			sprintf( '%s returns original integer when input is not a string', $modifier ) => array( 42, 42 ),
			sprintf( '%s returns original boolean when input is not a string', $modifier ) => array( true, true ),
			sprintf( '%s returns original null when input is not a string', $modifier ) => array( null, null ),
			sprintf( '%s returns original array when input is not a string', $modifier ) => array( array( 'array' ), array( 'array' ) ),
		);
	}

	/**
	 * Build cases shared by whitespace modifiers.
	 *
	 * @param array<string, array{0:mixed,1:mixed}> $valid_cases Modifier-specific valid cases.
	 * @param string                                $modifier Modifier name used in dataset labels.
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	private function build_whitespace_modifier_cases( array $valid_cases, string $modifier ): array {
		return array_merge( $valid_cases, $this->provide_non_string_passthrough_cases( $modifier ) );
	}

	/**
	 * Provide valid ltrim cases.
	 *
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	private function provide_ltrim_valid_cases(): array {
		return array(
			'trims leading spaces and preserves trailing spaces' => array( '  hello', 'hello' ),
			'trims leading tabs and newlines' => array( "\t\nhello", 'hello' ),
			'preserves trailing space when no leading whitespace exists' => array( 'spaces at end ', 'spaces at end ' ),
		);
	}

	/**
	 * Provide valid rtrim cases.
	 *
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	private function provide_rtrim_valid_cases(): array {
		return array(
			'trims trailing spaces' => array( 'hello  ', 'hello' ),
			'trims trailing tabs and newlines' => array( "hello\t\n", 'hello' ),
			'preserves leading whitespace when no trailing whitespace exists' => array( '  spaces at beginning', '  spaces at beginning' ),
		);
	}

	/**
	 * Provide split cases.
	 *
	 * @return array<string, array{0:mixed,1:array,2:mixed}>
	 */
	public function provide_split_cases(): array {
		return array(
			'splits by comma separator' => array( 'a,b,c', array( ',' ), array( 'a', 'b', 'c' ) ),
			'splits by space separator' => array( 'one two three', array( ' ' ), array( 'one', 'two', 'three' ) ),
			'splits by pipe separator' => array( 'apple|banana|cherry', array( '|' ), array( 'apple', 'banana', 'cherry' ) ),
			'uses comma separator by default' => array( 'a,b,c', array(), array( 'a', 'b', 'c' ) ),
			'uses comma separator by default for words' => array( 'one,two,three', array(), array( 'one', 'two', 'three' ) ),
			'returns original integer when input is not string' => array( 42, array( ',' ), 42 ),
			'returns original boolean when input is not string' => array( true, array( ',' ), true ),
			'returns original null when input is not string' => array( null, array( ',' ), null ),
			'returns original array when input is already array' => array( array( 'array' ), array( ',' ), array( 'array' ) ),
		);
	}

	/**
	 * Provide truncateChars cases.
	 *
	 * @return array<string, array{0:mixed,1:array,2:mixed}>
	 */
	public function provide_truncate_chars_cases(): array {
		return $this->build_string_modifier_cases_with_args( $this->provide_truncate_chars_valid_cases(), 'truncateChars', array( 10 ) );
	}

	/**
	 * Provide truncateWords cases.
	 *
	 * @return array<string, array{0:mixed,1:array,2:mixed}>
	 */
	public function provide_truncate_words_cases(): array {
		return $this->build_string_modifier_cases_with_args( $this->provide_truncate_words_valid_cases(), 'truncateWords', array( 2 ) );
	}

	/**
	 * Provide urlEncode cases.
	 *
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	public function provide_url_encode_cases(): array {
		return $this->build_string_modifier_cases( $this->provide_url_encode_valid_cases(), 'urlEncode' );
	}

	/**
	 * Provide urlDecode cases.
	 *
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	public function provide_url_decode_cases(): array {
		return $this->build_string_modifier_cases( $this->provide_url_decode_valid_cases(), 'urlDecode' );
	}

	/**
	 * Provide stripTags cases.
	 *
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	public function provide_strip_tags_cases(): array {
		return array_merge(
			array(
				'removes nested inline tags' => array( '<p>Hello <strong>World</strong></p>', 'Hello World' ),
				'removes link tags and preserves text' => array( '<a href="#">Link</a>', 'Link' ),
				'preserves plain text without tags' => array( 'No tags here', 'No tags here' ),
				'preserves empty string when stripping tags' => array( '', '' ),
				'removes nested block tags from complex markup' => array( '<div><h1>Title</h1><p>This is a <em>paragraph</em>.</p></div>', 'TitleThis is a paragraph.' ),
				'removes self-closing image tags' => array( '<img src="image.jpg" alt="Image"/>', '' ),
			),
			$this->provide_string_modifier_passthrough_cases( 'stripTags' ),
		);
	}

	/**
	 * Provide valid truncateChars cases.
	 *
	 * @return array<string, array{0:mixed,1:array,2:mixed}>
	 */
	private function provide_truncate_chars_valid_cases(): array {
		return array(
			'truncates string to requested character count' => array( 'The quick brown fox jumps over the lazy dog', array( 10 ), 'The quick ...' ),
			'accepts numeric string character count' => array( 'The quick brown fox jumps over the lazy dog', array( '10' ), 'The quick ...' ),
			'returns original string when shorter than requested character count' => array( 'Short', array( 10 ), 'Short' ),
			'uses custom ellipsis string when provided' => array( 'The quick brown fox jumps over the lazy dog', array( 10, ' (more)' ), 'The quick  (more)' ),
		);
	}

	/**
	 * Provide valid truncateWords cases.
	 *
	 * @return array<string, array{0:mixed,1:array,2:mixed}>
	 */
	private function provide_truncate_words_valid_cases(): array {
		return array(
			'truncates string to requested word count' => array( 'The quick brown fox jumps over the lazy dog', array( 4 ), 'The quick brown fox...' ),
			'accepts numeric string word count' => array( 'The quick brown fox jumps over the lazy dog', array( '4' ), 'The quick brown fox...' ),
			'returns original string when shorter than requested word count' => array( 'The quick brown fox', array( 10 ), 'The quick brown fox' ),
			'uses custom ellipsis string when provided' => array( 'The quick brown fox jumps over the lazy dog', array( 4, ' (more)' ), 'The quick brown fox (more)' ),
		);
	}

	/**
	 * Provide valid urlEncode cases.
	 *
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	private function provide_url_encode_valid_cases(): array {
		return array(
			'url-encodes plain text with spaces' => array( 'Hello World!', 'Hello%20World!' ),
			'preserves empty string when encoding' => array( '', '' ),
			'url-encodes reserved characters' => array( 'a+b=c&d', 'a%2Bb%3Dc%26d' ),
		);
	}

	/**
	 * Provide valid urlDecode cases.
	 *
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	private function provide_url_decode_valid_cases(): array {
		return array(
			'url-decodes plain text with spaces' => array( 'Hello%20World!', 'Hello World!' ),
			'preserves empty string when decoding' => array( '', '' ),
			'url-decodes reserved characters' => array( 'a%2Bb%3Dc%26d', 'a+b=c&d' ),
		);
	}

	/**
	 * Provide replace cases.
	 *
	 * @return array<string, array{0:mixed,1:array,2:mixed}>
	 */
	public function provide_replace_cases(): array {
		return $this->build_replace_family_cases(
			array(
				'replaces first matching occurrence in a string' => array( 'hello world', array( 'hel', 'hey' ), 'heylo world' ),
				'replaces only the first matching occurrence when multiple exist' => array( 'hello hello', array( 'hello', 'hey' ), 'hey hello' ),
			),
			'replace'
		);
	}

	/**
	 * Provide replaceAll cases.
	 *
	 * @return array<string, array{0:mixed,1:array,2:mixed}>
	 */
	public function provide_replace_all_cases(): array {
		return $this->build_replace_family_cases(
			array(
				'replaces all matching occurrences in a string' => array( 'hello hello hello', array( 'hello', 'hey' ), 'hey hey hey' ),
			),
			'replaceAll'
		);
	}

	/**
	 * Provide valid startsWith cases.
	 *
	 * @return array<string, array{0:mixed,1:array,2:bool}>
	 */
	private function provide_starts_with_valid_cases(): array {
		return array(
			'returns true when string starts with full prefix' => array( 'Hello World', array( 'Hello' ), true ),
			'returns true when string starts with first character' => array( 'Hello World', array( 'H' ), true ),
			'returns false when string does not start with requested word' => array( 'Hello World', array( 'World' ), false ),
			'returns false when casing does not match start of string' => array( 'Hello World', array( 'h' ), false ),
		);
	}

	/**
	 * Provide valid endsWith cases.
	 *
	 * @return array<string, array{0:mixed,1:array,2:bool}>
	 */
	private function provide_ends_with_valid_cases(): array {
		return array(
			'returns true when string ends with full suffix' => array( 'Hello World', array( 'World' ), true ),
			'returns true when string ends with last character' => array( 'Hello World', array( 'd' ), true ),
			'returns false when string does not end with requested word' => array( 'Hello World', array( 'Hello' ), false ),
			'returns false when casing does not match end of string' => array( 'Hello World', array( 'D' ), false ),
		);
	}

	/**
	 * Provide startsWith cases.
	 *
	 * @return array<string, array{0:mixed,1:array,2:mixed}>
	 */
	public function provide_starts_with_cases(): array {
		return $this->build_string_edge_match_cases(
			$this->provide_starts_with_valid_cases(),
			'startsWith',
			array(
				'number'  => array( '4' ),
				'boolean' => array( 't' ),
				'null'    => array( 'n' ),
				'array'   => array( 'a' ),
			)
		);
	}

	/**
	 * Provide endsWith cases.
	 *
	 * @return array<string, array{0:mixed,1:array,2:mixed}>
	 */
	public function provide_ends_with_cases(): array {
		return $this->build_string_edge_match_cases(
			$this->provide_ends_with_valid_cases(),
			'endsWith',
			array(
				'number'  => array( '2' ),
				'boolean' => array( 'e' ),
				'null'    => array( 'l' ),
				'array'   => array( 'y' ),
			)
		);
	}

	/**
	 * Provide toString cases.
	 *
	 * @return array<string, array{0:mixed,1:string}>
	 */
	public function provide_to_string_cases(): array {
		return array(
			'preserves string input' => array( 'string', 'string' ),
			'converts integer one input' => array( 1, '1' ),
			'converts zero input' => array( 0, '0' ),
			'converts boolean true input' => array( true, 'true' ),
			'converts boolean false input' => array( false, 'false' ),
			'converts null input to empty string' => array( null, '' ),
		);
	}

	/**
	 * Provide toSlug cases.
	 *
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	public function provide_to_slug_cases(): array {
		return array(
			'slugifies plain title' => array( 'Hello World', 'hello-world' ),
			'slugifies accented title' => array( 'Hello World á', 'hello-world-a' ),
			'slugifies underscored and hyphenated title' => array( '_Hello World á-', 'hello-world-a' ),
			'slugifies umlaut title' => array( 'Über Theme', 'uber-theme' ),
			'slugifies cafe title with transliteration' => array( 'Über Cool Café', 'uber-cool-cafe' ),
			'slugifies polish title' => array( 'Strona główna', 'strona-glowna' ),
			'slugifies dense polish diacritics' => array( 'śćńóżź', 'scnozz' ),
			'slugifies umlaut-heavy title' => array( 'über äö test', 'uber-ao-test' ),
			'slugifies accent and punctuation title' => array( 'Hello Wôrld!', 'hello-world' ),
			'returns original integer when input is not a string' => array( 42, 42 ),
			'returns original boolean when input is not a string' => array( true, true ),
			'returns original null when input is not a string' => array( null, null ),
			'returns original array when input is not a string' => array( array( 'array' ), array( 'array' ) ),
		);
	}

	/**
	 * Provide passthrough cases for string modifiers without extra args.
	 *
	 * @param string $modifier Modifier name used in the dataset label.
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	private function provide_string_modifier_passthrough_cases( string $modifier ): array {
		return array(
			sprintf( '%s returns original integer when input is not a string', $modifier ) => array( 42, 42 ),
			sprintf( '%s returns original boolean when input is not a string', $modifier ) => array( true, true ),
			sprintf( '%s returns original null when input is not a string', $modifier ) => array( null, null ),
			sprintf( '%s returns original array when input is not a string', $modifier ) => array( array( 'array' ), array( 'array' ) ),
		);
	}

	/**
	 * Build cases shared by string modifiers without extra args.
	 *
	 * @param array<string, array{0:mixed,1:mixed}> $valid_cases Modifier-specific valid cases.
	 * @param string                                $modifier Modifier name used in dataset labels.
	 * @return array<string, array{0:mixed,1:mixed}>
	 */
	private function build_string_modifier_cases( array $valid_cases, string $modifier ): array {
		return array_merge( $valid_cases, $this->provide_string_modifier_passthrough_cases( $modifier ) );
	}

	/**
	 * Provide passthrough cases for string modifiers with args.
	 *
	 * @param string $modifier Modifier name used in the dataset label.
	 * @param array  $args Modifier arguments.
	 * @return array<string, array{0:mixed,1:array,2:mixed}>
	 */
	private function provide_string_modifier_passthrough_cases_with_args( string $modifier, array $args ): array {
		return array(
			sprintf( '%s returns original integer when input is not a string', $modifier ) => array( 42, $args, 42 ),
			sprintf( '%s returns original boolean when input is not a string', $modifier ) => array( true, $args, true ),
			sprintf( '%s returns original null when input is not a string', $modifier ) => array( null, $args, null ),
			sprintf( '%s returns original array when input is not a string', $modifier ) => array( array( 'array' ), $args, array( 'array' ) ),
		);
	}

	/**
	 * Build cases shared by string modifiers with args.
	 *
	 * @param array<string, array{0:mixed,1:array,2:mixed}> $valid_cases Modifier-specific valid cases.
	 * @param string                                        $modifier Modifier name used in dataset labels.
	 * @param array                                         $args Passthrough args for non-string inputs.
	 * @return array<string, array{0:mixed,1:array,2:mixed}>
	 */
	private function build_string_modifier_cases_with_args( array $valid_cases, string $modifier, array $args ): array {
		return array_merge( $valid_cases, $this->provide_string_modifier_passthrough_cases_with_args( $modifier, $args ) );
	}

	/**
	 * Build cases shared by replace-style modifiers.
	 *
	 * @param array<string, array{0:mixed,1:array,2:mixed}> $valid_cases Modifier-specific valid cases.
	 * @param string                                        $modifier Modifier name used in dataset labels.
	 * @return array<string, array{0:mixed,1:array,2:mixed}>
	 */
	private function build_replace_family_cases( array $valid_cases, string $modifier ): array {
		return array_merge(
			$valid_cases,
			array(
				sprintf( 'returns original integer when %s input is not a string', $modifier ) => array( 123, array( 'a', 'b' ), 123 ),
				sprintf( 'returns original array when %s input is not a string', $modifier ) => array( array( 'a' ), array( 'a', 'b' ), array( 'a' ) ),
				'returns original string when search value is not a string' => array( 'hello', array( 123, 'b' ), 'hello' ),
				'returns original string when replace value is not a string' => array( 'hello', array( 'h', 123 ), 'hello' ),
				'returns original string when search value is not found' => array( 'hello world', array( 'xyz', 'abc' ), 'hello world' ),
			)
		);
	}

	/**
	 * Build cases shared by startsWith and endsWith.
	 *
	 * @param array<string, array{0:mixed,1:array,2:bool}> $valid_cases Modifier-specific valid cases.
	 * @param string                                       $modifier Modifier name used in dataset labels.
	 * @param array<string, array>                         $passthrough_args Args keyed by input type.
	 * @return array<string, array{0:mixed,1:array,2:bool}>
	 */
	private function build_string_edge_match_cases( array $valid_cases, string $modifier, array $passthrough_args ): array {
		return array_merge(
			$valid_cases,
			array(
				sprintf( 'returns false when %s input is a number', $modifier ) => array( 42, $passthrough_args['number'], false ),
				sprintf( 'returns false when %s input is a boolean', $modifier ) => array( true, $passthrough_args['boolean'], false ),
				sprintf( 'returns false when %s input is null', $modifier ) => array( null, $passthrough_args['null'], false ),
				sprintf( 'returns false when %s input is an array', $modifier ) => array( array( 'array' ), $passthrough_args['array'], false ),
			)
		);
	}
}
