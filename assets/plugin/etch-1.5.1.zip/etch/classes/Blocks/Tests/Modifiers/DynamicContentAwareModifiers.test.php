<?php
/**
 * Dynamic-content-aware modifiers test class.
 *
 * @package Etch
 */

declare(strict_types=1);

namespace Etch\Blocks\Tests;

use Etch\Blocks\Global\Utilities\Modifiers\DynamicContentAwareModifiers;
use WP_UnitTestCase;

/**
 * Class DynamicContentAwareModifiersTest
 */
class DynamicContentAwareModifiersTest extends WP_UnitTestCase {
	/**
	 * Test applyData returns callable in the dynamic-content-aware seam.
	 */
	public function test_apply_data_returns_callable_in_the_dynamic_content_aware_seam() {
		$this->assertIsCallable( DynamicContentAwareModifiers::get_modifier( 'applyData' ) );
	}

	/**
	 * Test applyData modifier resolves templates against sources.
	 */
	public function test_apply_data_modifier_resolves_templates_against_sources() {
		$sources = array(
			array(
				'key'    => 'person',
				'source' => array(
					'name' => 'Bob',
				),
			),
		);

		$modifier = DynamicContentAwareModifiers::get_modifier(
			'applyData',
			array(
				'sources' => $sources,
			)
		);

		$this->assertSame(
			'Hello my name is Bob',
			$modifier( 'Hello my name is {person.name}' )
		);
	}

	/**
	 * Test dynamic-content-aware seam returns null outside category scope.
	 */
	public function test_dynamic_content_aware_seam_returns_null_when_modifier_is_outside_scope() {
		$this->assertNull( DynamicContentAwareModifiers::get_modifier( 'concat' ) );
	}
}
