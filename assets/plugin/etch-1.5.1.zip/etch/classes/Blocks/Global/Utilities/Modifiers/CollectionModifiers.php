<?php
/**
 * Collection modifiers for Blocks dynamic content.
 *
 * @package Etch\Blocks\Global\Utilities\Modifiers
 */

declare(strict_types=1);

namespace Etch\Blocks\Global\Utilities\Modifiers;

use Etch\Blocks\Utilities\EtchTypeAsserter;

/**
 * Collection modifiers registry.
 */
class CollectionModifiers {
	/**
	 * Registered collection modifier handlers.
	 *
	 * @var array<string, string>
	 */
	private const HANDLERS = array(
		'indexOf'        => 'index_of_modifier',
		'join'           => 'join_modifier',
		'concat'         => 'concat_modifier',
		'length'         => 'length_modifier',
		'reverse'        => 'reverse_modifier',
		'at'             => 'at_modifier',
		'slice'          => 'slice_modifier',
		'includes'       => 'includes_modifier',
		'pluck'          => 'pluck_modifier',
		'unserializePHP' => 'unserialize_php_modifier',
		'values'         => 'values_modifier',
		'keys'           => 'keys_modifier',
		'intersects'     => 'intersects_modifier',
	);

	/**
	 * Deprecated collection modifier aliases.
	 *
	 * @var array<string, string>
	 */
	private const ALIASES = array(
		'unserializePhp' => 'unserializePHP',
	);

	/**
	 * Get a collection modifier function by name.
	 *
	 * @param string $method The modifier method name.
	 * @return callable|null
	 */
	public static function get_modifier( string $method ) {
		$method  = self::ALIASES[ $method ] ?? $method;
		$handler = self::HANDLERS[ $method ] ?? null;

		return null === $handler ? null : \Closure::fromCallable( array( self::class, $handler ) );
	}

	/**
	 * Find the position of an item in a string or array.
	 *
	 * @param mixed $value Value to search.
	 * @param mixed ...$args Search args.
	 * @return mixed
	 */
	private static function index_of_modifier( $value, ...$args ) {
		if ( ! array_key_exists( 0, $args ) ) {
			return -1;
		}

		$search_value = $args[0];

		if ( is_string( $value ) ) {
			$position = strpos( $value, EtchTypeAsserter::to_string( $search_value ) );

			return false === $position ? -1 : $position;
		}

		if ( is_array( $value ) ) {
			$index = array_search( $search_value, $value, true );

			return false === $index ? -1 : $index;
		}

		return -1;
	}

	/**
	 * Join an array into a string.
	 *
	 * @param mixed $value Value to join.
	 * @param mixed ...$args Join args.
	 * @return mixed
	 */
	private static function join_modifier( $value, ...$args ) {
		if ( ! is_array( $value ) ) {
			return $value;
		}

		$separator = ',';
		if ( isset( $args[0] ) && is_string( $args[0] ) ) {
			$separator = $args[0];
		}

		return implode( $separator, $value );
	}

	/**
	 * Concatenate arrays or strings.
	 *
	 * @param mixed $value Value to extend.
	 * @param mixed ...$args Concat args.
	 * @return mixed
	 */
	private static function concat_modifier( $value, ...$args ) {
		if ( is_array( $value ) ) {
			return array_merge(
				array_values( $value ),
				...array_map(
					static fn( $arg ) => is_array( $arg ) ? array_values( $arg ) : array( $arg ),
					$args
				)
			);
		}

		if ( ! is_string( $value ) ) {
			return $value;
		}

		$concat_string = '';
		foreach ( $args as $arg ) {
			$concat_string .= EtchTypeAsserter::to_string( $arg );
		}

		return $value . $concat_string;
	}

	/**
	 * Get the length of a string or list array.
	 *
	 * @param mixed $value Value to measure.
	 * @return mixed
	 */
	private static function length_modifier( $value ) {
		if ( is_string( $value ) ) {
			return mb_strlen( $value );
		}

		if ( self::is_list_array( $value ) ) {
			return count( $value );
		}

		return $value;
	}

	/**
	 * Reverse a string or array.
	 *
	 * @param mixed $value Value to reverse.
	 * @return mixed
	 */
	private static function reverse_modifier( $value ) {
		if ( is_string( $value ) ) {
			return strrev( $value );
		}

		if ( is_array( $value ) ) {
			return array_reverse( $value );
		}

		return $value;
	}

	/**
	 * Return an item at a list index.
	 *
	 * @param mixed $value List value.
	 * @param mixed ...$args Access args.
	 * @return mixed
	 */
	private static function at_modifier( $value, ...$args ) {
		if ( ! self::is_list_array( $value ) || ! array_key_exists( 0, $args ) ) {
			return $value;
		}

		$index = 0;
		if ( self::is_numeric_type( $args[0] ) ) {
			$index = (int) $args[0];
		}

		$array_length = count( $value );

		if ( $index < 0 ) {
			$index = $array_length + $index;
		}

		if ( isset( $value[ $index ] ) ) {
			return $value[ $index ];
		}

		return null;
	}

	/**
	 * Slice a list array.
	 *
	 * @param mixed $value List value.
	 * @param mixed ...$args Slice args.
	 * @return mixed
	 */
	private static function slice_modifier( $value, ...$args ) {
		if ( ! self::is_list_array( $value ) || ! array_key_exists( 0, $args ) ) {
			return $value;
		}

		$start        = 0;
		$array_length = count( $value );
		$end          = $array_length;

		if ( self::is_numeric_type( $args[0] ) ) {
			$start = (int) $args[0];
		}

		if ( isset( $args[1] ) && self::is_numeric_type( $args[1] ) ) {
			$end = (int) $args[1];
		}

		if ( $start < 0 ) {
			$start = max( 0, $array_length + $start );
		}

		if ( $end < 0 ) {
			$end = max( 0, $array_length + $end );
		}

		$start  = min( $start, $array_length );
		$length = max( 0, $end - $start );

		return array_slice( $value, $start, $length );
	}

	/**
	 * Check whether a string or array includes a value.
	 *
	 * @param mixed $value Value to search.
	 * @param mixed ...$args Search args.
	 * @return mixed
	 */
	private static function includes_modifier( $value, ...$args ) {
		if ( ! array_key_exists( 0, $args ) ) {
			return false;
		}

		$search_value = $args[0];
		$true_value   = $args[1] ?? true;
		$false_value  = $args[2] ?? false;

		if ( is_string( $value ) ) {
			return str_contains( $value, EtchTypeAsserter::to_string( $search_value ) ) ? $true_value : $false_value;
		}

		if ( is_array( $value ) ) {
			return in_array( $search_value, $value, true ) ? $true_value : $false_value;
		}

		return false;
	}

	/**
	 * Pluck a nested property from each list item.
	 *
	 * @param mixed $value List value.
	 * @param mixed ...$args Pluck args.
	 * @return array<mixed>
	 */
	private static function pluck_modifier( $value, ...$args ): array {
		if ( ! self::is_list_array( $value ) || ! array_key_exists( 0, $args ) ) {
			return array();
		}

		$property = EtchTypeAsserter::to_string( $args[0] );
		$keys     = explode( '.', $property );

		return array_map(
			static fn( $item ) => self::resolve_plucked_value( $item, $keys ),
			$value
		);
	}

	/**
	 * Unserialize a PHP value safely.
	 *
	 * @param mixed $value Value to unserialize.
	 * @return mixed
	 */
	private static function unserialize_php_modifier( $value ) {
		if ( ! is_string( $value ) ) {
			return $value;
		}

		$output = maybe_unserialize( $value );

		if ( is_object( $output ) ) {
			return null;
		}

		return $output;
	}

	/**
	 * Return array values.
	 *
	 * @param mixed $value Value to normalize.
	 * @return mixed
	 */
	private static function values_modifier( $value ) {
		if ( ! is_array( $value ) ) {
			return $value;
		}

		return array_values( $value );
	}

	/**
	 * Return associative array keys.
	 *
	 * @param mixed $value Value to inspect.
	 * @return mixed
	 */
	private static function keys_modifier( $value ) {
		if ( ! is_array( $value ) || array_is_list( $value ) ) {
			return $value;
		}

		return array_keys( $value );
	}

	/**
	 * Check whether two arrays intersect.
	 *
	 * @param mixed $value Value to compare.
	 * @param mixed ...$args Comparison args.
	 * @return mixed
	 */
	private static function intersects_modifier( $value, ...$args ) {
		if ( ! is_array( $value ) || ! array_key_exists( 0, $args ) ) {
			return false;
		}

		$compare_value = $args[0];

		if ( ! is_array( $compare_value ) ) {
			return false;
		}

		$true_value  = $args[1] ?? true;
		$false_value = $args[2] ?? false;

		return array_intersect( $value, $compare_value ) ? $true_value : $false_value;
	}

	/**
	 * Resolve a dotted property path from an item.
	 *
	 * @param mixed         $item Current collection item.
	 * @param array<string> $keys Property path.
	 * @return mixed
	 */
	private static function resolve_plucked_value( $item, array $keys ) {
		$current = $item;

		foreach ( $keys as $key ) {
			if ( ! is_object( $current ) && ! is_array( $current ) ) {
				return null;
			}

			if ( is_object( $current ) ) {
				$current = $current->$key ?? null;
			} else {
				$current = $current[ $key ] ?? null;
			}
		}

		return $current;
	}

	/**
	 * Checks if a value is a numeric type (int or float), excluding numeric strings.
	 *
	 * @param mixed $value The value to check.
	 * @phpstan-assert-if-true int|float $value
	 * @return bool
	 */
	private static function is_numeric_type( $value ): bool {
		return is_numeric( $value ) && ! is_string( $value );
	}

	/**
	 * Checks if a value is a list array (numeric keys only).
	 *
	 * @param mixed $value The value to check.
	 * @phpstan-assert-if-true list<mixed> $value
	 * @return bool
	 */
	private static function is_list_array( $value ): bool {
		return is_array( $value ) && array_is_list( $value );
	}
}
