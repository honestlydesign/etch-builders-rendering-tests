<?php
/**
 * SourceResolver test class.
 *
 * @package Etch
 */

declare(strict_types=1);

namespace Etch\Blocks\Global\Utilities\Tests;

use Etch\Blocks\Global\Utilities\SourceResolver;
use WP_UnitTestCase;

/**
 * Class SourceResolverTest
 */
class SourceResolverTest extends WP_UnitTestCase {

	/**
	 * Build a source entry.
	 *
	 * @param array  $data Source data.
	 * @param string $key  Source key.
	 * @return array
	 */
	private function source( array $data, string $key = 'item' ): array {
		return array(
			'key' => $key,
			'source' => $data,
		);
	}

	/**
	 * Test returns empty string when expression is empty.
	 */
	public function test_returns_empty_string_when_expression_is_empty(): void {
		$result = SourceResolver::resolve_from_sources( '', array(), null );

		$this->assertSame( '', $result );
	}

	/**
	 * Test returns null when sources are empty.
	 */
	public function test_returns_null_when_sources_are_empty(): void {
		$result = SourceResolver::resolve_from_sources( 'item.title', array(), null );

		$this->assertNull( $result );
	}

	/**
	 * Test resolves simple property.
	 */
	public function test_resolves_simple_property(): void {
		$result = SourceResolver::resolve_from_sources(
			'item.title',
			array( $this->source( array( 'title' => 'Hello' ) ) ),
		);

		$this->assertSame( 'Hello', $result );
	}

	/**
	 * Test resolves nested property.
	 */
	public function test_resolves_nested_property(): void {
		$result = SourceResolver::resolve_from_sources(
			'item.meta.description',
			array( $this->source( array( 'meta' => array( 'description' => 'nested value' ) ) ) ),
		);

		$this->assertSame( 'nested value', $result );
	}

	/**
	 * Test returns null property as resolved value.
	 */
	public function test_returns_null_property_as_resolved_value(): void {
		$result = SourceResolver::resolve_from_sources(
			'item.title',
			array( $this->source( array( 'title' => null ) ) ),
		);

		$this->assertNull( $result );
	}

	/**
	 * Test null property does not fall through to next source.
	 */
	public function test_null_property_does_not_fall_through_to_next_source(): void {
		$sources = array(
			$this->source( array( 'title' => 'from parent' ) ),
			$this->source( array( 'title' => null ) ),
		);

		$result = SourceResolver::resolve_from_sources( 'item.title', $sources );

		$this->assertNull( $result );
	}

	/**
	 * Test falls through when property does not exist.
	 */
	public function test_falls_through_when_property_does_not_exist(): void {
		$sources = array(
			$this->source( array( 'title' => 'from parent' ) ),
			$this->source( array( 'other' => 'value' ) ),
		);

		$result = SourceResolver::resolve_from_sources( 'item.title', $sources );

		$this->assertSame( 'from parent', $result );
	}

	/**
	 * Test last source wins when both have key.
	 */
	public function test_last_source_wins_when_both_have_key(): void {
		$sources = array(
			$this->source( array( 'title' => 'first' ) ),
			$this->source( array( 'title' => 'second' ) ),
		);

		$result = SourceResolver::resolve_from_sources( 'item.title', $sources );

		$this->assertSame( 'second', $result );
	}

	/**
	 * Test defaults key to item.
	 */
	public function test_defaults_key_to_item(): void {
		$sources = array(
			array( 'source' => array( 'title' => 'no key set' ) ),
		);

		$result = SourceResolver::resolve_from_sources( 'item.title', $sources );

		$this->assertSame( 'no key set', $result );
	}

	/**
	 * Test returns null when expression matches no source.
	 */
	public function test_returns_null_when_expression_matches_no_source(): void {
		$result = SourceResolver::resolve_from_sources(
			'item.title',
			array( $this->source( array( 'title' => 'Hello' ), 'post' ) ),
		);

		$this->assertNull( $result );
	}

	/**
	 * Test resolves false as valid value.
	 */
	public function test_resolves_false_as_valid_value(): void {
		$result = SourceResolver::resolve_from_sources(
			'item.active',
			array( $this->source( array( 'active' => false ) ) ),
		);

		$this->assertSame( false, $result );
	}

	/**
	 * Test resolves zero as valid value.
	 */
	public function test_resolves_zero_as_valid_value(): void {
		$result = SourceResolver::resolve_from_sources(
			'item.count',
			array( $this->source( array( 'count' => 0 ) ) ),
		);

		$this->assertSame( 0, $result );
	}

	/**
	 * Test resolves empty string property as valid value.
	 */
	public function test_resolves_empty_string_property_as_valid_value(): void {
		$result = SourceResolver::resolve_from_sources(
			'item.name',
			array( $this->source( array( 'name' => '' ) ) ),
		);

		$this->assertSame( '', $result );
	}

	/**
	 * Test modifier runs when preceding property is missing.
	 */
	public function test_modifier_runs_when_preceding_property_is_missing(): void {
		$result = SourceResolver::resolve_from_sources(
			'props.date.equal(true,"yes","no")',
			array( $this->source( array(), 'props' ) ),
		);

		$this->assertSame( 'no', $result );
	}

	/**
	 * Test modifier runs when preceding property is null.
	 */
	public function test_modifier_runs_when_preceding_property_is_null(): void {
		$result = SourceResolver::resolve_from_sources(
			'props.date.equal(true,"yes","no")',
			array( $this->source( array( 'date' => null ), 'props' ) ),
		);

		$this->assertSame( 'no', $result );
	}

	/**
	 * Test modifier receives resolved value.
	 */
	public function test_modifier_receives_resolved_value(): void {
		$result = SourceResolver::resolve_from_sources(
			'props.date.equal(true,"yes","no")',
			array( $this->source( array( 'date' => true ), 'props' ) ),
		);

		$this->assertSame( 'yes', $result );
	}

	/**
	 * Test arithmetic modifier resolves source arguments.
	 */
	public function test_arithmetic_modifier_resolves_source_arguments(): void {
		$result = SourceResolver::resolve_from_sources(
			'props.total.add(site.offset)',
			array(
				$this->source( array( 'offset' => 3 ), 'site' ),
				$this->source( array( 'total' => 5 ), 'props' ),
			),
		);

		$this->assertSame( 8, $result );
	}

	/**
	 * Test arithmetic modifier returns null when preceding property is missing.
	 */
	public function test_arithmetic_modifier_returns_null_when_preceding_property_is_missing(): void {
		$result = SourceResolver::resolve_from_sources(
			'props.total.add(5)',
			array( $this->source( array(), 'props' ) ),
		);

		$this->assertNull( $result );
	}

	/**
	 * Test arithmetic modifier returns null when preceding property is null.
	 */
	public function test_arithmetic_modifier_returns_null_when_preceding_property_is_null(): void {
		$result = SourceResolver::resolve_from_sources(
			'props.total.add(5)',
			array( $this->source( array( 'total' => null ), 'props' ) ),
		);

		$this->assertNull( $result );
	}

	/**
	 * Test unresolved expression with no modifier falls through.
	 */
	public function test_unresolved_expression_with_no_modifier_falls_through(): void {
		$sources = array(
			$this->source( array( 'a' => 'value' ) ),
			$this->source( array() ),
		);

		$result = SourceResolver::resolve_from_sources( 'item.missing.nested', $sources );

		$this->assertNull( $result );
	}
}
