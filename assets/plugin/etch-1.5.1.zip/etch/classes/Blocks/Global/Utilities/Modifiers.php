<?php
/**
 * Modifiers class for Blocks dynamic content.
 *
 * @package Etch\Blocks\Global\Utilities
 */

declare(strict_types=1);

namespace Etch\Blocks\Global\Utilities;

use Etch\Blocks\Global\Utilities\Modifiers\ArithmeticModifiers;
use Etch\Blocks\Global\Utilities\Modifiers\CollectionModifiers;
use Etch\Blocks\Global\Utilities\Modifiers\ComparisonModifiers;
use Etch\Blocks\Global\Utilities\Modifiers\DateModifiers;
use Etch\Blocks\Global\Utilities\Modifiers\DynamicContentAwareModifiers;
use Etch\Blocks\Global\Utilities\Modifiers\NumericModifiers;
use Etch\Blocks\Global\Utilities\Modifiers\StringModifiers;

/**
 * Modifiers class for handling modifier application in dynamic data.
 */
class Modifiers {
	/**
	 * Parses modifier arguments from a string.
	 *
	 * @param string $arg_string The string to parse.
	 * @return array<string> The parsed arguments.
	 */
	public static function parse_modifier_arguments( string $arg_string ): array {
		return ModifierParser::split_args( $arg_string );
	}

	/**
	 * Check if the string is a modifier pattern
	 *
	 * @param string $part  String to be checked (e.g., 'format("y-m-d")', 'toUpperCase()').
	 * @return bool
	 */
	public static function is_modifier( string $part ): bool {
		return ModifierParser::is_modifier( $part );
	}

	private const REGISTRIES = array(
		ArithmeticModifiers::class,
		NumericModifiers::class,
		DateModifiers::class,
		StringModifiers::class,
		CollectionModifiers::class,
		ComparisonModifiers::class,
	);

	/**
	 * Get a modifier function by name.
	 *
	 * @param string               $method The modifier method name.
	 * @param array<string, mixed> $options Options including 'sources' array.
	 * @return callable|null Returns a callable that takes (value, ...args) or null if modifier doesn't exist.
	 */
	public static function get_modifier( string $method, array $options = array() ) {
		foreach ( self::REGISTRIES as $registry ) {
			$modifier = $registry::get_modifier( $method );
			if ( null !== $modifier ) {
				return $modifier;
			}
		}

		return DynamicContentAwareModifiers::get_modifier(
			$method,
			array( 'sources' => $options['sources'] ?? array() )
		);
	}

	/**
	 * Check if a modifier exists.
	 * Matches TypeScript getModifier() pattern - returns true if modifier exists.
	 *
	 * @param string $method The modifier method name (e.g., 'slice', 'toUpperCase').
	 * @return bool
	 */
	public static function has_modifier( string $method ): bool {
		return null !== self::get_modifier( $method );
	}

	/**
	 * Apply a modifier to a value.
	 *
	 * Options:
	 * - sources: array<int, array{key: string, source: mixed}>
	 *
	 * @param mixed                $value Value to modify.
	 * @param string               $modifier Modifier string like `applyData()`.
	 * @param array<string, mixed> $options Modifier options.
	 * @return mixed
	 */
	public static function apply_modifier( $value, string $modifier, array $options = array() ) {
		$modifier = trim( $modifier );
		if ( '' === $modifier || ! self::is_modifier( $modifier ) ) {
			return $value;
		}

		$sources = $options['sources'] ?? array();

		$parsed = ModifierParser::parse( $modifier );
		$method = $parsed['method'];
		$args_string = $parsed['args'];

		// Get the modifier function
		$modifier_func = self::get_modifier( $method, array( 'sources' => $sources ) );

		if ( null === $modifier_func ) {
			// Unknown modifier - return null to indicate it doesn't exist
			return null;
		}

		// Parse and resolve arguments
		$parsed_args = '' !== $args_string ? self::parse_modifier_arguments( $args_string ) : array();
		$resolved_args = array_map(
			static function ( $arg ) use ( $sources ) {
				return DynamicContentProcessor::process_expression(
					$arg,
					array(
						'sources' => $sources,
					)
				);
			},
			$parsed_args
		);

		// Call the modifier function with value and resolved args
		return $modifier_func( $value, ...$resolved_args );
	}
}
