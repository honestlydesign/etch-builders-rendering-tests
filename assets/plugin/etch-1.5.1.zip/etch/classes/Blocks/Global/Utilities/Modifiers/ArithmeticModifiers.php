<?php
/**
 * Arithmetic modifiers for Blocks dynamic content.
 *
 * @package Etch\Blocks\Global\Utilities\Modifiers
 */

declare(strict_types=1);

namespace Etch\Blocks\Global\Utilities\Modifiers;

/**
 * Arithmetic modifiers registry.
 */
class ArithmeticModifiers {
	/**
	 * Registered arithmetic modifier handlers.
	 *
	 * @var array<string, string>
	 */
	private const HANDLERS = array(
		'add'      => 'add_modifier',
		'subtract' => 'subtract_modifier',
		'multiply' => 'multiply_modifier',
		'divide'   => 'divide_modifier',
		'mod'      => 'mod_modifier',
	);

	/**
	 * Get an arithmetic modifier function by name.
	 *
	 * @param string $method The modifier method name.
	 * @return callable|null
	 */
	public static function get_modifier( string $method ) {
		$handler = self::HANDLERS[ $method ] ?? null;

		return null === $handler ? null : \Closure::fromCallable( array( self::class, $handler ) );
	}

	/**
	 * Add the right operand to the value.
	 *
	 * @param mixed $value Original value.
	 * @param mixed ...$args Modifier args.
	 * @return mixed
	 */
	private static function add_modifier( $value, ...$args ) {
		return self::with_numeric_operands(
			$value,
			$args,
			static fn( $left_operand, $right_operand ) => $left_operand + $right_operand
		);
	}

	/**
	 * Subtract the right operand from the value.
	 *
	 * @param mixed $value Original value.
	 * @param mixed ...$args Modifier args.
	 * @return mixed
	 */
	private static function subtract_modifier( $value, ...$args ) {
		return self::with_numeric_operands(
			$value,
			$args,
			static fn( $left_operand, $right_operand ) => $left_operand - $right_operand
		);
	}

	/**
	 * Multiply the value by the right operand.
	 *
	 * @param mixed $value Original value.
	 * @param mixed ...$args Modifier args.
	 * @return mixed
	 */
	private static function multiply_modifier( $value, ...$args ) {
		return self::with_numeric_operands(
			$value,
			$args,
			static fn( $left_operand, $right_operand ) => $left_operand * $right_operand
		);
	}

	/**
	 * Divide the value by the right operand.
	 *
	 * @param mixed $value Original value.
	 * @param mixed ...$args Modifier args.
	 * @return mixed
	 */
	private static function divide_modifier( $value, ...$args ) {
		return self::with_non_zero_right_operand(
			$value,
			$args,
			static fn( $left_operand, $right_operand ) => $left_operand / $right_operand
		);
	}

	/**
	 * Apply modulo using the right operand.
	 *
	 * @param mixed $value Original value.
	 * @param mixed ...$args Modifier args.
	 * @return mixed
	 */
	private static function mod_modifier( $value, ...$args ) {
		return self::with_non_zero_right_operand(
			$value,
			$args,
			static fn( $left_operand, $right_operand ) => fmod( (float) $left_operand, (float) $right_operand )
		);
	}

	/**
	 * Normalize a numeric operand while preserving int/float output.
	 *
	 * @param mixed $value Value to normalize.
	 * @return int|float|null
	 */
	private static function normalize_numeric_operand( $value ) {
		if ( is_string( $value ) ) {
			$value = trim( $value );
		}

		if ( ! is_numeric( $value ) ) {
			return null;
		}

		if ( is_float( $value ) && is_nan( $value ) ) {
			return null;
		}

		return 0 + $value;
	}

	/**
	 * Run arithmetic callback when both operands are numeric.
	 *
	 * @param mixed    $value Original value.
	 * @param mixed[]  $args Modifier args.
	 * @param callable $callback Arithmetic callback.
	 * @return mixed
	 */
	private static function with_numeric_operands( $value, array $args, callable $callback ) {
		if ( ! array_key_exists( 0, $args ) ) {
			return $value;
		}

		$left_operand  = self::normalize_numeric_operand( $value );
		$right_operand = self::normalize_numeric_operand( $args[0] );

		if ( null === $left_operand || null === $right_operand ) {
			return $value;
		}

		return $callback( $left_operand, $right_operand );
	}

	/**
	 * Run arithmetic callback when both operands are numeric and divisor is non-zero.
	 *
	 * @param mixed    $value Original value.
	 * @param mixed[]  $args Modifier args.
	 * @param callable $callback Arithmetic callback.
	 * @return mixed
	 */
	private static function with_non_zero_right_operand( $value, array $args, callable $callback ) {
		return self::with_numeric_operands(
			$value,
			$args,
			static function ( $left_operand, $right_operand ) use ( $value, $callback ) {
				if ( 0 == $right_operand ) {
					return $value;
				}

				return $callback( $left_operand, $right_operand );
			}
		);
	}
}
