<?php
/**
 * Comparison modifiers for Blocks dynamic content.
 *
 * @package Etch\Blocks\Global\Utilities\Modifiers
 */

declare(strict_types=1);

namespace Etch\Blocks\Global\Utilities\Modifiers;

/**
 * Comparison modifiers registry.
 */
class ComparisonModifiers {
	/**
	 * Registered comparison modifier handlers.
	 *
	 * @var array<string, string>
	 */
	private const HANDLERS = array(
		'less'           => 'less_modifier',
		'lessOrEqual'    => 'less_or_equal_modifier',
		'greater'        => 'greater_modifier',
		'greaterOrEqual' => 'greater_or_equal_modifier',
		'equal'          => 'equal_modifier',
	);

	/**
	 * Get a comparison modifier function by name.
	 *
	 * @param string $method The modifier method name.
	 * @return callable|null
	 */
	public static function get_modifier( string $method ) {
		$handler = self::HANDLERS[ $method ] ?? null;

		return null === $handler ? null : \Closure::fromCallable( array( self::class, $handler ) );
	}

	/**
	 * Compare whether the value is less than the argument.
	 *
	 * @param mixed $value Value to compare.
	 * @param mixed ...$args Comparison args.
	 * @return mixed
	 */
	private static function less_modifier( $value, ...$args ) {
		return self::apply_relational_modifier(
			$value,
			$args,
			static fn( $left_value, $right_value ) => $left_value < $right_value
		);
	}

	/**
	 * Compare whether the value is less than or equal to the argument.
	 *
	 * @param mixed $value Value to compare.
	 * @param mixed ...$args Comparison args.
	 * @return mixed
	 */
	private static function less_or_equal_modifier( $value, ...$args ) {
		return self::apply_relational_modifier(
			$value,
			$args,
			static fn( $left_value, $right_value ) => $left_value <= $right_value
		);
	}

	/**
	 * Compare whether the value is greater than the argument.
	 *
	 * @param mixed $value Value to compare.
	 * @param mixed ...$args Comparison args.
	 * @return mixed
	 */
	private static function greater_modifier( $value, ...$args ) {
		return self::apply_relational_modifier(
			$value,
			$args,
			static fn( $left_value, $right_value ) => $left_value > $right_value
		);
	}

	/**
	 * Compare whether the value is greater than or equal to the argument.
	 *
	 * @param mixed $value Value to compare.
	 * @param mixed ...$args Comparison args.
	 * @return mixed
	 */
	private static function greater_or_equal_modifier( $value, ...$args ) {
		return self::apply_relational_modifier(
			$value,
			$args,
			static fn( $left_value, $right_value ) => $left_value >= $right_value
		);
	}

	/**
	 * Compare whether the value is strictly equal to the argument.
	 *
	 * @param mixed $value Value to compare.
	 * @param mixed ...$args Comparison args.
	 * @return mixed
	 */
	private static function equal_modifier( $value, ...$args ) {
		if ( ! array_key_exists( 0, $args ) ) {
			return false;
		}

		$compare_value = $args[0];
		$true_value    = $args[1] ?? true;
		$false_value   = $args[2] ?? false;

		return $value === $compare_value ? $true_value : $false_value;
	}

	/**
	 * Apply shared relational comparison flow.
	 *
	 * @param mixed        $value Value to compare.
	 * @param array<mixed> $args Comparison args.
	 * @param callable     $operation Comparison operation.
	 * @return mixed
	 */
	private static function apply_relational_modifier( $value, array $args, callable $operation ) {
		if ( ! array_key_exists( 0, $args ) ) {
			return false;
		}

		$compare_value = $args[0];
		$true_value    = $args[1] ?? true;
		$false_value   = $args[2] ?? false;

		if ( ! self::is_comparable( $value ) || ! self::is_comparable( $compare_value ) ) {
			return $false_value;
		}

		return $operation( $value, $compare_value ) ? $true_value : $false_value;
	}

	/**
	 * Checks if a value is comparable (numeric or string).
	 *
	 * @param mixed $value The value to check.
	 * @return bool
	 */
	private static function is_comparable( $value ): bool {
		return is_numeric( $value ) || is_string( $value );
	}
}
