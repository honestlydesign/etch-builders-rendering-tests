<?php
/**
 * Dynamic-content-aware modifiers for Blocks dynamic content.
 *
 * @package Etch\Blocks\Global\Utilities\Modifiers
 */

declare(strict_types=1);

namespace Etch\Blocks\Global\Utilities\Modifiers;

use Etch\Blocks\Global\Utilities\DynamicContentProcessor;

/**
 * Dynamic-content-aware modifiers registry.
 */
class DynamicContentAwareModifiers {
	/**
	 * Registered dynamic-content-aware modifier handlers.
	 *
	 * @var array<string, string>
	 */
	private const HANDLERS = array(
		'applyData' => 'apply_data_modifier',
	);

	/**
	 * Get a dynamic-content-aware modifier function by name.
	 *
	 * @param string               $method The modifier method name.
	 * @param array<string, mixed> $options Options including 'sources' array.
	 * @return callable|null
	 */
	public static function get_modifier( string $method, array $options = array() ) {
		$handler = self::HANDLERS[ $method ] ?? null;

		if ( null === $handler ) {
			return null;
		}

		$sources = $options['sources'] ?? array();

		return static fn( $value ) => self::{$handler}( $value, $sources );
	}

	/**
	 * Apply dynamic content sources to a value.
	 *
	 * @param mixed                $value Value to process.
	 * @param array<string, mixed> $sources Dynamic data sources.
	 * @return mixed
	 */
	private static function apply_data_modifier( $value, array $sources ) {
		return DynamicContentProcessor::apply(
			$value,
			array(
				'sources' => $sources,
			)
		);
	}
}
