<?php
/**
 * String modifiers for Blocks dynamic content.
 *
 * @package Etch\Blocks\Global\Utilities\Modifiers
 */

declare(strict_types=1);

namespace Etch\Blocks\Global\Utilities\Modifiers;

use Etch\Blocks\Utilities\EtchTypeAsserter;

/**
 * String modifiers registry.
 */
class StringModifiers {
	/**
	 * Registered string modifier handlers.
	 *
	 * @var array<string, string>
	 */
	private const HANDLERS = array(
		'toUpperCase'   => 'to_upper_case_modifier',
		'toLowerCase'   => 'to_lower_case_modifier',
		'toString'      => 'to_string_modifier',
		'toBool'        => 'to_bool_modifier',
		'trim'          => 'trim_modifier',
		'ltrim'         => 'ltrim_modifier',
		'rtrim'         => 'rtrim_modifier',
		'split'         => 'split_modifier',
		'toSlug'        => 'to_slug_modifier',
		'truncateChars' => 'truncate_chars_modifier',
		'truncateWords' => 'truncate_words_modifier',
		'urlEncode'     => 'url_encode_modifier',
		'urlDecode'     => 'url_decode_modifier',
		'stripTags'     => 'strip_tags_modifier',
		'replace'       => 'replace_modifier',
		'replaceAll'    => 'replace_all_modifier',
		'startsWith'    => 'starts_with_modifier',
		'endsWith'      => 'ends_with_modifier',
	);

	/**
	 * Deprecated string modifier aliases.
	 *
	 * @var array<string, string>
	 */
	private const ALIASES = array(
		'toUppercase' => 'toUpperCase',
		'toLowercase' => 'toLowerCase',
	);

	/**
	 * Get a string modifier function by name.
	 *
	 * @param string $method The modifier method name.
	 * @return callable|null
	 */
	public static function get_modifier( string $method ) {
		$method  = self::ALIASES[ $method ] ?? $method;
		$handler = self::HANDLERS[ $method ] ?? null;

		return null === $handler ? null : \Closure::fromCallable( array( self::class, $handler ) );
	}

	/**
	 * Uppercase a string value.
	 *
	 * @param mixed $value Value to uppercase.
	 * @return mixed
	 */
	private static function to_upper_case_modifier( $value ) {
		if ( ! is_string( $value ) ) {
			return $value;
		}

		return mb_strtoupper( $value );
	}

	/**
	 * Lowercase a string value.
	 *
	 * @param mixed $value Value to lowercase.
	 * @return mixed
	 */
	private static function to_lower_case_modifier( $value ) {
		if ( ! is_string( $value ) ) {
			return $value;
		}

		return mb_strtolower( $value );
	}

	/**
	 * Cast a value to string.
	 *
	 * @param mixed $value Value to cast.
	 * @return string
	 */
	private static function to_string_modifier( $value ): string {
		return EtchTypeAsserter::to_string( $value );
	}

	/**
	 * Cast a value to bool.
	 *
	 * @param mixed $value Value to cast.
	 * @return bool
	 */
	private static function to_bool_modifier( $value ): bool {
		if ( is_bool( $value ) ) {
			return $value;
		}

		if ( is_null( $value ) ) {
			return false;
		}

		if ( is_numeric( $value ) ) {
			return (bool) (int) $value;
		}

		if ( is_string( $value ) ) {
			$normalized   = strtolower( trim( $value ) );
			$true_values  = array( 'true', '1', 'yes', 'y', 'on' );
			$false_values = array( 'false', '0', 'no', 'n', 'off', '' );

			if ( in_array( $normalized, $true_values, true ) ) {
				return true;
			}

			if ( in_array( $normalized, $false_values, true ) ) {
				return false;
			}
		}

		return (bool) $value;
	}

	/**
	 * Trim a string.
	 *
	 * @param mixed $value Value to trim.
	 * @return mixed
	 */
	private static function trim_modifier( $value ) {
		if ( ! is_string( $value ) ) {
			return $value;
		}

		return trim( $value );
	}

	/**
	 * Left trim a string.
	 *
	 * @param mixed $value Value to trim.
	 * @return mixed
	 */
	private static function ltrim_modifier( $value ) {
		if ( ! is_string( $value ) ) {
			return $value;
		}

		return ltrim( $value );
	}

	/**
	 * Right trim a string.
	 *
	 * @param mixed $value Value to trim.
	 * @return mixed
	 */
	private static function rtrim_modifier( $value ) {
		if ( ! is_string( $value ) ) {
			return $value;
		}

		return rtrim( $value );
	}

	/**
	 * Split a string.
	 *
	 * @param mixed $value Value to split.
	 * @param mixed ...$args Split args.
	 * @return mixed
	 */
	private static function split_modifier( $value, ...$args ) {
		if ( ! is_string( $value ) ) {
			return $value;
		}

		$separator = ',';
		if ( isset( $args[0] ) && is_string( $args[0] ) ) {
			$separator = $args[0];
		}

		if ( '' === $separator ) {
			return str_split( $value );
		}

		return explode( $separator, $value );
	}

	/**
	 * Slugify a string.
	 *
	 * @param mixed $value Value to slugify.
	 * @return mixed
	 */
	private static function to_slug_modifier( $value ) {
		if ( ! is_string( $value ) ) {
			return $value;
		}

		$slug           = mb_strtolower( trim( $value ), 'UTF-8' );
		$transliterated = transliterator_transliterate( 'Any-Latin; Latin-ASCII', $slug );
		$slug           = false !== $transliterated ? $transliterated : $slug;
		$slug           = preg_replace( '/[^a-z0-9]+/', '-', $slug ) ?? $slug;

		return trim( $slug, '-' );
	}

	/**
	 * Truncate a string by characters.
	 *
	 * @param mixed $value Value to truncate.
	 * @param mixed ...$args Truncation args.
	 * @return mixed
	 */
	private static function truncate_chars_modifier( $value, ...$args ) {
		if ( ! is_string( $value ) ) {
			return $value;
		}

		$char_count = 0;
		$ellipses   = '...';

		if ( isset( $args[0] ) && is_numeric( $args[0] ) ) {
			$char_count = (int) $args[0];
		}

		if ( isset( $args[1] ) && is_string( $args[1] ) ) {
			$ellipses = $args[1];
		}

		if ( mb_strlen( $value ) <= $char_count ) {
			return $value;
		}

		return mb_substr( $value, 0, $char_count ) . $ellipses;
	}

	/**
	 * Truncate a string by words.
	 *
	 * @param mixed $value Value to truncate.
	 * @param mixed ...$args Truncation args.
	 * @return mixed
	 */
	private static function truncate_words_modifier( $value, ...$args ) {
		if ( ! is_string( $value ) ) {
			return $value;
		}

		$word_count = 0;
		$ellipses   = '...';

		if ( isset( $args[0] ) && is_numeric( $args[0] ) ) {
			$word_count = (int) $args[0];
		}

		if ( isset( $args[1] ) && is_string( $args[1] ) ) {
			$ellipses = $args[1];
		}

		$words = explode( ' ', $value );
		if ( count( $words ) <= $word_count ) {
			return $value;
		}

		return implode( ' ', array_slice( $words, 0, $word_count ) ) . $ellipses;
	}

	/**
	 * URL encode a string.
	 *
	 * @param mixed $value Value to encode.
	 * @return mixed
	 */
	private static function url_encode_modifier( $value ) {
		if ( ! is_string( $value ) ) {
			return $value;
		}

		$revert = array(
			'%21' => '!',
			'%2A' => '*',
			'%27' => "'",
			'%28' => '(',
			'%29' => ')',
		);

		return strtr( rawurlencode( $value ), $revert );
	}

	/**
	 * URL decode a string.
	 *
	 * @param mixed $value Value to decode.
	 * @return mixed
	 */
	private static function url_decode_modifier( $value ) {
		if ( ! is_string( $value ) ) {
			return $value;
		}

		return rawurldecode( $value );
	}

	/**
	 * Strip tags from a string.
	 *
	 * @param mixed $value Value to sanitize.
	 * @return mixed
	 */
	private static function strip_tags_modifier( $value ) {
		if ( ! is_string( $value ) ) {
			return $value;
		}

		return strip_tags( $value );
	}

	/**
	 * Replace the first matching substring.
	 *
	 * @param mixed $value Value to search.
	 * @param mixed ...$args Replace args.
	 * @return mixed
	 */
	private static function replace_modifier( $value, ...$args ) {
		$search_value  = $args[0] ?? null;
		$replace_value = $args[1] ?? null;

		if ( ! self::are_all_strings( $value, $search_value, $replace_value ) ) {
			return $value;
		}

		assert( is_string( $value ) );
		assert( is_string( $search_value ) );
		assert( is_string( $replace_value ) );
		$position = strpos( $value, $search_value );
		if ( false === $position ) {
			return $value;
		}

		return substr_replace( $value, $replace_value, $position, strlen( $search_value ) );
	}

	/**
	 * Replace all matching substrings.
	 *
	 * @param mixed $value Value to search.
	 * @param mixed ...$args Replace args.
	 * @return mixed
	 */
	private static function replace_all_modifier( $value, ...$args ) {
		$search_value  = $args[0] ?? null;
		$replace_value = $args[1] ?? null;

		if ( ! self::are_all_strings( $value, $search_value, $replace_value ) ) {
			return $value;
		}

		assert( is_string( $value ) );
		assert( is_string( $search_value ) );
		assert( is_string( $replace_value ) );
		return str_replace( $search_value, $replace_value, $value );
	}

	/**
	 * Check whether a string starts with a substring.
	 *
	 * @param mixed $value Value to check.
	 * @param mixed ...$args Comparison args.
	 * @return mixed
	 */
	private static function starts_with_modifier( $value, ...$args ) {
		$true_value  = $args[1] ?? true;
		$false_value = $args[2] ?? false;

		if ( ! is_string( $value ) || ! array_key_exists( 0, $args ) ) {
			return $false_value;
		}

		$search_value = EtchTypeAsserter::to_string( $args[0] );

		return str_starts_with( $value, $search_value ) ? $true_value : $false_value;
	}

	/**
	 * Check whether a string ends with a substring.
	 *
	 * @param mixed $value Value to check.
	 * @param mixed ...$args Comparison args.
	 * @return mixed
	 */
	private static function ends_with_modifier( $value, ...$args ) {
		$true_value  = $args[1] ?? true;
		$false_value = $args[2] ?? false;

		if ( ! is_string( $value ) || ! array_key_exists( 0, $args ) ) {
			return $false_value;
		}

		$search_value = EtchTypeAsserter::to_string( $args[0] );

		return str_ends_with( $value, $search_value ) ? $true_value : $false_value;
	}

	/**
	 * Checks if all provided values are strings.
	 *
	 * @param mixed ...$values The values to check.
	 * @return bool
	 */
	private static function are_all_strings( ...$values ): bool {
		foreach ( $values as $value ) {
			if ( ! is_string( $value ) ) {
				return false;
			}
		}

		return true;
	}
}
