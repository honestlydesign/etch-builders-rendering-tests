<?php
/**
 * Date modifiers for Blocks dynamic content.
 *
 * @package Etch\Blocks\Global\Utilities\Modifiers
 */

declare(strict_types=1);

namespace Etch\Blocks\Global\Utilities\Modifiers;

/**
 * Date modifiers registry.
 */
class DateModifiers {
	/**
	 * Registered date modifier handlers.
	 *
	 * @var array<string, string>
	 */
	private const HANDLERS = array(
		'dateFormat' => 'date_format_modifier',
	);

	/**
	 * Deprecated date modifier aliases.
	 *
	 * @var array<string, string>
	 */
	private const ALIASES = array(
		'format' => 'dateFormat',
	);

	/**
	 * Get a date modifier function by name.
	 *
	 * @param string $method The modifier method name.
	 * @return callable|null
	 */
	public static function get_modifier( string $method ) {
		$method  = self::ALIASES[ $method ] ?? $method;
		$handler = self::HANDLERS[ $method ] ?? null;

		return null === $handler ? null : \Closure::fromCallable( array( self::class, $handler ) );
	}

	/**
	 * Format a date-like value when the modifier args are valid.
	 *
	 * @param mixed $value Value to format.
	 * @param mixed ...$args Modifier arguments.
	 * @return mixed
	 */
	private static function date_format_modifier( $value, ...$args ) {
		if ( ! array_key_exists( 0, $args ) || ! is_string( $args[0] ) ) {
			return $value;
		}

		$format = $args[0];

		try {
			if ( is_numeric( $value ) ) {
				$date = new \DateTime( '@' . $value );
			} elseif ( is_string( $value ) ) {
				$date = new \DateTime( $value );
			} else {
				return $value;
			}

			if ( function_exists( 'wp_date' ) ) {
				return wp_date( $format, (int) $date->format( 'U' ) );
			}

			return $date->format( $format );
		} catch ( \Exception $e ) {
			return $value;
		}
	}
}
