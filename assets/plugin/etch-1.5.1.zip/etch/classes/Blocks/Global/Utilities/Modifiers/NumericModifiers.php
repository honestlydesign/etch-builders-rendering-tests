<?php
/**
 * Numeric modifiers for Blocks dynamic content.
 *
 * @package Etch\Blocks\Global\Utilities\Modifiers
 */

declare(strict_types=1);

namespace Etch\Blocks\Global\Utilities\Modifiers;

/**
 * Numeric modifiers registry.
 */
class NumericModifiers {
	/**
	 * Registered numeric modifier handlers.
	 *
	 * @var array<string, string>
	 */
	private const HANDLERS = array(
		'numberFormat' => 'number_format_modifier',
		'toInt'        => 'to_int_modifier',
		'ceil'         => 'ceil_modifier',
		'round'        => 'round_modifier',
		'floor'        => 'floor_modifier',
	);

	/**
	 * Get a numeric modifier function by name.
	 *
	 * @param string $method The modifier method name.
	 * @return callable|null
	 */
	public static function get_modifier( string $method ) {
		$handler = self::HANDLERS[ $method ] ?? null;

		return null === $handler ? null : \Closure::fromCallable( array( self::class, $handler ) );
	}

	/**
	 * Format a numeric value.
	 *
	 * @param mixed $value Numeric value.
	 * @param mixed ...$args Formatting args.
	 * @return mixed
	 */
	private static function number_format_modifier( $value, ...$args ) {
		if ( ! is_numeric( $value ) ) {
			return $value;
		}

		$decimals             = 0;
		$decimal_point        = '.';
		$thousands_separator  = ',';

		if ( isset( $args[0] ) && self::is_numeric_type( $args[0] ) ) {
			$decimals = (int) $args[0];
		}

		if ( isset( $args[1] ) && is_string( $args[1] ) ) {
			$decimal_point = $args[1];
		}

		if ( isset( $args[2] ) && is_string( $args[2] ) ) {
			$thousands_separator = $args[2];
		}

		return number_format( (float) $value, $decimals, $decimal_point, $thousands_separator );
	}

	/**
	 * Cast a numeric value to int.
	 *
	 * @param mixed $value Value to cast.
	 * @return mixed
	 */
	private static function to_int_modifier( $value ) {
		if ( is_int( $value ) ) {
			return $value;
		}

		if ( is_numeric( $value ) ) {
			return (int) $value;
		}

		return $value;
	}

	/**
	 * Apply ceil to a numeric value.
	 *
	 * @param mixed $value Value to ceil.
	 * @return mixed
	 */
	private static function ceil_modifier( $value ) {
		if ( ! is_numeric( $value ) ) {
			return $value;
		}

		return (int) ceil( (float) $value );
	}

	/**
	 * Round a numeric value.
	 *
	 * @param mixed $value Value to round.
	 * @param mixed ...$args Precision args.
	 * @return mixed
	 */
	private static function round_modifier( $value, ...$args ) {
		if ( ! is_numeric( $value ) ) {
			return $value;
		}

		$precision = 0;

		if ( isset( $args[0] ) && is_numeric( $args[0] ) ) {
			$precision = (int) $args[0];
		}

		return round( (float) $value, $precision );
	}

	/**
	 * Apply floor to a numeric value.
	 *
	 * @param mixed $value Value to floor.
	 * @return mixed
	 */
	private static function floor_modifier( $value ) {
		if ( ! is_numeric( $value ) ) {
			return $value;
		}

		return (int) floor( (float) $value );
	}

	/**
	 * Checks if a value is a numeric type (int or float), excluding numeric strings.
	 *
	 * @param mixed $value The value to check.
	 * @phpstan-assert-if-true int|float $value
	 * @return bool
	 */
	private static function is_numeric_type( $value ): bool {
		return is_numeric( $value ) && ! is_string( $value );
	}
}
